//=========================================================================================================================================
// Server Config.CS
//=========================================================================================================================================

$Server::HostName = "=AWA=Yukichigai's Beta Test Server";	// The name of your
$Server::MaxPlayers = "2"; 				// Max Players On Your Server
$AdminPassword = "Spankme";				// Password for Admins
$Server::HostPublicGame = "true";			// Server will be publically listed


$Console::LogMode = "1"; 	   			// save the console to a logfile
$Server::Password = "";			// Server Password - for passworded matches
$TelnetPort = "9999";					// Telnet port number
$TelnetPassword = "and_a";				// Telnet password


//============================== Server Information That Players Can See.
$Server::Info = "SERVERSIDE ONLY MODS: Shifter v1Y\nAdmin: Yukichigai ICQ#... got me\nEmail: better than teletype\nRunning the latest build of Shifter_v1Y for testing purposes.  Be warned!";
$Server::JoinMOTD = "<jc><f1>Welcome to a Shifter_v1Y server\nTking and/or Bking is easily recognized and dealt with\nPacket Loss (PL) does not cause server lag\nIf you attempt to kick someone because of their ping or PL you will be BANNED.";
$Server::MODInfo = "Running Shifter_v1Y.\nmywebpage.netscape.com/yukichigai";
$MODInfo = $Server::MODInfo;

$Server::AutoAssignTeams = "true";		// Places players on teams automatically
$Server::FloodProtectionEnabled = "true";	// Check for chat flooding players
$Server::HostPublicGame = "true";		// List your server with the master list.
$pref::noIpx = "true";				// Disallow IPX/SPX binding

$Server::Port = "28000";			// Port To Run Server On
$Server::respawnTime = "2";			// Time after death to respawn.
$Server::TeamDamageScale = "1";			// Team Damage On/Off

//========================================= Team Names and Default Skins
$Server::teamName0 = "Kittens";		
$Server::teamSkin0 = "dsword";
$Server::teamName1 = "Kitty-Cats";		
$Server::teamSkin1 = "beagle";	
$Server::teamName2 = "Voyeurs";		
$Server::teamSkin2 = "swolf";
$Server::teamName3 = "Exhibitionists";		
$Server::teamSkin3 = "cphoenix";
$Server::teamName4 = "Base";				$Server::teamSkin4 = "base";
$Server::teamName5 = "Base";				$Server::teamSkin5 = "base";
$Server::teamName6 = "Base";				$Server::teamSkin6 = "base";
$Server::teamName7 = "Base";				$Server::teamSkin7 = "base";

$Server::timeLimit = "0";			// Mission Time Limit In Minutes

//========================================= Voting Varriables
$Server::MinVotes = "1";
$Server::MinVotesPct = "0.85";
$Server::MinVoteTime = "45";
$Server::VoteFailTime = "30";			// Length Of Votes if people are NOT voting.
$Server::VoteWinMargin = "0.699999";		// Ratio of Yeh to Neh to win vote.
$Server::VotingTime = "20";			// Length Of Votes if people are voting.


$Server::TourneyMode = "False";			// Set Tourney Mod Initially.

$Server::warmupTime = "2";			// Mission Start Time (Delay before missions starts)

$Server::PacketRate = "10";     		// recommended rate for a cable modem
$Server::PacketSize = "200";    		// recommended rate for a cable modem


//=========================================================================================================================================
// Shifter_v1.cs - The Following Options Pretain Strictly To The Functionality Of Shifter.
//=========================================================================================================================================


//=========================================================================================================================================
// Client Options
//=========================================================================================================================================
$Debug = "False";		// == Turns on Debug - If you have problems you can turn Debug on here.

$Shifter::NoSwearing = True; 	// == True means disallow swearing on your server? (update the SHBadwordlist.cs file)
$Shifter::BadWordsMax = 1; 	// == If no swearing, This value is the limit at which the client starts being killed for swearing
$Shifter::BadWordskick = 2; 	// == If no swearing, This value is the limit at which the client is kicked for swearing

$Shifter::LooseScore = 0.75;	// == This is the score ratio for the loosing team. 0.5 for instance would cut a loosing players score by half.

$Shifter::Guided = True;
$Shifter::SpawnType = "Random"; 	//== Must be 'Standard' or 'Random'
$Shifter::Racer = True;
$Shifter::SaveOn = True;
$Shifter::SpawnFavs = True;
$Shifter::EngHealAll = True;

$Shifter::VoteDTD = True;
$Shifter::VoteKick = True;
$Shifter::VoteAdmin = True;
$Shifter::HelpOn = True;
$Shifter::SwitchPerm = True;

$Shifter::ScoreTracker = True;
$Shifter::CheckScores = 30;
$Shifter::WarnScore1 = "-10";
$Shifter::WarnScore2 = "-20";
$Shifter::WarnScore3 = "-30";
$Shifter::WarnScoreFinal = "-40";

$pref::LastMission = "Next_Door2";

//=========================================================

$Shifter::RandomStart = False;
$Shifter::Reactions = True;
$Shifter::Refresh = False;

//=========================================================

$Shifter::HackedTime = 90;	// -- Time hacked items will remain hacked. 0 = Must be hacked back... - Defults To 90
$Shifter::HackTime = 5;		// -- Length Of Time To Complete Hacking - Defaults To 5
$Shifter::HackLock = 0;	// -- Legth of time a hacked item will be disabled for after being hacked. - Defaults To 0
$Shifter::LaserMineLive = 15;	// -- Live Time For Laser Mines - Defaults To 5 Seconds
$Shifter::ItemLimit = True;
$Shifter::DetPackLimit = 10;

//=========================================================

$Shifter::LocalNetMask = "IP:134.121.";
$Shifter::NukeLimit = 4;
$Shifter::PowerCheck = True;
$Shifter::TeamJuggle = 3;
$Shifter::AmmoBoom = True;
$Shifter::HeadShot = 5;
$Shifter::KillTime = 120;

$Shifter::Guided = True;

//=========================================================================================================================================
// AutoAdmin Options
//=========================================================================================================================================

//==== Wild card IP's must just be left blank. Do NOT use the * in place of an octet. Note below for an example.

$Server::AutoAdmin0 = "=AWA=*";
$Server::AutoAdmin1 = "";
$Server::AutoAdmin2 = "";
$Server::AutoAdmin2 = "";

$Server::AutoAdminAddr0 = "IP:134.121.";
$Server::AutoAdminAddr1 = "IP:134.121.";
$Server::AutoAdminAddr2 = "IPX";
$Server::AutoAdminAddr2 = "IPX";

$Server::Noban0 = "=AWA=Yukichigai";
$Server::Noban1 = "";
$Server::Noban2 = "";
$Server::Noban3 = "";
$Server::NobanAddr0 = "IP:134.121";
$Server::NobanAddr1 = "IPX";
$Server::NobanAddr2 = "";
$Server::NobanAddr3 = "";

//=========================================================================================================================================
// Server Options
//=========================================================================================================================================

$Shifter::Weapons = True;                               //== Advanced Weapon Options On

$Shifter::LockOn = True;				//== Missle locks

$Shifter::emailAddress = "Yukichigai@netscape.net";	//== Email address to show banned users for reinstatement
$Shifter::VoteAdmin =  False;				//== Can players initiate vote to admin
$Shifter::VoteKick = True;				//== Can players initiate vote to kick
$Shifter::RandomMissions = False;			//== Random Missions on/off
$Shifter::RandomStart = False;				//== Random Missions on/off

$Shifter::KeepBalanced = True;				//== Keep Balanced
$Shifter::SpawnRandom = True;				//== Turn on Random Spawn Setup?
$Shifter::NoOutside = True;				//== Turn on Outside of mission area damage
$Shifter::TurretKill = True;                           //== Turret Kills Count For Player
$Shifter::PersonalSkin = True;				//== Personal Skins On or Off

//=========================================================================================================================================
// Advanced Flag Options
//=========================================================================================================================================
$Shifter::FlagNoReturn = "True";
$Shifter::FlagReturnTime = "360";

//=========================================================================================================================================
// Advanced Scoring System
//=========================================================================================================================================
$ScoreOn = True;		    	//== If True will show client thier score on change in a bottom print message for 3 seconds.

$Score::25Meters = "5";     		//== Less Than 25 Meters To Flag
$Score::75Meters = "3";     		//== From 25 to 75 Meters
$Score::150Meters = "2";    		//== From 75 to 150 Meters
$Score::250Meters = "1";    		//== From 150 to 250 Meters

$Score::FlagCapture = "15";		//== Points For A Successful Flag Capture 
$Score::FlagKill = "7";  		//== Bonus For Killing Flag Runner
$Score::FlagDef  = "3";   		//== Bonus Points For Defending The Runner
$Score::FlagReturn = "24";   		//== Points For Returning Dropped

$Score::CaptureOdj = "2";   		//== Points For Capturing An Objective
$Score::HoldingObj = "5";   		//== Points For Holding An Objective For 60 Seconds.
$Score::InitialObj = "2";   		//== Points For Getting The Objective First

$Score::ObjDestroy = "15";      	//== Objective Destroyed
 
//=========================================================================================================================================
// Note about the following section... These points are awarded for destroying the enemy stations, generators, etc. 
// These points are also used in a calculation to give points for repairing things on your own team and to deduct points for
// repairing things on the enemy's team.
//
// The Lower option, Score::RepairObject is a base repair score. You can make this zero if you do not want players to get the 
// base 1 point ofr repairing... 
//
// You do NOT just get points for walking up and shooting something with a repair gun for a couple seconds. There is a detailed
// calculation that gets the total points for a repair job. The (ammount the item was damaged X the point value below) + the 
// Score::RepairObject... This ammount is given for repairing the players own teams equipment. It will also deduct this amount
// if the player repairs enemy equipment. 
//
// You will only gain points for repairing an object COMPLETELY... Points are calculated from the time you start the repair to the 
// time you finish, if you want full points you had better not stop...
//
// What stops a player from just shooting and repairing his own stuff to horde points?! If the player is the last person to have
// damaged the object he will recieve NO points.
//=========================================================================================================================================

$Score::ObjStationS = "7";      //== Destroy Supply Station 
$Score::ObjStationA = "5";      //== Destroy Ammo Station or Command
$Score::ObjStationR = "3";      //== Destroy Remote Station
$Score::ObjFlier = "3";         //== Destroy Flyer Pad or Station
$Score::ObjGeneratorB = "10";   //== Destroy Large Generator
$Score::ObjGeneratorS = "5";    //== Destroy Small Generator including - Panels
$Score::ObjSensorL = "5";       //== Destroy Large Sensors
$Score::ObjSensorS = "2";       //== Destroy Deployable Sensors

$Score::ObjTurretL = "3";       //== Large Turrets
$Score::ObjTurretS = "1";       //== Deployable Turrets

$Score::Kill15Meters = "1";	//== Player Makes A Kill With In 15m
$Score::Kill50Meters = "1";	//== Kill From 15 to 50m
$Score::Kill100Meters = "2";	//== Kill From 50 to 100m
$Score::Kill250Meters = "2";	//== Kill From 100 to 250m
$Score::Kill250Plus = "3";	//== Kill 250m Or More

$Score::RepairObject = "1";     //== Repair Bonus. Base Points For Repair...

$Shifter::SpawnSafe = "5";   	//== If the player is killed before X - Only Half Points Are Awarded.

//=========================================================================================================================================
// Fair Teams Variables
//=========================================================================================================================================

$Shifter::FairTeams = False;  //== Is Fair Teams Is On
$Shifter::FairCheck = "30";  //== Number in seconds that Shifter will check the teams evenness and warn players
$Shifter::FairEvens = "120"; //== Number in seconds that Shifter will move the last connected player to the un even team.

//=========================================================================================================================================
// Team Killing Options
//=========================================================================================================================================

$Shifter::TeamKillOn 	= "True";		//== Is Anti TK On/Off
$Shifter::KillTerm 		= "1";		//== Number Of Time A Player Can Team Kill
						//== Before Being Terminated (Killed By Server
$SHAntiTeamKillWarnKills 	= "1";         	//== Number Of Team Kills Before Player Gets Warning.
$SHAntiTeamKillBanTime 		= "600";	//== Length Of Time In Seconds Player Is Banded For.
$SHAntiTeamKillMaxKills 	= "2";		//== Maximum Team Kills Before Kicked - Banned.
$SHAntiTeamKillProximity	= "50";        	//== Proximity Distance For Accidental Damage.
	
//=========================================================================================================================================
// Varrious Server Messages To The Client
//=========================================================================================================================================

//================================================================= Message To Banned Team Killer
$Shifter::TeamKillMsg = "You have been kick and banned for team killing, i hope you enjoyed it. Email:" @ $Shifter::emailAddress @ " for reinstatement.";

//================================================================= Show When Client Spawns For The First Time

$Shifter::WelcomeMsg = "<jc><f2>Welcome to Y|yukichigai's Dominant/submissive server, a haven for those who don't want to conform\nMission: <f1><vmissionName> <f0>Mission Type: <f1><vGame::missionType>\n<f0>Bigots don't get very far here, so keep the language un-biased.\nDon't worry, we don't eat newbies!";

$Shifter::WelcomeDelay = "60";  //== Amount in seconds that the message is shown. If "0" message will not be displayed.

//=========================================================================================================================================
// Set Default Anti-TK Functions
//=========================================================================================================================================

if($SHAntiTeamKillWarnKills == "")
	$SHAntiTeamKillWarnKills = 1;
if($SHAntiTeamKillBanTime == "")
	$SHAntiTeamKillBanTime = 600;
if($SHAntiTeamKillMaxKills == "")
	$SHAntiTeamKillMaxKills = 2;
if($SHAntiTeamKillProximity == "")
    $SHAntiTeamKillProximity = 50;


//=========== Master Server Listing (Dont frell with this).
$Server::CurrentMaster = "0";
$Server::numMasters = "3";
$Server::Master1 = "t1m1.masters.dynamix.com:28000 t1m2.masters.dynamix.com:28000 t1m3.masters.dynamix.com:28000";
$Server::Master2 = "IP:BROADCAST:28001";

$Server::XLMaster1 = "IP:198.74.38.23:28000";
$Server::XLMaster2 = "IP:Broadcast:28001";
$Server::XLMasterN0 = "IP:209.67.28.148:28000";
$Server::XLMasterN1 = "IP:209.1.233.139:28000";
$Server::XLMasterN2 = "IP:198.74.40.68:28000";

$Server::MasterAddress0 = "IP:tribes.dynamix.com:28000";
$Server::MasterAddressN0 = "t1m1.masters.dynamix.com:28000 t1m2.masters.dynamix.com:28000 t1m3.masters.dynamix.com:28000";
$Server::MasterAddressN1 = "t1ukm1.masters.dynamix.com:28000 t1ukm2.masters.dynamix.com:28000 t1ukm3.masters.dynamix.com:28000";
$Server::MasterAddressN2 = "t1aum1.masters.dynamix.com:28000 t1aum2.masters.dynamix.com:28000 t1aum3.masters.dynamix.com:28000";
$Server::MasterName0 = "Tribes Master";
$Server::MasterName1 = "UK Tribes Master";
$Server::MasterName2 = "Australian Tribes Master";
//========================================================== v1Y stuff
$Shifter::BoosterPacks = true;	//== Mounts Booster Packs on Mercenary armor

$Shifter::Boosters = true;	//== Fires Merc Booster Packs when a player boosts.