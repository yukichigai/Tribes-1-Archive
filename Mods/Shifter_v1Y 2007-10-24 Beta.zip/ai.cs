
$AI::defaultPathType = 2; //run twoWay paths
$AI::defaultArmorType = "larmor";


function createAI( %aiName, %markerGroup, %armorType, %name )
{
   %group = nameToID( %markerGroup );
   
   if( %group == -1 || Group::objectCount(%group) == 0 )
   {
      return -1;
   }
   else
   {
      %spawnMarker = Group::getObject(%group, 0);
      %spawnPos = GameBase::getPosition(%spawnMarker);
      %spawnRot = GameBase::getRotation(%spawnMarker);

      if( AI::spawn( %aiName, %armorType, %spawnPos, %spawnRot, %name, "male2" ) != "false" ) //$AI::defaultarmor
      {
         // The order number is used for sorting waypoints, and other directives.  
         %orderNumber = 100;
         %aiId = AI::getID(%aiName);
	 %aiId.possessed = false;
         for(%i = 1; %i < Group::objectCount(%group); %i = %i + 1)
         {
             
            %spawnMarker = Group::getObject(%group, %i);
            %spawnPos = GameBase::getPosition(%spawnMarker);
            
            AI::DirectiveWaypoint( %aiName, %spawnPos, %orderNumber );
            
            %orderNumber += 100;
         }
      }
      else
      {
      }
   }
}

//----------------------------------   
function AI::setupAI(%key, %team)
{
   if(%key == "")
   {
      %aiFound = 0;
      for( %T = 0; %T < 8; %T++ )
      {
         %groupId = nameToID("MissionGroup\\Teams\\team" @ %T @ "\\AI" );
         if( %groupId != -1 )
         {
            %teamItemCount = Group::objectCount(%groupId);
            if( %teamItemCount > 0 )
            {
               AI::initDrones(%T, %teamItemCount);
               %aiFound += %teamItemCount;
            }
         }
      }
      if( %aiFound == 0 )
         dbecho(1, "No drones exist...");
      else
         dbecho(1, %aiFound @ " drones installed..." );
   }
   else     //respawning dead AI with original name and path
   {
      %group = nameToID("MissionGroup\\Teams\\team" @ %team @ "\\AI\\" @ %key);
      %num = Group::objectCount(%group);
      createAI(%key, %group, $AI::defaultArmorType, %key);
      %aiId = AI::getId(%key);
      GameBase::setTeam(%aiId, %team);
      AI::setVar(%key, pathType, $AI::defaultPathType);
      AI::setWeapons(%key);
   }		
}

//------------------------------
// AI::setWeapons()
//------------------------------
function AI::setWeapons(%aiName)
{
	%aiId = AI::getId(%aiName);
	
   if(Game::missionType == "DM")
   {	
      dbecho(2, "giving DM weapon select...");
      Player::setItemCount(%aiId, blaster, 1);
   }
   else
   {
      dbecho(2, "giving normal weapon select...");
      Player::setItemCount(%aiId, blaster, 1);
	   Player::setItemCount(%aiId, disclauncher, 1);
	   Player::setItemCount(%aiId, chaingun, 1);
	   Player::setItemCount(%aiId, discammo, 500);
	   Player::setItemCount(%aiId, bulletAmmo, 50000);
   }
   
   Player::mountItem(%aiId, blaster, 0);
   AI::SetVar(%aiName, triggerPct, 0.03 );
   AI::setVar(%aiName, iq, 70 );
   AI::setVar(%aiName, attackMode, 1);
   AI::setAutomaticTargets( %aiName );
   ai::callbackPeriodic(%aiName, 5, ai::periodicWeaponChange);
}


//-----------------------------------
// AI::periodicWeaponChange()
// Modified by Y|yukichigai to work with Shifter
//-----------------------------------
function ai::periodicWeaponChange(%aiName)
{
   %aiId = AI::getId(%aiName);

   if(($Hologram[%aiId,Deployer]).poss == %aiId || $Hologram[%aiId,Possessor] != false)
	return;

   dbecho(2, %aiName @ " thinking....");

   %curTarget = ai::getTarget( %aiName );
   
   if(%curTarget == -1)
   {
   	return;
   }
      
   dbecho(2, %aiName @ " target: " @ %curTarget);	
   
   %targLoc = GameBase::getPosition(Client::getOwnedObject(%curTarget));
   %aiLoc = GameBase::getPosition(Client::getOwnedObject(%aiId));
   %targetDist = Vector::getDistance(%aiLoc, %targLoc);
   dbecho(2, "distance to target: " @ %targetDist @ 
                  " targetPosition: " @ targLoc @ " aiLocation: " @ %aiLoc);
//   %jetting = Player::isJetting(%curTarget);        
//   if(%targetDist >= 100)
//   {
//   	Player::mountItem(%aiId, blaster, 0);
//      AI::SetVar(%aiName, triggerPct, 0.03 );
//   }   
//   else
//   {
//      dbecho(2, "checking for target jet...");
//      dbecho(2, "jetting? " @ %jetting);
//      if(%jetting)
//      {	
//         Player::mountItem(%aiId, Chaingun, 0);
//         AI::SetVar(%aiName, triggerPct, 0.6 );
//      }
//      else
//      {
//         Player::mountItem(%aiId, disclauncher, 0);  
//         AI::SetVar(%aiName, triggerPct, 0.03 );
//      }   
//   }
	%weapon = AI::getWeaponforRange(%aiId,%targetDist,%curTarget);
	if(%weapon != -1)
		Player::mountItem(%aiId, %weapon, 0);
}

function AI::getWeaponforRange(%aiId, %targetDist, %curTarget)
{
    %jetting = Player::isJetting(%curTarget);
    %aname = $ArmorName[Player::getArmor(%curTarget)];
    if(%targetDist <= 70)
    {
	if(Player::getItemCount(%aiId, EnergyRifle) > 0 && ((%curTarget.shieldStrength > 0 && GameBase::getEnergyLevel(%curTarget) > 30) || GameBase::getEnergy(%curTarget) >= 30))
		return EnergyRifle;
	if(Player::getItemCount(%aiId, Boomstick) > 0)
		return Boomstick;
	if(Player::getItemCount(%aiId, Boomer) > 0)
		return Boomer;
	if(Player::getItemCount(%aiId, IonGun) > 0 && %aname != AlArmor && %aname != MediumArmor)
		return IonGun;
    }
    if(%targetDist <= 25)
    {
	if(Player::getItemCount(%aiId, Flamer) > 0 && %aname != BursterArmor)
		return Flamer;
	if(Player::getItemCount(%aiId, Volter) > 0 && !%jetting && %aname != AlArmor && %aname != MediumArmor)
		return Volter;
    }
    if(%targetDist <= 84)
    {
	if(Player::getItemCount(%aiId, Silencer) > 0)
		return Silencer;
    }
    if(%targetDist <= 100)
    {
	if(Player::getItemCount(%aiId, IonGun) > 0 && %aname != AlArmor && %aname != MediumArmor)
		return IonGun;
	if(Player::getItemCount(%aiId, Mortar) > 0 && !%jetting)
		return Mortar0;
	if(Player::getItemCount(%aiId, GrenadeLauncher) && !%jetting)
		return GrenadeLauncher;
    }
    if(%targetDist <= 199)
    {
	if(Player::getItemCount(%aiId, HyperB) > 0)
		return HyperB;
    }

	if(Player::getItemCount(%aiId, SniperRifle) > 0)
		return SniperRifle;
	else if(Player::getItemCount(%aiId, Railgun) > 0)
		return Railgun;
	else if(Player::getItemCount(%aiId, TranqGun) > 0)
		return TranqGun;
	else if(Player::getItemCount(%aiId, LaserRifle) > 0 && GameBase::GetEnergy(%aiId) >= 60)
		return LaserRifle;
	else if(Player::getItemCount(%aiId, Vulcan) > 0 && !%jetting)
		return Vulcan;
	else if(Player::getItemCount(%aiId, RocketLauncher) > 0 && %jetting)
		return RocketLauncher;
	else if(Player::getItemCount(%aiId, PlasmaGun) > 0 && %aname != BursterArmor)
		return PlasmaGun;
	else if(Player::getItemCount(%aiId, Vulcan) > 0)
		return Vulcan;
	else if(Player::getItemCount(%aiId, MegaDiscLauncher) > 0 && !%jetting)
		return MegaDiscLauncher;
	else if(Player::getItemCount(%aiId, DiscLauncher) > 0 && !%jetting)
		return DiscLauncher;
	else if(Player::getItemCount(%aiId, Chaingun) > 0 && !%jetting)
		return Chaingun;
	else if(Player::getItemCount(%aiId, Blaster) > 0)
		return Blaster;
	else if(Player::getItemCount(%aiId, Chaingun) > 0)
		return Chaingun;
	else if(Player::getItemCount(%aiId, RocketLauncher) > 0)
		return RocketLauncher;
	else if(Player::getItemCount(%aiId, DiscLauncher) > 0)
		return DiscLauncher;
	else if(Player::getItemCount(%aiId, PlasmaGun) > 0)
		return PlasmaGun;

	//== If all else fails, don't change our weapon
	return -1;
}

//-----------------------------------
// AI::initDrones()
//-----------------------------------
function AI::initDrones(%team, %numAi)
{
	dbecho(1, "spawning team " @ %team @ " ai...");
   for(%guard = 0; %guard < %numAi; %guard++)
   {
      //check for internal data
      %tempSet = 	nameToID("MissionGroup\\Teams\\team" @ %team @ "\\AI");
      %tempItem = Group::getObject(%tempSet, %guard);
      %aiName = Object::getName(%tempItem);
      
      %set = nameToID("MissionGroup\\Teams\\team" @ %team @ "\\AI\\" @ %aiName);
      %numPts = Group::objectCount(%set);
      
      if(%numPts > 0)
      {
         createAI(%aiName, %set, $AI::defaultArmorType, %aiName);
         %aiId = AI::getId( %aiName );
         GameBase::setTeam(%aiId, %team);
         AI::setVar( %aiName,  iq,  60 );
         AI::setVar( %aiName,  attackMode, 1);
         AI::setVar( %aiName,  pathType, $AI::defaultPathType);
      	schedule("AI::setWeapons(" @ %aiName @ ");", 1);
      }
      else
         dbecho(1, "no info to spawn ai...");
   }
}


//------------------------------------------------------------------
//functions to test and move AI players.
//
//------------------------------------------------------------------

$numAI = 0;
function AI::helper(%aiName, %armorType, %commandIssuer)
{
   %spawnMarker = GameBase::getPosition(%commandIssuer);
   %xPos = getWord(%spawnMarker, 0) + floor(getRandom() * 15);
   %yPos = getword(%spawnMarker, 1) + floor(getRandom() * 10);
   %zPos = getWord(%spawnMarker, 2) + 2;
   %rPos = GameBase::getRotation(%commandIssuer);
   
   dbecho(2, "Spawning AI helper at position " @ %xPos @ " " @ %yPos @ " " @ %zPos);
   dbecho(2, "Current Issuer rotation: " @ %rPos);
      
   %aiSpawnPos = %xPos @ "  " @ %yPos @ "  " @ %zPos;
   %newName = %aiName @ $numAI;
   $numAI++;
   Ai::spawn(%newName, %armorType, %aiSpawnPos, %rPos);
   return ( %newName );
}

//
//This function will move an AI player to the position of an object
//that the players LOS is hitting(terrain included). Must be `	within 50 units.
//
//
function AI::moveToLOS(%aiName, %commandIssuer) 
{
   %aiId = AI:getID(%aiName);
   if(($Hologram[%aiId,Deployer]).poss == %aiId || $Hologram[%aiId,Possessor] != false)
	return;

   %issuerRot = GameBase::getRotation(%commandIssuer);
   %playerObj = Client::getOwnedObject(%commandIssuer);
   %playerPos = GameBase::getPosition(%commandIssuer);
      
   //check within max dist
   if(GameBase::getLOSInfo(%playerObj, 100, %issuerRot))
   { 
      %newIssuedVec = $LOS::position;
	  %distance = Vector::getDistance(%playerPos, %newIssuedVec);
	  dbecho(2, "Command accepted, AI player(s) moving....");
	  dbecho(2, "distance to LOS: " @ %distance);
	  AI::DirectiveWaypoint( %aiName, %newIssuedVec, 1 );
   }
   else
      dbecho(2, "Distance to far.");
      
   dbecho(2, "LOS point: " @ $LOS::position);
}

//This function will move an AI player to a position directly in front of
//the player passed, at a distance that is specified.
function  AI::moveAhead(%aiName, %commandIssuer, %distance) 
{
   %aiId = AI::getID(%aiName);
   if(($Hologram[%aiId,Deployer]).poss == %aiId || $Hologram[%aiId,Possessor] != false)
	return;

   %issuerRot = GameBase::getRotation(%commandIssuer);
   %commPos  = GameBase::getPosition(%commandIssuer);
   dbecho(2, "Commanders Position: " @ %commPos);
   
   //get commanders x and y positions
   %comm_x = getWord(%commPos, 0);
   %comm_y = getWord(%commPos, 1);
   
   //get offset x and y positions
   %offSetPos = Vector::getFromRot(%issuerRot, %distance);
   %off_x = getWord(%offSetPos, 0);
   %off_y = getWord(%offSetPos, 1);
   
   //calc new position
   %new_x = %comm_x + %off_x;
   %new_y = %comm_y + %off_y;
   %newPos = %new_x  @ " " @ %new_y @ " 0";
  
   //move AI player
   dbecho(2, "AI moving to " @ %newPos);
   AI::DirectiveWaypoint(%aiName, %newPos, 1);
}  

function AI::onCommand ( %name, %commander, %command, %waypoint, %targetId, %cmdText, %cmdStatus, %cmdSequence )
{
   %aiId = AI::getId( %name );
   if(($Hologram[%aiId,Deployer]).poss == %aiId || $Hologram[%aiId,Possessor] != false)
	return;

   %T = GameBase::getTeam( %aiId );
   %groupId = nameToID("MissionGroup\\Teams\\team" @ %T @ "\\AI\\" @ %name ); 
  	%nodeCount = Group::objectCount( %groupId );
   dbecho(2, "checking drone information...." @ " number of nodes: " @ %nodeCount);
   dbecho(2, "AI id: " @ %aiId @ " groupId: " @ %groupId);
   
   if($SinglePlayer || %nodeCount == 1)
   {
	   if( %command == 2 || %command == 1 )
	   {
	      // must convert waypoint location into world location.  waypoint location
	      //    is given in range [0-1023, 0-1023].  
	      %worldLoc = WaypointToWorld ( %waypoint );
	      AI::DirectiveWaypoint( %name, %worldLoc, 125 );
	      dbecho ( 2, %name @ " IS PROCEEDING TO LOCATION " @ %worldLoc );
	   }
	   dbecho( 2, "AI::OnCommand() issued to  " @ %name @ "  with parameters: " );
	   dbecho( 3, "Cmdr:        " @ %commander );
	   dbecho( 3, "Command:     " @ %command );
	   dbecho( 3, "Waypoint:    " @ %waypoint );
	   dbecho( 3, "TargetId:    " @ %targetId );
	   dbecho( 3, "cmdText:     " @ %cmdText );
	   dbecho( 3, "cmdStatus:   " @ %cmdStatus );
	   dbecho( 3, "cmdSequence: " @ %cmdSequence );
   }
   else if($Hologram[%name])
   {
	%worldLoc = WaypointToWorld(%waypoint);
	AI::directiveWaypoint(%name, %worldLoc, 1);
   }
   else
   	return;   
}


function Ai::soundHelper( %sourceId, %destId, %waveFileName )
{
   %wName = strcat( "~w", Client::getVoiceBase( %sourceId ) );
   %wName = strcat( %wName, ".w" );
   %wName = strcat( %wName, %waveFileName );
   %wName = strcat( %wName, ".wav" );
   
   dbecho( 2, "Trying to play " @ %wName );
   
   Client::sendMessage( %destId, 0, %wName );
}

function AI::onPeriodic( %aiName )
{
   dbecho(2, "onPeriodic() called with " @ %aiName );
}

function AI::onDroneKilled(%aiName)
{
   if( ! $SinglePlayer )
   {
      %aiId = AI::getId(%aiName);
      %team = GameBase::getTeam(%aiId);
      dbecho(2, "AI Id: " @ %aiId);
      
      // Trying a little longer delay -
      schedule("AI::setupAI(" @ %aiName @ ", " @ %team @ ");", 8 );
   }
   else
   {
      // just in case:
      dbecho( 2, "Non training callback called from Training" );
   }
}

function AI::onTargetLOSAcquired(%aiName, %idNum)
{
	if($Hologram[%aiName])
	{
		$Hologram[%aiName,Dodge] = true;
		Hologram::Think(AI::getId(%aiName));
	}
}

function AI::onTargetDied(%aiName, %idNum)
{
	if($Hologram[%aiName])
	{
		if($point[AI::getId(%aiName)])
			AI::DirectiveWaypoint(%aiName, $point[AI::getId(%aiName)]@" 0", 1);
		$Hologram[%aiName,Dodge] = false;
	}
}                                 

function AI::onTargetLOSLost(%aiName, %idNum)
{
	if($Hologram[%aiName])
		$Hologram[%aiName,Dodge] = false;
}

function AI::onTargetLOSRegained(%aiName, %idNum)
{
	if($Hologram[%aiName])
	{
		$Hologram[%aiName,Dodge] = true;
		Hologram::Think(AI::getId(%aiName));
	}
}

function AI::reMountAfterEMP(%aiId,%weapon)
{

	if(Player::isDead(%aiId))
		return;

	if(Player::getItemCount(%aiId,%weapon) > 0 || (%weapon == Mortar0 && Player::getItemCount(%aiId,Mortar) > 0))
	{
		if(Player::getMountedItem(%aiId,0))
		{
			dbecho(2,Player::getMountedItem(%aiId,0));
		}
		else
		{
			Player::mountItem(%aiId,%weapon,0);
		}
	}
}
