$BeenPlaying = 0;
exec("lastmatch.cs");
joingame();

function lastconnect()
{
	export("$server::address", "config\\lastmatch.cs", false);
	export("$server::joinpassword", "config\\lastmatch.cs", true);
}
Event::attach(eventConnected, lastconnect);

function JoinGameGui::onOpen()
{
   checkMasterTranslation();
	//update the record button
	if (! $recordDemo) $recorderFileName = "";
	Control::setValue(RecordDemo, $recordDemo);
	if(!$BeenPlaying)
	{
		joingame();
		$BeenPlaying = true;
	}
}
