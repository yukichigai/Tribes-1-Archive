$ImpactDamageType      = -1;
$ImpactDamageTurret    = 99;
$LandingDamageType     =  0;
$BulletDamageType      =  1;
$EnergyDamageType      =  2;	//=== Poison Effect
$PlasmaDamageType      =  3;	//=== On Fire Damage
$PlasmaDamageTurret    =  103;
$ExplosionDamageType   =  4;
$ShrapnelDamageType    =  5;
$LaserDamageType       =  6;
$LaserDamageTurret     =  106;
$MortarDamageType      =  7;
$MortarDamageTurret    =  107;
$BlasterDamageType     =  8;
$ElectricityDamageType =  9;
$ElectricityDamageTurret =  109;
$CrushDamageType       = 10;
$DebrisDamageType      = 11;
$MissileDamageType     = 12;
$MissileDamageTurret   = 112;
$MineDamageType        = 13;
$SniperDamageType      = 14;	//=== Drop Weapon-Flag Damage
$FlashDamageType       = 15;	//=== EMP Damage
$FlashDamageTurret     = 115;
$PoisonDamageType      = 16;
$ReFireDamageType      = 17;
$DeSupressDamageType   = 18;
$GravDamageType	       = 20;
$ShellDamageType       = 21;
$CloakDamageType       = 22;
$NukeDamageType        = 23;
$RailDamageType        = 24;	
$KamikazeDamageType    = 25;
$AntiMatterDamageType  = 26;
$EqualizerDamageType   = 27;
$OverDoseDamageType    = 28;
$IDamageType	       = 29;
$TargetingDamageType   = 30;
$FlareDamageType       = 31;
$DeCloakDamageType     = 32;
$ELFDamageType	       = 33;
$IceDamageType	       = 34;


//Globals
$hacking[%client] = "false";
$Viral = "false";
$isInfected[0] = "false";
$origTeam[0] = "-1";
$minHacked = "-1";
$maxHacked = "-1";
$minInfected = "-1";
$maxInfected = "-1";

if ($Shifter::HackTime == "")
	$Shifter::HackTime = "5";

if ($Shifter::HackedTime == "")
	$Shifter::HackedTime = "90";

if ($Shifter::HackLock == "")
	$Shifter::HackLock = "0";

if ($Shifter::AllowHacking == "")
	$Shifter::AllowHacking = True;

if (!$Shifter::LaserMineLive || $Shifter::LaserMineLive == "")
	$Shifter::LaserMineLive = 2;

//=======================================================================================================================
//						    Bullet Class Ammos
//=======================================================================================================================


//======================================================================== Interceptor Ammo 
BulletData InterceptorAmmo
{
	bulletShapeName    = "tumult_small.dts";
	explosionTag       = debrisExpsmall;
	collideWithOwner   = True;
	ownerGraceMS       = 250;
	collisionRadius    = 0.5;
	mass               = 1.0;
	elasticity         = 0.45;

	damageClass        = 1;       // 0 impact, 1, radius
	damageValue        = 0.5;
	damageType         = $IDamageType;

	explosionRadius    = 1.25;
	kickBackStrength   = 150.0;
	maxLevelFlightDist = 250;
	totalTime          = 30.0;    // special meaning for grenades...
	liveTime           = 0.3;
	projSpecialTime    = 0.05;

	aimDeflection      = 0.002;
	muzzleVelocity     = 100.0;
	totalTime          = 1.5;
	inheritedVelocityScale = 2.0;
	isVisible          = False;

	tracerPercentage   = 1.0;
	tracerLength       = 75;
};

//======================================================================== Shuriken
BulletData Shuriken
{
	bulletShapeName    = "discb.dts";
	explosionTag       = bulletExp0;
	mass               = 0.05;
	collisionRadius    = 0.0;
	damageClass        = 0;
	damageValue        = 0.5;
	damageType         = $EnergyDamageType;
	aimDeflection      = 0.0;
	muzzleVelocity     = 65.0;
	terminalVelocity	 = 85.0;
	acceleration	 = 5;
	totalTime          = 1;
	inheritedVelocityScale = 0.0;
	isVisible          = true;
	tracerPercentage   = 0.0;
	tracerLength       = 0;
};

//======================================================================== ChainGun
BulletData ChaingunBullet
{
	bulletShapeName    = "tumult_small.dts";
	explosionTag       = debrisExpsmall;
	collideWithOwner   = True;
	ownerGraceMS       = 250;
	collisionRadius    = 0.5;
	mass               = 1.0;
	elasticity         = 0.45;

	damageClass        = 1;       // 0 impact, 1, radius
	damageValue        = 0.37;
	damageType         = $EqualizerDamageType;

	explosionRadius    = 2.5;
	kickBackStrength   = 150.0;
	maxLevelFlightDist = 150;
	totalTime          = 30.0;    // special meaning for grenades...
	liveTime           = 1.5;
	projSpecialTime    = 0.05;

	aimDeflection      = 0.003;
	muzzleVelocity     = 200.0;
	totalTime          = 1.5;
	inheritedVelocityScale = 2.0;
	isVisible          = False;

	tracerPercentage   = 1.0;
	tracerLength       = 45;
};

//======================================================================== Sniper Bullet
BulletData SniperBullet
{
	bulletShapeName    = "bullet.dts";
	explosionTag       = bulletExp0;
	mass               = 0.05;
	collisionRadius    = 0.0;
	bulletHoleIndex    = 0;
	damageClass        = 0;
	damageValue        = 0.70;
	damageType         = $SniperDamageType;
	aimDeflection      = 0.0;
	muzzleVelocity     = 3500.0;
	totalTime          = 1;
	inheritedVelocityScale = 0.0;
	isVisible          = false;
	tracerPercentage   = 100.0;
	tracerLength       = 25;
};


//======================================================================== Silencer - Magnum
//From Grey's mod
BulletData SilencerBullet
{
	bulletShapeName    = "bullet.dts";
	explosionTag       = purpleExp;
	mass               = 200.0;
	bulletHoleIndex    = 0;
	damageClass        = 0;
	damageValue        = 1.02;
	damageType         = $BulletDamageType;
	muzzleVelocity     = 700.0;
	aimDeflection      = 0.0;
	totalTime          = 0.1;
	inheritedVelocityScale = 0.0;
	isVisible          = True;
	kickBackStrength = 900.0; 
	tracerPercentage   = 99.0;
	tracerLength       = 46;
	explosionRadius    = 0.03;
	collisionRadius    = 0.03;
};

//======================================================================== Vulcan Bullet
BulletData VulcanBullet
{
	bulletShapeName    = "bullet.dts";
	explosionTag       = bulletExp0;
	expRandCycle       = 3;
	mass               = 0.06;
	bulletHoleIndex    = 0;
	damageClass        = 0;       // 0 impact, 1, radius
	damageValue        = 0.03;
	damageType         = $BulletDamageType;
	aimDeflection      = 0.005;
	muzzleVelocity     = 900.0;
	totalTime          = 2;
	inheritedVelocityScale = 1.0;
	isVisible          = False;
	tracerPercentage   = 2.0;
	tracerLength       = 60;
};

//======================================================================== BoomStickBlast
BulletData BoomStickBlast
{
	bulletShapeName    = "bullet.dts";
	explosionTag       = bulletExp0;
	expRandCycle       = 3;
	mass               = 0.05;
	bulletHoleIndex    = 0;
	damageClass        = 0;       // 0 impact, 1, radius
	damageValue        = 0.08;
	damageType         = $ShellDamageType;
	aimDeflection      = 0.029;
	muzzleVelocity     = 200.0;
	totalTime          = 1;
	inheritedVelocityScale = 0.3;
	isVisible          = False;
	tracerPercentage   = 2.0;
	tracerLength       = 30;
	soundId = SoundJetLight;
};

//======================================================================== Jet Bullet
BulletData JetBullet
{
   bulletShapeName    = "bullet.dts";
   explosionTag       = bulletExp0;
   expRandCycle       = 3;
   mass               = 0.05;
   bulletHoleIndex    = 0;

   damageClass        = 0;       // 0 impact, 1, radius
   damageValue        = 0.20;
   damageType         = $BulletDamageType;

   aimDeflection      = 0.004;
   muzzleVelocity     = 900.0;
   totalTime          = 1.5;
   inheritedVelocityScale = 1.0;
   isVisible          = True;

   tracerPercentage   = 100.0;
   tracerLength       = 30;
};

//======================================================================== Fusion Bolt
BulletData FusionBolt
{
   bulletShapeName    = "fusionbolt.dts";
   explosionTag       = turretExp;
   mass               = 0.05;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 0.5;
   damageType         = $ImpactDamageTurret;
   collisionRadius    = 0.5;
   explosionRadius    = 2.5;

   muzzleVelocity     = 80.0;//50.0;
   totalTime          = 6.0;
   liveTime           = 4.0;
   isVisible          = True;

   rotationPeriod = 1.5;
};

//======================================================================== MiniFusionBolt
BulletData MiniFusionBolt
{
   bulletShapeName    = "enbolt.dts";
   explosionTag       = energyExp;

   damageClass        = 0;
   damageValue        = 0.15;
   damageType         = $ImpactDamageType;

   muzzleVelocity     = 80.0;
   totalTime          = 4.0;
   liveTime           = 2.0;

   lightRange         = 3.0;
   lightColor         = { 0.25, 0.25, 1.0 };
   inheritedVelocityScale = 0.5;
   isVisible          = True;

   rotationPeriod = 1;
};

//======================================================================== Blaster Bolt
BulletData BlasterBolt
{
   bulletShapeName    = "shotgunbolt.dts";
   explosionTag       = blasterExp;

   damageClass        = 0;
   damageValue        = 0.200;
   damageType         = $BlasterDamageType;

   muzzleVelocity     = 200.0;
   totalTime          = 2.0;
   liveTime           = 1.125;

   lightRange         = 3.0;
   lightColor         = { 1.0, 0.25, 0.25 };
   inheritedVelocityScale = 0.5;
   isVisible          = True;

   rotationPeriod = 1;
};

//======================================================================== Hyper Bolt
BulletData HyperBolt
{
   bulletShapeName    = "paint.dts";
   explosionTag       = hblasterExp;

   damageClass        = 0;
   damageValue        = 0.17;
   damageType         = $BlasterDamageType;

   muzzleVelocity     = 200.0;
   totalTime          = 1.0;
   liveTime           = 0.13;

   lightRange         = 3.0;
   lightColor         = { 0.3, 1.25, 0.25 };
   inheritedVelocityScale = 0.5;
   isVisible          = True;

   rotationPeriod = 1;
};

//======================================================================== Jet Bolt
BulletData JetBolt
{
    bulletShapeName    = "bullet.dts";
    explosionTag       = bulletExp0;
    expRandCycle       = 3;
    mass               = 0.05;
    bulletHoleIndex    = 0;
   
    damageClass        = 0;       // 0 impact, 1, radius
    damageValue        = 0.04;
    damageType         = $BulletDamageType;
  
    aimDeflection      = 0.002;
    muzzleVelocity     = 900.0;
    totalTime          = 2;
    inheritedVelocityScale = 2.0;
    isVisible          = False;
   
    tracerPercentage   = 2.0;
    tracerLength       = 160;
};

//======================================================================== Plasma Bolt
BulletData PlasmaBolt
{
   bulletShapeName    = "plasmabolt.dts";
   explosionTag       = plasmaExp;

   damageClass        = 1;
   damageValue        = 0.55;
   damageType         = $PlasmaDamageType;
   explosionRadius    = 5.0;

   muzzleVelocity     = 55.0;
   totalTime          = 3.0;
   liveTime           = 2.0;
   lightRange         = 3.0;
   lightColor         = { 1, 1, 0 };
   inheritedVelocityScale = 0.3;
   isVisible          = True;

   soundId = SoundJetLight;
};

RocketData PlasmaBolt2					//=== With Trail
{
	bulletShapeName  = "plasmabolt.dts";
   	explosionTag       = plasmaExp;
	collisionRadius  = 0.0;
	mass             = 0.0;

	damageClass      = 1;
	damageValue      = 0.65;
	damageType       = $PlasmaDamageType;
	explosionRadius  = 6.0;
	kickBackStrength = 0;
	
	muzzleVelocity   = 60.0;
	terminalVelocity = 60.0;
	acceleration     = 60.0;
	totalTime        = 1.7;
	liveTime         = 0.7;
	lightRange       = 1.0;
	lightColor       = { 1, 1, 0 };
	inheritedVelocityScale = 0.0;

	trailType   = 2;
	trailString = "plasmabolt.dts";
	smokeDist   = 5.0;
	soundId = SoundJetHeavy;
};
//======================================================================== Plasma Bolt Multi
BulletData PlasmaBoltMulti
{
   bulletShapeName    = "plasmabolt.dts";
   explosionTag       = plasmaExp;

   damageClass        = 1;
   damageValue        = 0.19;
   damageType         = $PlasmaDamageType;
   explosionRadius    = 2.5;

   muzzleVelocity     = 225.0;
   totalTime          = 3.0;
   liveTime           = 0.2;
   lightRange         = 3.0;
   lightColor         = { 1, 1, 0 };
   inheritedVelocityScale = 0.3;
   isVisible          = True;

   soundId = SoundJetLight;
};

RocketData PlasmaBoltMultiNew					//=== With Trail
{
	bulletShapeName  = "plasmabolt.dts";
   	explosionTag       = plasmaExp;
	collisionRadius  = 0.0;
	mass             = 0.0;

	damageClass      = 1;
	damageValue      = 0.19;
	damageType       = $PlasmaDamageType;
	explosionRadius  = 2.5;
	
	muzzleVelocity   = 225.0;
	terminalVelocity = 225.0;
	acceleration     = 1000.0;
	totalTime        = 3.0;
	liveTime         = 0.2;
	lightRange       = 3.0;
	lightColor       = { 1, 1, 0 };
	inheritedVelocityScale = 0.3;

	trailType   = 2;
	trailString = "plasmatrail.dts";
	smokeDist   = 5.0;
	soundId = SoundJetLight;
};

//======================================================================== Plasma Bolt Rapid
BulletData PlasmaBoltRapid
{
   bulletShapeName    = "plasmabolt.dts";
   explosionTag       = plasmaExp;

   damageClass        = 1;
   damageValue        = 0.35;
   damageType         = $PlasmaDamageType;
   explosionRadius    = 2.0;

   muzzleVelocity     = 300.0;
   totalTime          = 2.7;
   liveTime           = 1.3;
   lightRange         = 3.0;
   lightColor         = { 1, 1, 0 };
   inheritedVelocityScale = 0.3;
   isVisible          = True;

   soundId = SoundJetLight;
};

//======================================================================== Plasma Bolt Rapid2
BulletData PlasmaBoltRapid2
{
   bulletShapeName    = "plasmabolt.dts";
   explosionTag       = plasmaExp;

   damageClass        = 1;
   damageValue        = 0.25;
   damageType         = $PlasmaDamageType;
   explosionRadius    = 3.0;

   muzzleVelocity     = 250.0;
   totalTime          = 3.0;
   liveTime           = 1.7;
   lightRange         = 3.0;
   lightColor         = { 1, 1, 0 };
   inheritedVelocityScale = 0.3;
   isVisible          = True;

   soundId = SoundJetLight;
};

//======================================================================== Booster Fire
RocketData Booster
{
	bulletShapeName  = "plasmaex.dts";
   	explosionTag  = plasmaExp; //boosterExp;
	collisionRadius  = 0.0;
	collideWithOwner = False;

	mass             = 0.0;
	damageClass      = 1;
	damageValue      = 0.0;
	damageType       = $PlasmaDamageType;
	explosionRadius  = 0.0;
	kickBackStrength = 0.0;
	
	muzzleVelocity   = 5.0;
	terminalVelocity = 5.0;
	acceleration     = 5.0;
	totalTime        = 0.55;
	liveTime         = 0.55;
	lightRange       = 3.0;
	lightColor       = { 1, 1, 0 };
	inheritedVelocityScale = 0.0;

	trailType   = 0;
	trailString = "plasmaex.dts";
	smokeDist   = 5.0;
	soundId = SoundJetHeavy;
};

//======================================================================== Flamer Bolt
BulletData FlamerBolt
{
   bulletShapeName    = "plasmaex.dts";
   explosionTag       = plasmaExp;

   damageClass        = 1;
   damageValue        = 0.20;
   damageType         = $PlasmaDamageType;
   explosionRadius    = 4.0;

   muzzleVelocity     = 30.0;
   totalTime          = 0.75;
   liveTime           = 0.85;
   lightRange         = 3.0;
   lightColor         = { 1, 1, 0 };
   inheritedVelocityScale = 0.3;
   isVisible          = True;

   soundId = SoundJetLight;
};

//======================================================================== HellFire Bullets
BulletData HellFireBullet
{
	bulletShapeName    = "bullet.dts";
	explosionTag       = plasmaExp;

	damageClass        = 1;
	damageValue        = 0.10;
	damageType         = $PlasmaDamageType;
	explosionRadius    = 5.0;

	aimDeflection      = 0.007;
	muzzleVelocity     = 155.0;
	totalTime          = 2.0;
	liveTime           = 2.0;
	lightRange         = 3.0;
	lightColor         = { 1, 1, 0 };
	inheritedVelocityScale = 0.3;
	isVisible          = True;

	rotationPeriod = 1;

	soundId = SoundJetLight;
};

//=======================================================================================================================
//						    Missile Class Ammos
//=======================================================================================================================

//=============================================================================== Laser Cannon

RocketData LasCannonBolt
{ 
	bulletShapeName = "enbolt.dts"; 
	explosionTag = ShockwaveFour; 
	collisionRadius = 0.0;
	mass = 0.0; 
	damageClass = 0;
    	damageValue = 0.8; 
	damageType = $LaserDamageType;
	explosionRadius = 2; 
	kickBackStrength = 0.0; 
	muzzleVelocity = 250.0; 
	terminalVelocity = 3000.0;
	acceleration = 500; 
	totalTime = 14.0; 
	liveTime = 14.0; 
	lightRange = 5.0; 
	lightColor = { 0.0, 0.0, 1.5 }; 
	inheritedVelocityScale = 0.0; 
	trailType = 1;
	trailLength = 3000; 
	trailWidth = 2.0; 
	soundId = SoundJetHeavy;
};

RocketData LasCannonBolt2
{ 
	bulletShapeName = "enbolt.dts"; 
	explosionTag = ShockwaveFour; 
	collisionRadius = 0.0;
	mass = 0.0; 
	damageClass = 0;
    	damageValue = 0.5; 
	damageType = $LaserDamageType;
	explosionRadius = 2; 
	kickBackStrength = 0.0; 
	muzzleVelocity = 250.0; 
	terminalVelocity = 3000.0;
	acceleration = 500; 
	totalTime = 14.0; 
	liveTime = 14.0; 
	lightRange = 5.0; 
	lightColor = { 0.0, 0.0, 1.5 }; 
	inheritedVelocityScale = 0.0; 
	trailType = 1;
	trailLength = 3000; 
	trailWidth = 1.0; 
	soundId = SoundJetHeavy;
};

RocketData LasCannonShock
{
	bulletShapeName  = "shield.dts";
	explosionTag     = ShockwaveFour;
	collisionRadius  = 0.0;
	mass             = 0.0;
	damageClass      = 0;
	damageValue      = 1.0;
	damageType       = $LaserDamageType;
	explosionRadius  = 5.0;
	kickBackStrength = 0;
	muzzleVelocity   = 250.0;
	terminalVelocity = 4000.0;
	acceleration     = 500.0;
	totalTime        = 14.0;
	liveTime         = 14.0;
	lightRange       = 5.0;
	lightColor       = { 0.0, 0.1, 1.5 };
	inheritedVelocityScale = 0.0;

	trailType   = 2;
	trailString = "shield.dts";
	smokeDist   = 20.0;
	soundId = SoundJetHeavy;
};

//===================================================================================== Anti-Aircraft Turret

SeekingMissileData BarrageBolt
{
	bulletShapeName  = "tracer.dts";
	explosionTag     = flashExpMedium;
	collisionRadius  = 0.0;
	mass             = 1.5;

	damageClass      = 1;
	damageValue      = 0.20;
	damageType       = $MissileDamageTurret;

	explosionRadius  = 4.0;
	kickBackStrength = 10.0;
	muzzleVelocity   = 50.0;
	terminalVelocity = 210.0;
	acceleration     = 400.0;
	totalTime        = 20.0;
	liveTime         = 21.0;
	seekingTurningRadius = 1;
	nonSeekingTurningRadius = 1.1;
	proximityDist 	 = 1.9;
	smokeDist 	 = 0.5;
	lightRange       = 1.0;
	lightColor       = { 1.0, 0.7, 0.5 };
	inheritedVelocityScale = 0.5;
	soundId = SoundJetHeavy;
};

function BarrageBolt::verifyTarget(%target, %this)
{
	return "True";
}


//======================================================================== Sniper Round
RocketData SniperRound
{
	bulletShapeName  = "bullet.dts";
	explosionTag     = bulletExp0;
	collisionRadius  = 0.0;
	mass             = 2.0;
	damageClass      = 0;
	damageValue      = 0.73;
	damageType       = $SniperDamageType;
	explosionRadius  = 0.1;
	kickBackStrength = 600.0;
	muzzleVelocity   = 3500.0;
	terminalVelocity = 3500.0;
	acceleration     = 500.0;
	totalTime        = 10.0;
	liveTime         = 11.0;
	lightRange       = 10.0;
	lightColor       = { 0.25, 0.25, 1 };
	inheritedVelocityScale = 1.0;
	soundId = SoundJetHeavy;
};

//======================================================================== Tranq Round
RocketData TranqDart
{
	bulletShapeName  = "bullet.dts";
	explosionTag     = bulletExp0;
	collisionRadius  = 0.0;
	mass             = 0.2;
	damageClass      = 0;
	damageValue      = 0.37;
	damageType       = $EnergyDamageType;
	explosionRadius  = 0.1;
	bulletHoleIndex  = 0;
	kickBackStrength = 600.0;
	muzzleVelocity   = 3500.0;
	terminalVelocity = 3500.0;
	acceleration     = 500.0;
	totalTime        = 10.0;
	liveTime         = 11.0;
	lightRange       = 10.0;
	lightColor       = { 0.25, 0.25, 1 };
	inheritedVelocityScale = 0.0;
	soundId = SoundJetHeavy;
};

//======================================================================== EMP Round
RocketData EMPDart
{
	bulletShapeName  = "bullet.dts";
	explosionTag     = bulletExp1;
	collisionRadius  = 0.0;
	mass             = 0.2;
	damageClass      = 0;
	damageValue      = 0.20;
	damageType       = $FlashDamageType;
	explosionRadius  = 0.1;
	bulletHoleIndex  = 0;
	kickBackStrength = 600.0;
	muzzleVelocity   = 3500.0;
	terminalVelocity = 3500.0;
	acceleration     = 500.0;
	totalTime        = 10.0;
	liveTime         = 11.0;
	lightRange       = 10.0;
	lightColor       = { 0.25, 0.25, 1 };
	inheritedVelocityScale = 0.0;
	soundId = SoundJetHeavy;
};

//======================================================================== Flare Round
RocketData FlareDart
{
	bulletShapeName  = "bullet.dts";
	explosionTag     = bulletExp4;
	collisionRadius  = 0.0;
	mass             = 0.2;
	damageClass      = 0;
	damageValue      = 0.30;
	damageType       = $FlareDamageType;
	explosionRadius  = 0.1;
	bulletHoleIndex  = 0;
	kickBackStrength = 600.0;
	muzzleVelocity   = 3500.0;
	terminalVelocity = 3500.0;
	acceleration     = 500.0;
	totalTime        = 10.0;
	liveTime         = 11.0;
	lightRange       = 10.0;
	lightColor       = { 0.25, 0.25, 1 };
	inheritedVelocityScale = 0.0;
	soundId = SoundJetHeavy;
};

//======================================================================== De-Cloak Dart
BulletData DeCloakDart
{
	bulletShapeName    = "bullet.dts";
	explosionTag       = flaredartExp;
	mass               = 0.05;
	damageClass        = 1;       // 0 impact, 1, radius
	damageValue        = 0.20;
	damageType         = $DeCloakDamageType;
	explosionRadius    = 10;
	muzzleVelocity     = 900.0;
	totalTime          = 1.5;
	inheritedVelocityScale = 0.0;
	isVisible          = False;
};

//======================================================================== Camera De-supression round
RocketData DeSupress
{
	bulletShapeName  = "breath.dts";
	explosionTag     = fakeExp;
	collisionRadius  = 0.0;
	mass             = 0.2;
	damageClass      = 0;
	damageValue      = 0.30;
	damageType       = $DeSupressDamageType;
  	explosionRadius  = 0.1;
	bulletHoleIndex  = 0;
	kickBackStrength = 0.0;
	muzzleVelocity   = 3500.0;
	terminalVelocity = 3500.0;
	acceleration     = 500.0;
	totalTime        = 10.0;
	liveTime         = 11.0;
	lightRange       = 0.0;
	lightColor       = { 0.0, 0.0, 0.0 };
	inheritedVelocityScale = 0.0;
};

//======================================================================== Disc Shell
RocketData FakeDiscShell
{
   bulletShapeName = "breath.dts";
   explosionTag    = fakeExp;

   collisionRadius = 0.0;
   mass            = 2.0;

   damageClass      = 0;
   damageValue      = 0.0;
   damageType       = $ExplosionDamageType;

   explosionRadius  = 7.5;
   kickBackStrength = 150.0;

   muzzleVelocity   = 75.0;
   terminalVelocity = 100.0;
   acceleration     = 5.0;

   totalTime        = 6.5;
   liveTime         = 8.0;

//   lightRange       = 5.0;
//   lightColor       = { 0.4, 0.4, 1.0 };

   inheritedVelocityScale = 0.5;

   // rocket specific
//   trailType   = 1;
//   trailLength = 15;
//   trailWidth  = 0.3;

//   soundId = SoundDiscSpin;
};

function FakeDiscShell::onAdd(%this)
{
	%player = FindProjectileFirer(%this,DiscLauncher);
	if(%player)
	{
		Player::incItemCount(%player,$WeaponAmmo[DiscLauncher],1);
		%fired = DiscLauncherImage::onFire(%player,$WeaponSlot);
		if(%fired)
		{
			GameBase::setPosition(%fired,GameBase::getPosition(%this));
		}
	}
	schedule("deleteObject("@%this@");",0.1);
}

RocketData DiscShell
{
   bulletShapeName = "discb.dts";
   explosionTag    = rocketExp;

   collisionRadius = 0.0;
   mass            = 2.0;

   damageClass      = 1;
   damageValue      = 0.6;
   damageType       = $ExplosionDamageType;

   explosionRadius  = 7.5;
   kickBackStrength = 150.0;

   muzzleVelocity   = 75.0;
   terminalVelocity = 100.0;
   acceleration     = 5.0;

   totalTime        = 6.5;
   liveTime         = 8.0;

   lightRange       = 5.0;
   lightColor       = { 0.4, 0.4, 1.0 };

   inheritedVelocityScale = 0.5;

   // rocket specific
   trailType   = 1;
   trailLength = 15;
   trailWidth  = 0.3;

   soundId = SoundDiscSpin;
};

RocketData DiscShell2
{
   bulletShapeName = "discb.dts";
   explosionTag    = rocketExp;

   collisionRadius = 0.0;
   mass            = 2.0;

   damageClass      = 1;
   damageValue      = 0.51;
   damageType       = $ExplosionDamageType;

   explosionRadius  = 7.0;
   kickBackStrength = 200.0;

   muzzleVelocity   = 175.0;
   terminalVelocity = 4000.0;
   acceleration     = 30.0;

   totalTime        = 6.5;
   liveTime         = 8.0;

   lightRange       = 5.0;
   lightColor       = { 0.4, 0.4, 1.0 };

   inheritedVelocityScale = 0.5;

   // rocket specific
   trailType   = 1;
   trailLength = 15;
   trailWidth  = 0.3;

   soundId = SoundDiscSpin;
};

//======================================================================== Mega-Disc Shell
RocketData MegaDiscShell
{
   bulletShapeName = "discammo.dts";
   explosionTag    = purpleExpLarge;//FireyrocketExp;

   collisionRadius = 0.0;
   mass            = 2.0;

   damageClass      = 1;
   damageValue      = 0.65;
   damageType       = $ExplosionDamageType;

   explosionRadius  = 12;
   kickBackStrength = 150.0;

   muzzleVelocity   = 175.0;
   terminalVelocity = 4000.0;
   acceleration     = 30.0;

   totalTime        = 6.5;
   liveTime         = 8.0;

   lightRange       = 5.0;
   lightColor       = { 0.45, 0.16, 1.0 }; //{ 1.0, 1.0, 0.4 };

   inheritedVelocityScale = 0.5;

   // rocket specific
   trailType   = 2;
   trailString = "flash_small.dts";//"plastrail.dts";
   smokeDist   = 3.0;
//	trailType   = 1;
//	trailLength = 20;
//	trailWidth  = 0.6;

   soundId = SoundDiscSpin;
};

//======================================================================== Flier Rocket
RocketData FlierRocket
{
   bulletShapeName  = "rocket.dts";
   explosionTag     = rocketExp;
   collisionRadius  = 0.0;
   mass             = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 0.5;
   damageType       = $MissileDamageType;

   explosionRadius  = 9.5;
   kickBackStrength = 250.0;
   muzzleVelocity   = 65.0;
   terminalVelocity = 80.0;
   acceleration     = 5.0;
   totalTime        = 10.0;
   liveTime         = 11.0;
   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };
   inheritedVelocityScale = 0.5;
   trailType   = 2;                // smoke trail
   trailString = "rsmoke.dts";
   smokeDist   = 1.8;

   soundId = SoundJetHeavy;
};

//======================================================================== Turret Missile

SeekingMissileData TurretMissile
{
   bulletShapeName = "rocket.dts";
   explosionTag    = rocketExp;
   collisionRadius = 0.0;
   mass            = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 0.5;
   damageType       = $MissileDamageTurret;
   explosionRadius  = 9.5;
   kickBackStrength = 175.0;

   muzzleVelocity    = 72.0;
   totalTime         = 10;
   liveTime          = 10;
   seekingTurningRadius    = 9;
   nonSeekingTurningRadius = 75.0;
   proximityDist     = 1.5;
   smokeDist         = 1.75;

   lightRange       = 5.0;
   lightColor       = { 0.4, 0.4, 1.0 };

   inheritedVelocityScale = 0.5;

   soundId = SoundJetHeavy;
};

function SeekingMissile::updateTargetPercentage(%target)
{
	return GameBase::virtual(%target, "getHeatFactor");
}


//======================================================================== Shock Blast
RocketData Shock
{
   bulletShapeName  = "shield.dts";
   explosionTag     = ShockwaveFour;
   collisionRadius  = 0.0;
   mass             = 2.0;

   damageClass      = 1;
   damageValue      = 0.15;
   damageType       = $ImpactDamageType;  //$MissileDamageType;

   explosionRadius  = 30.0;
   kickBackStrength = 350.0;
   muzzleVelocity   = 50.0;
   terminalVelocity = 80.0;
   acceleration     = 5.0;
   totalTime        = 6.0;
   liveTime         = 4.0;
   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };
   inheritedVelocityScale = 0.5;
   trailType   = 2;
   trailString = "shield.dts";
   smokeDist   = 1.8;
   soundId = SoundJetHeavy;
};

//======================================================================== Turret Shock

RocketData TurretShock
{
   bulletShapeName  = "fusionbolt.dts";
   explosionTag     = LargeShockwave;
   collisionRadius  = 0.0;
   mass             = 2.0;

   damageClass      = 1;
   damageValue      = 0.0;
   damageType       = $MissileDamageTurret;

   explosionRadius  = 30.0;
   kickBackStrength = 450.0;
   muzzleVelocity   = 65.0;
   terminalVelocity = 80.0;
   acceleration     = 5.0;
   totalTime        = 10.0;
   liveTime         = 11.0;
   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };
   inheritedVelocityScale = 0.5;

   soundId = SoundJetHeavy;
};

//======================================================================== Rail Round

RocketData RailRound
{
   bulletShapeName  = "bullet.dts";
   explosionTag     = bulletExp0;
   collisionRadius  = 0.0;
   mass             = 2.0;

   damageClass      = 0;
   damageValue      = 0.75;
   damageType       = $RailDamageType;

   explosionRadius  = 0.1;
   kickBackStrength = 600.0;
   muzzleVelocity   = 2000.0;
   terminalVelocity = 2000.0;
   acceleration     = 5.0;
   totalTime        = 10.0;
   liveTime         = 11.0;
   lightRange       = 10.0;
   lightColor       = { 0.25, 0.25, 1 };
   inheritedVelocityScale = 1.0;

   trailType   = 1;         
   trailLength = 3000;
   trailWidth  = 0.6;
  
   soundId = SoundJetHeavy;

};


//======================================================================== Mini-Locking Missle 
SeekingMissileData MiniMissileTracker 
{
	bulletShapeName = "rocket.dts";
	explosionTag = rocketExp;
	collisionRadius = 0.0;
	mass = 2.0;
	damageClass = 1;
	damageValue = 0.5;
	damageType = $MissileDamageType;
	explosionRadius = 10.0;
	kickBackStrength = 100.0;
	muzzleVelocity = 100.0;
	terminalVelocity = 1000.0;
	acceleration = 200.0;
	totalTime = 15.0;
	liveTime = 15.0;
	lightRange = 5.0;
	lightColor = { 1.0, 0.7, 0.5 };
	inheritedVelocityScale = 0.5;
	seekingTurningRadius = 3.6;
	nonSeekingTurningRadius = 3.6;
	proximityDist = 0.5;
	lightRange = 5.0;
	lightColor = { 0.4, 0.4, 1.0 };
	smokeDist = 4.5;
	inheritedVelocityScale = 0.5;
	soundId = SoundJetHeavy;
};
function MiniMissileTracker::updateTargetPercentage(%target)
{
   return GameBase::virtual(%target, "getHeatFactor");
}

//======================================================================== Locking Missle 
SeekingMissileData StingerMissileTracker 
{
	bulletShapeName = "rocket.dts";
	explosionTag = rocketExp;
	collisionRadius = 0.0;
	mass = 2.0;
	damageClass = 1;
	damageValue = 0.6;
	damageType = $MissileDamageType;
	explosionRadius = 8.5;
	kickBackStrength = 220.0;
	muzzleVelocity = 45.0;
	terminalVelocity = 60.0;
	acceleration = 15.0;
	totalTime = 4.0;
	liveTime = 21.0;
	lightRange = 5.0;
	lightColor = { 1.0, 0.7, 0.5 };
	inheritedVelocityScale = 0.5;
	seekingTurningRadius = 1.0;
	nonSeekingTurningRadius = 1.1;
	proximityDist = 1.5;
	lightRange = 5.0;
	lightColor = { 0.4, 0.4, 1.0 };
	trailType = 2;
	trailString = "plasmatrail.dts";
	//smokeDist = 2.5;
	inheritedVelocityScale = 0.5;
	soundId = SoundJetHeavy;
};
//======================================================================== Stinger Missile
RocketData StingerMissile
{
   bulletShapeName = "rocket.dts";
   explosionTag    = rocketExp;

   collisionRadius = 0.0;
   mass            = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 0.5;
   damageType       = $MissileDamageType;

   explosionRadius  = 12.5;
   kickBackStrength = 100.0;

   muzzleVelocity   = 200.0;
   terminalVelocity = 2000.0;
   acceleration     = 50.0;

   totalTime        = 8.5;
   liveTime         = 18.0;

   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };

   inheritedVelocityScale = 0.5;
   trailType   = 2;
   trailString = "rsmoke.dts";
   smokeDist   = 1.8;
   soundId = SoundJetHeavy;
};
//======================================================================== Juggy Locking Missle 
SeekingMissileData JugStingerMissileTracker 
{
	bulletShapeName = "rocket.dts";
	explosionTag = FireyRocketExp;
	collisionRadius = 0.0;
	mass = 2.0;
	damageClass = 1;
	damageValue = 0.75;
	damageType = $MissileDamageType;
	explosionRadius = 8.5;
	kickBackStrength = 220.0;
	muzzleVelocity = 45.0;
	terminalVelocity = 60.0;
	acceleration = 15.0;
	totalTime = 4.0;
	liveTime = 21.0;
	lightRange = 5.0;
	lightColor = { 1.0, 0.7, 0.5 };
	inheritedVelocityScale = 0.5;
	seekingTurningRadius = 1.0;
	nonSeekingTurningRadius = 1.1;
	proximityDist = 1.5;
	lightRange = 5.0;
	lightColor = { 0.4, 0.4, 1.0 };
	trailType = 2;
	trailString = "plastrail.dts";
	//smokeDist = 2.5;
	inheritedVelocityScale = 0.5;
	soundId = SoundJetHeavy;
};
//======================================================================== Regular Stinger Missile
RocketData RegStingerMissile
{
   bulletShapeName = "rocket.dts";
   explosionTag    = FireyRocketExp;

   collisionRadius = 0.0;
   mass            = 2.0;

   damageClass      = 1;       // 0 impact, 1, radius
   damageValue      = 0.72;
   damageType       = $MissileDamageType;

   explosionRadius  = 12.5;
   kickBackStrength = 100.0;

   muzzleVelocity   = 200.0;
   terminalVelocity = 2000.0;
   acceleration     = 50.0;

   totalTime        = 8.5;
   liveTime         = 18.0;

   lightRange       = 5.0;
   lightColor       = { 1.0, 0.7, 0.5 };

   inheritedVelocityScale = 0.5;
   trailType   = 2;
   trailString = "plastrail.dts"; //"rsmoke.dts";
   smokeDist   = 1.8;
   soundId = SoundJetHeavy;
};

//======================================================================== GodHammer Missile
RocketData GodHammer
{
	bulletShapeName = "rocket.dts";
	explosionTag    = rocketExp;
	collisionRadius = 0.0;
	mass            = 2.0;
	damageClass      = 1;       // 0 impact, 1, radius
	damageValue      = 0.45;
	damageType       = $ExplosionDamageType;
	explosionRadius  = 15;
	kickBackStrength = 80;
	muzzleVelocity   = 200.0;//50.0;
	terminalVelocity = 2000.0;//1000.0;
	acceleration     = 150.0;
	totalTime        = 8.5;
	liveTime         = 18.0;
	lightRange       = 5.0;
	lightColor       = { 0.0, 0.7, 0.5 };
	inheritedVelocityScale = 0.75;
	trailType   = 1;
	trailLength = 35;
	trailWidth  = 0.45;//0.40;
	soundId = SoundJetHeavy;
	rotationPeriod = 1.5;
};

//======================================================================== Slow GodHammer Missile
RocketData GodHammerSlow
{
	bulletShapeName = "rocket.dts";
	explosionTag    = rocketExp;
	collisionRadius = 0.0;
	mass            = 2.0;
	damageClass      = 1;       // 0 impact, 1, radius
	damageValue      = 0.45;
	damageType       = $ExplosionDamageType;
	explosionRadius  = 15;
	kickBackStrength = 80;
	muzzleVelocity   = 50.0;
	terminalVelocity = 1000.0;
	acceleration     = 150.0;
	totalTime        = 8.5;
	liveTime         = 18.0;
	lightRange       = 5.0;
	lightColor       = { 0.0, 0.7, 0.5 };
	inheritedVelocityScale = 0.75;
	trailType   = 1;
	trailLength = 35;
	trailWidth  = 0.45;//0.40;
	soundId = SoundJetHeavy;
	rotationPeriod = 1.5;
};

//======================================================================== Godhammer Locking Missle 
SeekingMissileData GodhammerMissileTracker 
{
	bulletShapeName = "rocket.dts";
	explosionTag = RocketExp;
	collisionRadius = 0.0;
	mass = 2.0;
	damageClass = 1;
	damageValue = 0.75;
	damageType = $ExplosionDamageType;
	explosionRadius = 15;
	kickBackStrength = 80.0;
	muzzleVelocity = 200.0;
	terminalVelocity = 1000.0;
	acceleration = 15.0;
	totalTime = 4.0;
	liveTime = 21.0;
	inheritedVelocityScale = 0.75;
	seekingTurningRadius = 1.0;
	nonSeekingTurningRadius = 1.1;
	proximityDist = 1.5;
	lightRange = 5.0;
	lightColor = { 0.4, 0.4, 1.0 };
	trailType   = 1;
	trailLength = 35;
	trailWidth  = 0.40;
	soundId = SoundJetHeavy;
	rotationPeriod = 1.5;
};

//======================================================================== GodHammer Pod
MineData GodHammerPod
{
	className = "Mine";
        description = "GodHammerPod";
        shapeFile = "rocket";
        shadowDetailMask = 4;
        explosionId = ShockwaveFour;
        explosionRadius = 5.0;
        damageValue = 0.15;
	damageType = $MineDamageType;
	kickBackStrength = 450;
	triggerRadius = 2.5;
	maxDamage = 0.5;
	shadowDetailMask = 0;
	destroyDamage = 1.0;
	damageLevel = {1.0, 1.0};
};

function GodHammerPod::OnAdd(%this)
{
	schedule("GodHammerPod::Release(" @ %this @ ");", 1.0);
}

function GodHammerPod::Release(%this)
{
	%client = %this.deployer;
	%player = Client::GetOwnedObject(%client);

	%rot = gamebase::getrotation(%player);
	%dir = (Vector::getfromrot(%rot));
	%vel = item::getvelocity(%this);
	%trans =  %rot @ " " @ %dir @ " " @ %dir @ " " @ gamebase::getposition(%this);

	%fired = Projectile::spawnProjectile(GodHammer, %trans ,%player,%vel);
	%fired.deployer = %client;
	deleteobject(%this);
}

//======================================================================== GodHammer Wire Guided Missle
GrenadeData GodHammerMortar
{
   bulletShapeName    = "rocket.dts";
   explosionTag       = rocketExp;
   collideWithOwner   = True;
   ownerGraceMS       = 650;
   collisionRadius    = 2.5;
   mass               = 200.0;
   elasticity         = 0.55;
   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 1.0;
   damageType         = $MortarDamageType;
   explosionRadius    = 20.0;
   kickBackStrength   = 150.0;
   maxLevelFlightDist = 75;
   totalTime          = 2.0;
   liveTime           = 2.0;
   projSpecialTime    = 2.0;
   inheritedVelocityScale = 0.1;
};


function GodHammerMortar::OnAdd(%this)
{
	schedule("GodHammerMortar::Release(" @ %this @ ");", 0.5);
}

function GodHammerMortar::Release(%this)
{
	%client = %this.deployer;
	%player = Client::GetOwnedObject(%client);
	%rot = gamebase::getrotation(%player);
	%dir = (Vector::getfromrot(%player));
	%vel = item::getvelocity(%player);
	%trans = GameBase::getMuzzleTransform(%player);	
	%t0 = getword (%trans, 0); %t1 = getword (%trans, 1); %t2 = getword (%trans, 2); %t3 = getword (%trans, 3); %t4 = getword (%trans, 4); %t5 = getword (%trans, 5); %t6 = getword (%trans, 6); %t7 = getword (%trans, 7); %t8 = getword (%trans, 8);
	%trans = %t0 @ " " @ %t1 @ " " @ %t2 @ " " @ %t3 @ " " @ %t4 @ " " @ %t5 @ " " @ %t6 @ " " @ %t7 @ " " @ %t8 @ " " @ gamebase::getposition(%this);
	playSound(SoundMissileTurretFire,GameBase::getPosition(%this));	
	%fired = Projectile::spawnProjectile(GodHammer, %trans ,%player,%vel);
	%fired.deployer = %client;
	%fired.spawn = %this.spawn + 1;
	%fired.pos = gamebase::getposition(%fired);
	%this.distance = Vector::getDistance(%this.pos, %fired.pos);
	
	if (%fired.spawn < 50 && %this.distance > 8)
	{
		schedule("GodHammerMortar::Release(" @ %fired @ ");", 0.25);
	}
	deleteobject(%this);
}


//========================================================================  Ion Bolt
RocketData IonBolt
{ 
	bulletShapeName = "enbolt.dts"; 
	explosionTag = turretExp; 
	collisionRadius = 0.0;
	 mass = 2.0; 
	damageClass = 1;
    	damageValue = 0.29; 
	damageType = $ElectricityDamageType; 
	explosionRadius = 4.0; 
	kickBackStrength = 0.0; 
	muzzleVelocity = 250.0; 
	terminalVelocity = 2000.0;
	acceleration = 500.0; 
	totalTime = 0.6; 
	liveTime = 0.3; 
	lightRange = 5.0; 
	lightColor = { 1.0, 0.7, 0.5 }; 
	inheritedVelocityScale = 0.2; 
	trailType = 1;
	trailLength = 250; 
	trailWidth = 0.9; 
	soundId = SoundJetHeavy;
};

//========================================================================  Ion Turret Bolt
RocketData IonBoltTurret
{ 
	bulletShapeName = "enbolt.dts"; 
	explosionTag = turretExp; 
	collisionRadius = 0.0;
	 mass = 2.0; 
	damageClass = 1;
    	damageValue = 0.29;  //.25 
	damageType = $ElectricityDamageTurret; 
	explosionRadius = 4.0; 
	kickBackStrength = 0.0; 
	muzzleVelocity = 250.0; 
	terminalVelocity = 2000.0;
	acceleration = 500.0; 
	totalTime = 0.5; 
	liveTime = 0.3; 
	lightRange = 5.0; 
	lightColor = { 1.0, 0.7, 0.5 }; 
	inheritedVelocityScale = 0.2; 
	trailType = 1;
	trailLength = 250; 
	trailWidth = 0.9; 
	soundId = SoundJetHeavy;
};

//=======================================================================================================================
//						    Grenade Class Ammos
//=======================================================================================================================

//======================================================================== DeadRocket
GrenadeData DeadRocket
{
	bulletShapeName    = "rocket.dts";
	explosionTag       = shockwave;
	collideWithOwner   = True;
	ownerGraceMS       = 250;
	collisionRadius    = 0.3;
	mass               = 400.0;
	elasticity         = 0.01;

	damageClass        = 1;       // 0 impact, 1, radius
	damageValue        = 0.0; //0.25;
	damageType         = $ImpactDamageType;

	explosionRadius    = 15.0;
	kickBackStrength   = -10.0;
	maxLevelFlightDist = 75;
	totalTime          = 30.0;
	liveTime           = 2.0;
	projSpecialTime    = 0.01;
	lightRange       = 5.0;
	lightColor       = { 1.0, 0.7, 0.5 };
	inheritedVelocityScale = 0;
	smokeName        = "rsmoke.dts";

};

//======================================================================== Grenade Shell
GrenadeData GrenadeShell
{
   bulletShapeName    = "grenade.dts";
   explosionTag       = grenadeExp;
   collideWithOwner   = True;
   ownerGraceMS       = 250;
   collisionRadius    = 0.2;
   mass               = 1.0;
   elasticity         = 0.45;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 0.4;
   damageType         = $ShrapnelDamageType;

   explosionRadius    = 15;
   kickBackStrength   = 150.0;
   maxLevelFlightDist = 150;
   totalTime          = 30.0;    // special meaning for grenades...
   liveTime           = 1.0;
   projSpecialTime    = 0.05;

   inheritedVelocityScale = 0.5;

   smokeName              = "smoke.dts";
};

//======================================================================== 20mm HE Shell
GrenadeData GrenadeShellP
{
   bulletShapeName    = "grenade.dts";
   explosionTag       = grenadeExp;
   collideWithOwner   = True;
   ownerGraceMS       = 250;
   collisionRadius    = 0.2;
   mass               = 1.0;
   elasticity         = 0.45;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 0.6;
   damageType         = $ShrapnelDamageType;

   explosionRadius    = 20;
   kickBackStrength   = 150.0;
   maxLevelFlightDist = 150;
   totalTime          = 30.0;    // special meaning for grenades...
   liveTime           = 0.1;
   projSpecialTime    = 0.05;

   inheritedVelocityScale = 0.5;

   smokeName              = "plastrail.dts";
};

//======================================================================== Mortar Shell
GrenadeData MortarShell
{
   bulletShapeName    = "mortar.dts";
   explosionTag       = mortarExp;
   collideWithOwner   = True;
   ownerGraceMS       = 250;
   collisionRadius    = 0.3;
   mass               = 5.0;
   elasticity         = 0.1;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 1.0;
   damageType         = $MortarDamageType;

   explosionRadius    = 20.0;
   kickBackStrength   = 250.0;
   maxLevelFlightDist = 275;
   totalTime          = 30.0;
   liveTime           = 2.0;
   projSpecialTime    = 0.01;

   inheritedVelocityScale = 0.5;
   smokeName              = "mortartrail.dts";
};

//======================================================================== Fake Mortar Shell
GrenadeData FakeMortarShell
{
   bulletShapeName    = "breath.dts";
   explosionTag       = fakeExp;
   collideWithOwner   = True;
   ownerGraceMS       = 250;
   collisionRadius    = 0.3;
   mass               = 5.0;
   elasticity         = 0.1;

   damageClass        = 0;       // 0 impact, 1, radius
   damageValue        = 0.0;
   damageType         = $MortarDamageType;

   explosionRadius    = 20.0;
   kickBackStrength   = 250.0;
   maxLevelFlightDist = 275;
   totalTime          = 30.0;
   liveTime           = 2.0;
   projSpecialTime    = 1.0;

   inheritedVelocityScale = 0.5;
   smokeName              = "breath.dts";
};

function FakeMortarShell::onAdd(%this)
{
	%player = FindProjectileFirer(%this,Mortar);
	if(%player)
	{
		Player::incItemCount(%player,$WeaponAmmo[Mortar],1);
		%fired = MortarImage::onFire(%player,$WeaponSlot);
		if(%fired)
			GameBase::setPosition(%fired,GameBase::getPosition(%this));
	}
	schedule("deleteObject("@%this@");",0.1);
}

function FindProjectileFirer(%this,%weapon)
{
	%set = newObject("set",SimSet);
	%Pos = GameBase::getPosition(%this);
	%Mask = $SimPlayerObjectType;
	%range = 3.0;

	containerBoxFillSet(%Set, %Mask, %Pos, %range, %range, %range, 0);
	%num = Group::objectCount(%set);

	%found = false;

	for(%i = 0; %i < %num;%i++)
	{
		%obj = Group::getObject(%set,%i);
		if(Player::getMountedItem(%obj,$WeaponSlot) == %weapon && Player::isTriggered(%obj,$Weaponslot))
		{
			%found = %obj;
			break;
		}
	}
	deleteObject(%set);

	return %found;
}

//======================================================================== MDM Mortar
GrenadeData DelayMortarShell
{
   bulletShapeName    = "mortar.dts";
   explosionTag       = ShockwaveThree;
   collideWithOwner   = True;
   ownerGraceMS       = 650;
   collisionRadius    = 2.5;
   mass               = 200.0;
   elasticity         = 0.55;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 1.0;
   damageType         = $MortarDamageType;

   explosionRadius    = 20.0;
   kickBackStrength   = 150.0;
   maxLevelFlightDist = 475;
   totalTime          = 30.0;
   liveTime           = 10.0;
   projSpecialTime    = 0.01; //0.09;

   inheritedVelocityScale = 0.1;
   smokeName              = "shotgunex.dts"; //"mortartrail.dts";
};

function DelayMortarShell::onRemove(%this)
{
	if($Firer[%this] != "")
	{
		%cl = $Firer[%this];
		%cl.firemortar = "";
		if(%cl.lastMDM)
			Player::decItemCount(%cl,$WeaponAmmo[Mortar],1);
		%cl.lastMDM = false;
		$Firer[%this] = "";
	}
}

//======================================================================== Ice Mortar
GrenadeData IceMortarShell
{
   bulletShapeName    = "mortar.dts";
   explosionTag       = ShockwaveThree;
   collideWithOwner   = True;
   ownerGraceMS       = 650;
   collisionRadius    = 2.5;
   mass               = 200.0;
   elasticity         = 0.55;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 1.0;
   damageType         = $IceDamageType;

   explosionRadius    = 20.0;
   kickBackStrength   = 150.0;
   maxLevelFlightDist = 475;
   totalTime          = 30.0;
   liveTime           = 10.0;
   projSpecialTime    = 0.01;

   inheritedVelocityScale = 0.1;
   smokeName              = "hflame.dts";
};

function IceMortarShell::onRemove(%this)
{
	if($Firer[%this] != "")
	{
		%cl = $Firer[%this];
		%cl.firemortar = "";
		if(%cl.lastMDM)
			Player::decItemCount(%cl,$WeaponAmmo[Mortar],1);
		%cl.lastMDM = false;
		$Firer[%this] = "";
	}
}

//======================================================================== Mortar Turret Shell
GrenadeData MortarTurretShell
{
   bulletShapeName    = "mortar.dts";
   explosionTag       = mortarExp;
   collideWithOwner   = True;
   ownerGraceMS       = 400;
   collisionRadius    = 2.5; //1.0;
   mass               = 5.0;
   elasticity         = 0.1;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 1.32;
   damageType         = $MortarDamageTurret;

   explosionRadius    = 30.0;
   kickBackStrength   = 250.0;
   maxLevelFlightDist = 400;
   totalTime          = 200.0;
   liveTime           = 0.3;
   projSpecialTime    = 0.05;

   inheritedVelocityScale = 0.5;
   smokeName              = "mortartrail.dts";
};

function MortarTurretShell::onAdd(%this)
{
	FindSourceTurret(%this,"MortarTurretShell","DeployableMortar","MortarTurret");
	Schedule("MortarTurretShell::CheckCollision("@%this@");",MortarTurretShell.liveTime,%this);
}

function MortarTurretShell::CheckCollision(%this)
{
	%Set = newObject("set",SimSet); 
	%Pos = GameBase::getPosition(%this); 
	%Mask = $SimPlayerObjectType;
	%range = MortarTurretShell.collisionRadius * 2;

	containerBoxFillSet(%Set, %Mask, %Pos, %range, %range, %range,0);

	//=== It doesn't matter what's in range, as long as it's something
	if(Group::objectCount(%set) > 0)
	{
		%mbomb = newObject("","Mine","MortarBomb2");
		addToSet("MissionCleanup",%mbomb);
		if(%this.deployer)
			%thrower = %this.deployer;
		else
			%thrower = %this;
		GameBase::throw(%mbomb,%thrower,0,false);
		GameBase::setPosition(%mbomb,%pos);
		%this.deployer = false;
		deleteObject(%this);
		schedule("Mine::Detonate("@%mbomb@");",0.1,%mbomb);
		deleteObject(%set);
		return;
	}
	deleteObject(%set);

	schedule("MortarTurretShell::CheckCollision("@ %this @");",0.1,%this);
}


//======================================================================== Juggy Mortar Shell
GrenadeData JuggyMortarShell
{
   bulletShapeName    = "mortar.dts";
   explosionTag       = mortarExp;
   collideWithOwner   = True;
   ownerGraceMS       = 400;
   collisionRadius    = 1.0;
   mass               = 5.0;
   elasticity         = 0.1;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 1.32;
   damageType         = $MortarDamageType;

   explosionRadius    = 30.0;
   kickBackStrength   = 150.0;
   maxLevelFlightDist = 275;
   totalTime          = 30.0;
   liveTime           = 2.0;
   projSpecialTime    = 0.05;

   inheritedVelocityScale = 0.5;
   smokeName              = "mortartrail.dts";
};

//======================================================================== Mortar Bomber Shell
GrenadeData MortarBomberShell
{
   bulletShapeName    = "mortar.dts";
   explosionTag       = mortarExp;
   collideWithOwner   = True;
   ownerGraceMS       = 400;
   collisionRadius    = 1.0;
   mass               = 5.0;
   elasticity         = 0.1;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 1.32;
   damageType         = $MortarDamageType;

   explosionRadius    = 30.0;
   kickBackStrength   = 250.0;
   maxLevelFlightDist = 1;
   totalTime          = 1000.0;
   liveTime           = 2.0;
   projSpecialTime    = 0.05;

   inheritedVelocityScale = 0;
   smokeName              = "mortartrail.dts";
};

//======================================================================== EMP Mortar Shell
GrenadeData EMPMortar
{
	bulletShapeName    = "mortar.dts";
	explosionTag       = shockwave;
	collideWithOwner   = True;
	ownerGraceMS       = 250;
	collisionRadius    = 0.3;
	mass               = 0.01; //400;
	elasticity         = 0.01;

	damageClass        = 1;       // 0 impact, 1, radius
	damageValue        = 0.30;
	damageType         = $FlashDamageType;

	explosionRadius    = 35.0;
	kickBackStrength   = -10.0;
	maxLevelFlightDist = 275;
	totalTime          = 30.0;
	liveTime           = 2.0;
	projSpecialTime    = 0.01;
	lightRange       = 5.0;
	lightColor       = { 1.0, 0.7, 0.5 };
	inheritedVelocityScale = 0.5;
	smokeName        = "rsmoke.dts";

};

//======================================================================== EMP Shell
GrenadeData EMPShell
{
   bulletShapeName    = "mortar.dts";
   explosionTag       = Shockwave;
   collideWithOwner   = True;
   ownerGraceMS       = 250;
   collisionRadius    = 0.3;
   mass               = 0.01;
   elasticity         = 0.01;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 0.30;
   damageType         = $FlashDamageTurret;

   explosionRadius    = 30.0;
   kickBackStrength   = 0.0;
   maxLevelFlightDist = 1;
   totalTime          = 30.0;
   liveTime           = 0.01;
   projSpecialTime    = 0.01;

   inheritedVelocityScale = 0.01;
   smokeName              = "smoke.dts";
};

//======================================================================== Satchel Shell
GrenadeData SatchelShell
{
   bulletShapeName    = "grenade.dts";
   explosionTag       = rocketExp;
   collideWithOwner   = True;
   ownerGraceMS       = 250;
   collisionRadius    = 0.2;
   mass               = 1.0;
   elasticity         = 0.45;

   damageClass        = 1;       // 0 impact, 1, radius
   damageValue        = 1.6;
   damageType         = $DebrisDamageType;

   explosionRadius    = 25;
   kickBackStrength   = 250.0;
   maxLevelFlightDist = 1;
   totalTime          = 30.0;    // special meaning for grenades...
   liveTime           = 0.01;
   projSpecialTime    = 0.01;

   inheritedVelocityScale = 0.5;

   smokeName              = "smoke.dts";
};

//======================================================================== Bomber Shell
GrenadeData BomberShell
{
	bulletShapeName    = "mortar.dts";
	explosionTag       = grenadeExp;
	collideWithOwner   = True;
	ownerGraceMS       = 250;
	collisionRadius    = 0.2;
	mass               = 0.01;
	elasticity         = 0.45;
	damageClass        = 1; 
	damageValue        = 0.4;
	damageType         = $PlasmaDamageType;
	explosionRadius    = 15;
	kickBackStrength   = 1.0;
	maxLevelFlightDist = 150;
	totalTime          = 5.0;
	liveTime           = 5.0;
	projSpecialTime    = 0.05;
	inheritedVelocityScale = 0.5;
	smokeName              = "plasmatrail.dts";
};

function BomberShell::onAdd(%this)
{
	schedule("DeployBomblets(" @ %this @ " , 5);",1.0,%this);
}

//======================================================================== Volter Burst
GrenadeData FlameBurst 
{
    	explosionTag = plasmaExp;
 	collideWithOwner = True;
 	ownerGraceMS = 50;
 	collisionRadius = 10.0;
 	mass = 5.0;
 	elasticity = 0.1;
 	damageClass = 1;
 	damageValue = 0.30;
 	damageType = $ElectricityDamageType;
 	explosionRadius = 5.0;
 	kickBackStrength = 0.1;
 	maxLevelFlightDist = 75;
 	totalTime = 4.0;
 	liveTime = 0.02;
 	projSpecialTime = 0.01;
 	lightRange = 10.0;
	lightColor = { 1, 1, 0 }; 
 	inheritedVelocityScale = 1.5;
 	smokeName = "plasmatrail.dts";
 	soundId = SoundJetLight;
 };

//======================================================================== Fake Tactical Nuke Shell

GrenadeData FakeFgcShell
{
	bulletShapeName    = "breath.dts";
	explosionTag       = fakeExp;
	collideWithOwner   = True;
	ownerGraceMS       = 250;
	collisionRadius    = 0.3;
	mass               = 5.0;
	elasticity         = 0.1;

	damageClass        = 0;       // 0 impact, 1, radius
	damageValue        = 0.0;
	damageType         = $ShrapnelDamageType;

	explosionRadius    = 75.0;
	kickBackStrength   = 1.0;
	maxLevelFlightDist = 375;
	totalTime          = 29.0;
	liveTime           = 29.0;
	projSpecialTime    = 1.0;

	inheritedVelocityScale = 0.5;
	smokeName              = "breath.dts";
};

function FakeFgcShell::onAdd(%this)
{
	%player = FindProjectileFirer(%this,Mfgl);
	if(%player)
	{
		Player::incItemCount(%player,$WeaponAmmo[Mfgl],1);
		%nuker = MfglImage::onFire(%player,$WeaponSlot);
		if(%nuker)
		{
			GameBase::setPosition(%nuker,GameBase::getPosition(%this));
			GameBase::setPosition($Nuker[%nuker],GameBase::getPosition(%this));
		}
	}
	schedule("deleteObject("@%this@");",0.1);
}

//======================================================================== Tactical Nuke Shell

GrenadeData FgcShell
{
	bulletShapeName    = "mortar.dts";
	explosionTag       = LargeShockwave;
	collideWithOwner   = True;
	ownerGraceMS       = 250;
	collisionRadius    = 0.3;
	mass               = 5.0;
	elasticity         = 0.1;

	damageClass        = 1;       // 0 impact, 1, radius
	damageValue        = 2.5;
	damageType         = $ShrapnelDamageType;

	explosionRadius    = 75.0;
	kickBackStrength   = 1.0;
	maxLevelFlightDist = 375;
	totalTime          = 30.0;
	liveTime           = 30.0;
	projSpecialTime    = 0.01;

	inheritedVelocityScale = 0.5;
	smokeName              = "plasmatrail.dts";
};

function FgcShell::onAdd(%this)
{
	FgcShell::Deploy(%this);
	$nukecheck[%this] = 0;
}

function FgcShell::onRemove(%this)
{

}

function FgcShell::Deploy(%this)
{
	if(Grenade::isatRest(%this) || $nukecheck[%this] > 14) // (GameBase::isAtRest(%this))
	{
//		%this.deaddeploy = "";
		$pos[%this] = "";
		$nukecheck[%this] = "";
		//schedule("NuclearExplosion(" @ %this @ ");",2.0,%this);
		NuclearExplosion(%this);
	}
	else
	{
		$pos[%this] = GameBase::getPosition(%this);
		$nukecheck[%this]++;
		schedule("FgcShell::Deploy(" @ %this @ ");",2.0,%this);
	}
}

//======================================================================== Tactical Nuke Shell

GrenadeData FgcShell2
{
	bulletShapeName    = "mortar.dts";
	explosionTag       = LargeShockwave;
	collideWithOwner   = True;
	ownerGraceMS       = 250;
	collisionRadius    = 0.3;
	mass               = 5.0;
	elasticity         = 0.1;

	damageClass        = 1;       // 0 impact, 1, radius
	damageValue        = 2.5;
	damageType         = $ShrapnelDamageType;

	explosionRadius    = 75.0;
	kickBackStrength   = 1.0;
	maxLevelFlightDist = 375;
	totalTime          = 5.0;
	liveTime           = 5.0;
	projSpecialTime    = 0.01;

	inheritedVelocityScale = 0.5;
	smokeName              = "plasmatrail.dts";
};

function FgcShell2::onAdd(%this)
{
	FgcShell2::Deploy(%this);
}

function FgcShell2::Deploy(%this)
{
	if (GameBase::isAtRest(%this))
	{
		%this.deaddeploy = true;
		schedule("NuclearExplosion(" @ %this @ ");",3.0,%this);
	}
	else
	{
		schedule("FgcShell2::Deploy(" @ %this @ ");",3.0,%this);
	}
}

//======================================================================== Tactical Nuke Shell (fake, detonator)

GrenadeData FgcShell3
{
	bulletShapeName    = "breath.dts";
	explosionTag       = fakeExp;
	collideWithOwner   = True;
	ownerGraceMS       = 250;
	collisionRadius    = 0.3;
	mass               = 5.0;
	elasticity         = 0.1;

	damageClass        = 1;       // 0 impact, 1, radius
	damageValue        = 2.5;
	damageType         = $NukeDamageType;

	explosionRadius    = 5.0;
	kickBackStrength   = 1.0;
	maxLevelFlightDist = 375;
	totalTime          = 29.0;
	liveTime           = 3.0;
	projSpecialTime    = 0.1;

	inheritedVelocityScale = 0.5;
	smokeName              = "laserhit.dts";
};

function FgcShell3::onRemove(%this)
{
	NuclearExplosion($Nuker[%this]);
	$Nuker[%this] = 0;
}

//======================================================================== Phoenix Missile
GrenadeData PhoenixShell
{
	bulletShapeName    = "mortar.dts";
	explosionTag       = grenadeExp;
	collideWithOwner   = True;
	ownerGraceMS       = 250;
	collisionRadius    = 0.2;
	mass               = 0.01;
	elasticity         = 0.1;
	damageClass        = 1; 
	damageValue        = 0.55;
	damageType         = $PlasmaDamageType;
	explosionRadius    = 20;
	kickBackStrength   = 1.0;
	maxLevelFlightDist = 150;
	totalTime          = 5.0;
	liveTime           = 5.0;
	projSpecialTime    = 0.05;
	inheritedVelocityScale = 0.5;
	smokeName              = "plasmatrail.dts";
};

function PhoenixShell::onAdd(%this)
{
	schedule("DeployFrags(" @ %this @ " , 7);",1.0,%this);
}

//=======================================================================================================================
//						    Laser Class Ammos
//=======================================================================================================================

//======================================================================== LasCannon
LaserData GatlingLaser
{
	laserBitmapName   = "red_blink4.bmp";//"chainflash1.bmp";//"pulse05.bmp";//"lightningNew.bmp";
	hitName           = "laserhit.dts";//"shield.dts";
	damageConversion  = 0.10;
	baseDamageType    = $LaserDamageType;
	beamTime          = 2.5;
	lightRange        = 5.0;
	lightColor        = { 1.25, 0.01, 0.01 };
	detachFromShooter = true;
	hitSoundId        = SoundLaserHit;
};

//======================================================================== Laser Turret Beam
LaserData sniperLaser
{
   laserBitmapName   = "shotgunbolt.bmp";//"lightningNew.bmp";
   hitName           = "laserhit.dts";

   damageConversion  = 0.01;
   baseDamageType    = $LaserDamageTurret;

   beamTime          = 0.5;

   lightRange        = 2.0;
   lightColor        = { 1.0, 0.25, 0.25 };

   detachFromShooter = false;
   hitSoundId        = SoundLaserHit;
};

//======================================================================== Sniper Rifle Laser
LaserData sniperRLaser
{
   laserBitmapName   = "blue_blink4.bmp";//"bar16.bmp";
   hitName           = "laserhit.dts";

   damageConversion  = 0.016;
   baseDamageType    = $LaserDamageType;

   beamTime          = 0.5;

   lightRange        = 2.0;
   lightColor        = { 0.50, 0.50, 1.0 };

   detachFromShooter = false;
   hitSoundId        = SoundLaserHit;
};

//======================================================================== Targeting Laser
TargetLaserData targetLaser
{
   laserBitmapName   = "paintPulse.bmp";
   damageConversion  = 0.0;
   baseDamageType    = $TargetingDamageType;
   lightRange        = 2.0;
   lightColor        = { 0.25, 1.0, 0.25 };
   detachFromShooter = false;
};

//=======================================================================================================================
//						    Lightining Class Ammos
//=======================================================================================================================


//======================================================================== Lightning Charge

LightningData lightningCharge
{
   bitmapName       = "lightningNew.bmp";

   damageType       = $ElectricityDamageType;
   boltLength       = 40.0;
   coneAngle        = 35.0;
   damagePerSec      = 0.18;
   energyDrainPerSec = 80.0;  //60
   segmentDivisions = 4;
   numSegments      = 5;
   beamWidth        = 0.125;

   updateTime   = 120;
   skipPercent  = 0.5;
   displaceBias = 0.15;

   lightRange = 3.0;
   lightColor = { 0.25, 0.25, 0.85 };

   soundId = SoundELFFire;
};

function lightningCharge::damageTarget(%target, %timeSlice, %damPerSec, %enDrainPerSec, %pos, %vec, %mom, %shooterId)
{
	//=== For refference, %timeSlice is usually 0.032, meaning the game checks this function once every
	//===  32/1000ths of a second.  You can adjust the values above and get the desired results below
	%player = Client::getControlObject(%shooterId);
	%energy = GameBase::getEnergy(%target);
	%enDrain = %enDrainPerSec * %timeSlice;
	%energy -= %enDrain; //used to be 2.24
	if (%energy < 0)
		%energy = 0;
	else
		GameBase::setEnergy(%player, GameBase::getEnergy(%player) + %enDrain);
	GameBase::setEnergy(%target, %energy);

	%damage = %damPerSec * %timeSlice; //used to be 0.005
	if(%energy > 0 || $ArmorName[Player::getArmor(%player)] != "AlArmor")
		GameBase::applyDamage(%target, $ElectricityDamageType, %damage, %pos, %vec, %mom, %shooterId);
	else
		GameBase::applyDamage(%target, $FlashDamageType, %damage, %pos, %vec, %mom, %shooterId);
}

//========================================================================  Lightning Charge1
LightningData lightningCharge1
{
   bitmapName       = "trailadd2.bmp"; //"lightningNew.bmp";

   damageType       = $FlashDamageType;
   boltLength       = 40.0;
   coneAngle        = 35.0;
   damagePerSec      = 0.10;
   energyDrainPerSec = 60.0;
   segmentDivisions = 4;
   numSegments      = 5;
   beamWidth        = 0.125;

   updateTime   = 120;
   skipPercent  = 0.5;
   displaceBias = 0.15;

   lightRange = 3.0;
   lightColor = { 0.25, 0.1, 0.85 };

   soundId = SoundELFFire;
};

function lightningCharge1::damageTarget(%target, %timeSlice, %damPerSec, %enDrainPerSec, %pos, %vec, %mom, %shooterId)
{
	GameBase::applyDamage(%target, $FlashDamageType, %timeSlice * %damPerSec, %pos, %vec, %mom, %shooterId);
	%energy = GameBase::getEnergyLevel(%target) - (%enDrainPerSec * %timeSlice);
	if(%energy < 0)
		%energy = 0;
	GameBase::SetEnergyLevel(%target,%energy);
}

//========================================================================  Lightning Charge2
LightningData lightningCharge2
{
   bitmapName       = "lightningNew.bmp";

   damageType       = $ElectricityDamageType;
   boltLength       = 40.0;
   coneAngle        = 35.0;
   damagePerSec      = 0.22;
   energyDrainPerSec = 100.0;
   segmentDivisions = 4;
   numSegments      = 5;
   beamWidth        = 0.125;//075;

   updateTime   = 120;
   skipPercent  = 0.5;
   displaceBias = 0.15;

   lightRange = 3.0;
   lightColor = { 0.25, 0.25, 0.85 };

   soundId = SoundELFFire;
};

//======================================================================== 

LightningData turretCharge
{
   bitmapName       = "lightningNew.bmp";

   damageType       = $ElectricityDamageTurret;
   boltLength       = 40.0;
   coneAngle        = 35.0;
   damagePerSec      = 0.1;
   energyDrainPerSec = 140.0;  //60
   segmentDivisions = 4;
   numSegments      = 5;
   beamWidth        = 0.125;

   updateTime   = 120;
   skipPercent  = 0.5;
   displaceBias = 0.15;

   lightRange = 3.0;
   lightColor = { 0.25, 0.25, 0.85 };

   soundId = SoundELFFire;
};

//======================================================================== Grav Charge
LightningData gravCharge
{
   bitmapName       = "repairadd.bmp";

   damageType       = $GravDamageType;
   boltLength       = 100.0;
   coneAngle        = 40.0;
   damagePerSec      = 0.01;
   energyDrainPerSec = 1.0;
   segmentDivisions = 2;
   numSegments      = 1;
   beamWidth        = 0.5;

   updateTime   = 120;
   skipPercent  = 0.1;
   displaceBias = 0.35;

   lightRange = 3.0;
   lightColor = { 0.85, 0.15, 0.15 };

   soundId = SoundELFFire;
};

function gravCharge::damageTarget(%target, %timeSlice, %damPerSec, %enDrainPerSec, %pos, %vec, %mom, %shooterId)
{
	%playerId = %shooterId;
	if(%playerId.possessing)
		%playerId = %playerId.poss;
	if(%playerId.GravBolt == "2")
	{
		%velocity = 25;
		%ppos = GameBase::getPosition(%playerId);
		%tpos = GameBase::getPosition(%target);
		%dpos = Vector::Sub(%ppos,%tpos);
		%Vsq = %velocity * %velocity;
		%Vecsq = (GetWord(%dpos,0) * GetWord(%dpos,0)) + (GetWord(%dpos,1) * GetWord(%dpos,1)) + (GetWord(%dpos,2) * GetWord(%dpos,2));
		%vdif = (sqrt(%Vsq / %Vecsq) * -1);
		%diffVector = GetWord(%dpos,0) * %vdif @ " " @ GetWord(%dpos,1) * %vdif @ " " @ GetWord(%dpos,2) * %vdif;

		if(%playerId.GravADV == "0")
		{
			Item::setVelocity(%playerID, %diffVector); //the actual movement function
		}
		else
		{
			Player::applyImpulse(%playerId, %diffVector);
		}	 
	}
	else if (%playerId.GravBolt == "0")
	{
		%Rotation = GameBase::GetRotation(Client::getOwnedObject(%playerId)); 
		%Zvalue = %Rotation;
		%velocity = -25;
		if(%playerId.GravADV == "0")
		{
			%shooterDir = Vector::getFromRot(GameBase::getRotation(%playerId),%velocity,%Zvalue);
		}
		else
		{
			%velocity = -35;
			%ppos = GameBase::getPosition(%playerId);
			%tpos = GameBase::getPosition(%target);
			%dpos = Vector::Sub(%ppos,%tpos);
			%Vsq = %velocity * %velocity;
			%Vecsq = (GetWord(%dpos,0) * GetWord(%dpos,0)) + (GetWord(%dpos,1) * GetWord(%dpos,1)) + (GetWord(%dpos,2) * GetWord(%dpos,2));
			%vdif = sqrt(%Vsq / %Vecsq);
			%shooterDir = GetWord(%dpos,0) * %vdif @ " " @ GetWord(%dpos,1) * %vdif @ " " @ GetWord(%dpos,2) * %vdif;
		}
		if(getObjectType(%target) == "Player")			
			Player::applyImpulse(%target, %shooterDir);
//		else
//			Item::setVelocity(%target, Vector::Add(Item::getVelocity(%target), Vector::Scale(%shooterDir,GameBase::getDataName(%target).mass / 50)));

		%damVal = %timeSlice * %damPerSec;
		%enVal  = %timeSlice * %enDrainPerSec;
		if(GameBase::getTeam(%target) != Gamebase::getTeam(%shooterId))
		{
			GameBase::applyDamage(%target, $ElectricityDamageType, %damVal, %pos, %vec, %mom, %shooterId);
			Shifter_startGravTracker(%target,%shooterId,%timeSlice);
		}
	}
	else
	{
		%Rotation = GameBase::GetRotation(Client::getOwnedObject(%playerId)); 
		%Zvalue = %Rotation;
		%velocity = 25;
		if(%playerId.GravADV == "0")
		{
			%shooterDir = Vector::getFromRot(GameBase::getRotation(%playerId),%velocity,%Zvalue);
			%vec=Vector::getFromRot(%rot,%len*%mass,%zlen*%mass);
			Player::applyImpulse(%obj,%vec);
		}
		else
		{
			%velocity = 45;
			%ppos = GameBase::getPosition(%playerId);
			%tpos = GameBase::getPosition(%target);
			%dpos = Vector::Sub(%ppos,%tpos);
			%Vsq = %velocity * %velocity;
			%Vecsq = (GetWord(%dpos,0) * GetWord(%dpos,0)) + (GetWord(%dpos,1) * GetWord(%dpos,1)) + (GetWord(%dpos,2) * GetWord(%dpos,2));
			%vdif = (sqrt(%Vsq / %Vecsq) * -1);
			%shooterDir = GetWord(%dpos,0) * %vdif @ " " @ GetWord(%dpos,1) * %vdif @ " " @ GetWord(%dpos,2) * %vdif;
		}				
		if(getObjectType(%target) == "Player")		
			Player::applyImpulse(%target, %shooterDir);
//		else
//			Item::setVelocity(%target, Vector::Add(Item::getVelocity(%target), Vector::Scale(%shooterDir,GameBase::getDataName(%target).mass / 50)));

		%damVal = %timeSlice * %damPerSec;
		%enVal  = %timeSlice * %enDrainPerSec;
		if(GameBase::getTeam(%target) != Gamebase::getTeam(%shooterId))
		{
			GameBase::applyDamage(%target, $ElectricityDamageType, %damVal, %pos, %vec, %mom, %shooterId);
			Shifter_startGravTracker(%target,%shooterId,%timeSlice);
		}
	}
}

function Lightning::damageTarget(%target, %timeSlice, %damPerSec, %enDrainPerSec, %pos, %vec, %mom, %shooterId)
{
   %damVal = %timeSlice * %damPerSec;
   %enVal  = %timeSlice * %enDrainPerSec;

   GameBase::applyDamage(%target, $ElectricityDamageType, %damVal, %pos, %vec, %mom, %shooterId);

   %energy = GameBase::getEnergy(%target);
   %energy = %energy - %enVal;
   if (%energy < 0) {
      %energy = 0;
   }
   GameBase::setEnergy(%target, %energy);
}

//=======================================================================================================================
//						    Repair Class Ammos
//=======================================================================================================================

//======================================================================== 
RepairEffectData RepairBolt
{
   bitmapName       = "repairadd.bmp";
   boltLength       = 10.0;
   segmentDivisions = 4;
   beamWidth        = 0.125;

   updateTime   = 450;
   skipPercent  = 0.6;
   displaceBias = 0.15;

   lightRange = 3.0;
   lightColor = { 0.85, 0.25, 0.25 };
};

function RepairBolt::onAcquire(%this, %player, %target)
{
	%client = Player::getClient(%player);

	if (%target == %player)
	{
	   %player.repairTarget = -1;
		if (GameBase::getDamageLevel(%player) != 0)
		{
			%player.repairRate = 0.05;
			%player.repairTarget = %player;
			Client::sendMessage(%client, 0, "AutoRepair On");
		}
		else
		{
			Client::sendMessage(%client,0,"Nothing in range");
			Player::trigger(%player, $WeaponSlot, false);
			return;
		}
	}
	else
	{
        %player.repairTarget = %target;
		%player.repairRate   = 0.1;
		
		if (getObjectType(%player.repairTarget) == "Player")
		{
			%rclient = Player::getClient(%player.repairTarget);
			%name = Client::getName(%rclient);
		}
		else
		{ 
			%name = GameBase::getMapName(%target);
			if(%name == "") 
			{
				%name = (GameBase::getDataName(%player.repairTarget)).description;
			}
		}
		
		if (GameBase::getDamageLevel(%player.repairTarget) == 0) 
		{
			Client::sendMessage(%client,0,%name @ " is not damaged");
			Player::trigger(%player,$WeaponSlot,false);
			%player.repairTarget = -1;
			return;
		}
		
		if (getObjectType(%player.repairTarget) == "Player") 
		{
			Client::sendMessage(%rclient,0,"Being repaired by " @ Client::getName(%client));
		}
		
		Client::sendMessage(%client,0,"Repairing " @ %name);
		
		$PlayerRepairing[%player] = "True";												//=== Player Is Repairing
		$PlayerRepairTar[%player] = (GameBase::getDamageLevel(%player.repairTarget));   //=== Amount Of Damage Starting

		//echo ("***  Repair Progress Started " @ $PlayerRepairing[%player] @ " Starting Damage Level = " @ $PlayerRepairTar[%player]);
	}

	if(GameBase::getDataName(%player.repairTarget).maxDamage >= 35)
		%player.repairRate = (GameBase::getDataName(%player.repairTarget).maxDamage)/30;
	%rate = GameBase::getAutoRepairRate(%player.repairTarget) + %player.repairRate;
	GameBase::setAutoRepairRate(%player.repairTarget,%rate);
}

function RepairBolt::onRelease(%this, %player)
{
	%client = Player::getClient(%player);

	$PlayerRepairing[%player] = "False";
	//echo ("***  Repair Progress Stopped " @ $PlayerRepairing[%player]);
	%object = %player.repairTarget;
	if (%object != -1)
	{
		%client = Player::getClient(%player);
		if (%object == %player)
		{
			Client::sendMessage(%client,0,"AutoRepair Off");
		}
		else
		{
			if (GameBase::getDamageLevel(%object) == 0)
			{
				Client::sendMessage(%client,0,"Repair Done");
			}
			else
			{
				Client::sendMessage(%client,0,"Repair Stopped");
			}
		}
		%rate = GameBase::getAutoRepairRate(%object) - %player.repairRate;
        if (%rate < 0)
      		%rate = 0;
      
		GameBase::setAutoRepairRate(%object,%rate);
	}
}

function RepairBolt::checkDone(%this, %player)
{
	%client = Player::getClient(%player);
	if (Player::isTriggered(%player,$WeaponSlot) && (Player::getMountedItem(%player,$WeaponSlot) == RepairGun || Player::getMountedItem(%player,$WeaponSlot) == FixIt) && %target != -1)
	{
		%object = %player.repairTarget;
		
		if (%object == %player)
		{
			if (GameBase::getDamageLevel(%player) == 0)
			{
				//echo ("Repair Stopped - Done");
				$PlayerRepairing[%player] = "False";
				Player::trigger(%player,$WeaponSlot,false);
				return;
			}
		}
		else
		{
			if (GameBase::getDamageLevel(%object) == 0)
			{
				if ($PlayerRepairing[%player] = True)
				{
						%objname = (GameBase::getDataName(%object)).description;
					
					%objectTeam = GameBase::getTeam(%object);								//=== Team Object.
					%playerTeam = GameBase::getTeam(%player); 								//=== Team Player.
					%lastdamage = GameBase::getControlClient(%object.lastDamageObject);	

					if (%objname == "Remote Mortar Turret")				%pntval = $Score::ObjTurretS;
					else if (%objname == "Remote Ion Turret")			%pntval = $Score::ObjTurretS;
					else if (%objname == "Remote Turret")				%pntval = $Score::ObjTurretS;
					else if (%objname == "Remote Laser Turret")			%pntval = $Score::ObjTurretS;
					else if (%objname == "Point Defense Laser Mine")		%pntval = $Score::ObjTurretS;
					else if (%objname == "EMP Turret")				%pntval = $Score::ObjTurretS;
					else if (%objname == "ELF Turret")				%pntval = $Score::ObjTurretS;
					else if (%objname == "Remote Rocket")				%pntval = $Score::ObjTurretS;
					else if (%objname == "Camera")					%pntval = $Score::ObjTurretS;
					else if (%objname == "Large Pulse Sensor")			%pntval = $Score::ObjSensorL;
					else if (%objname == "Medium Pulse Sensor")			%pntval = $Score::ObjSensorL;
					else if (%objname == "Motion Sensor")				%pntval = $Score::ObjSensorS;
					else if (%objname == "Remote Pulse Sensor")			%pntval = $Score::ObjSensorS;
					else if (%objname == "Remote Sensor Jammer")			%pntval = $Score::ObjSensorS;		
					else if (%objname == "Generator")				%pntval = $Score::ObjGeneratorB;
					else if (%objname == "Solar Panel")				%pntval = $Score::ObjGeneratorS;
					else if (%objname == "Portable Generator")			%pntval = $Score::ObjGeneratorS;		
					else if (%objname == "Ammo Supply Unit")	   		%pntval = $Score::ObjStationA;
					else if (%objname == "Station Supply Unit")			%pntval = $Score::ObjStationS;
					else if (%objname == "Command Station")				%pntval = $Score::ObjStationA;
					else if (%objname == "Remote Ammo Unit")			%pntval = $Score::ObjStationR;
					else if (%objname == "Remote Inv Unit")				%pntval = $Score::ObjStationR;
					else if (%objname == "Remote Command Station")			%pntval = $Score::ObjStationR;
					else if (%objname == "Station Vehicle Unit")			%pntval = $Score::ObjFlier;
					else if (%objname == "Vehicle Pad")				%pntval = $Score::ObjFlier;					

					%bonus = (floor($PlayerRepairTar[%player] * %pntval));
					%score = ($Score::RepairObject + %bonus);
					%lastdamage = $lastdamageobj[%object];
					%lastdpl = GameBase::getControlClient(%object.lastDamageObject);
					%objname = GameBase::getMapName(%object);
					if(%objname == "") 
						%objname = (GameBase::getDataName(%object)).description;					

					if (%lastdpl == %client)
					{
							if ((%objectteam == %playerteam || %objectteam == "-1") && (%object.lastDamageTeam == %playerTeam))
							{
								if ($ScoreOn) bottomprint(%client, "No points awarded, you were the last damager.");						
							}
							else if (%objectteam != %playerTeam)
							{
								%client.score = (%client.score - %score);
								if ($ScoreOn) bottomprint(%client, "You Repaired The Enemys Stuff. Score -" @ %score @ " = " @ %client.score @ " Total Score. You Dumb Ass.");
							}
							else if (%this.lastDamageTeam != %playerTeam)
							{
								%client.score = (%client.score + %score);
								if ($ScoreOn) bottomprint(%client, "Repairing Damage Score +" @ %score @ " = " @ %client.score @ " Total Score");
							}
					}
					else
					{
						if (%objectteam != %playerTeam)
						{
							%client.score = (%client.score - %score);
							if ($ScoreOn) bottomprint(%client, "You Repaired The Enemys Stuff. Score -" @ %score @ " = " @ %client.score @ " Total Score. You Dumb Ass.");
						}
						else
						{
							%client.score = (%client.score + %score);
							if ($ScoreOn) bottomprint(%client, "Repairing Damage Score +" @ %score @ " = " @ %client.score @ " Total Score");
						}
					}
						
					$PlayerRepairing[%player] = "False";
					Game::refreshClientScore(%client);

				}
				Player::trigger(%player,$WeaponSlot,false);
				return;
			}
		}
	}
}

//------------------------------------------------------------------------------------------------
// Power Beam -- For the Power Gun.  Hooray for Engineers
//------------------------------------------------------------------------------------------------
RepairEffectData PowerBolt
{
   bitmapName       = "trailadd2.bmp";
   boltLength       = 20.0;
   segmentDivisions = 4;
   beamWidth        = 0.3;

   updateTime   = 450;
   skipPercent  = 0.6;
   displaceBias = 0.25;

   lightRange = 3.0;
   lightColor = { 0.25, 0.25, 0.85 };

   soundId = SoundELFFire;
};

function PowerBolt::onAcquire(%this, %player, %target)
{
	if(%target != -1 && %target != %player)
	{
		%shape = (GameBase::getDataName(%target)).shapeFile;
		if(%shape == inventory_sta || %shape == cmdpnl || %shape == ammounit)
		{
			if(GameBase::getTeam(%target) == GameBase::getTeam(%player))
			{
				if(GameBase::isPowered(%target) || %target.poweron == "True")
				{
					Client::sendMessage(Player::getClient(%player),1,"Error - Target is already powered.~waccess_denied.wav");
				}
				else
				{
					Client::sendMessage(Player::getClient(%player),0,"Charging station...");
					%player.PowerTime = getSimTime() + 5;
					%player.PowerTarget = %target;
					return;
				}
			}
			else
				Client::sendMessage(Player::getClient(%player),1,"Error - Wrong Team~waccess_denied.wav");
		}
		else
		{
			Client::sendMessage(Player::getClient(%player),1,"Error - This object cannot be externally powered.~waccess_denied.wav");
		}

		%player.PowerTarget = -1;	
	}
	else
		Client::sendMessage(Player::getClient(%player),1,"No targets within range, aborting.");
		
	Player::trigger(%player,$WeaponSlot,false);
}

function PowerBolt::onRelease(%this,%player)
{
	%player.PowerTarget = -1;
	%player.PowerTime = "";
}

function PowerBolt::CheckDone(%this,%player)
{
	if(getSimTime() >= %player.PowerTime)
	{
		%target = %player.PowerTarget;
		if(%target != -1)
			%shape = (GameBase::getDataName(%target)).shapeFile;
		if(%shape == inventory_sta || %shape == cmdpnl || %shape == ammounit)
		{
			if(GameBase::getTeam(%target) == GameBase::getTeam(%player))
			{
				if(GameBase::isPowered(%target) || %target.poweron == "True")
				{
					Client::sendMessage(Player::getClient(%player),1,"Error - Target is already powered.~waccess_denied.wav");
				}
				else
				{
					%rate = GameBase::getRechargeRate(%player);
						if(%rate <= 0) %rate = 1;
	
					%time = GameBase::getEnergy(%player) / %rate;
					%time *= 2;
					Client::sendMessage(Player::getClient(%player),0,"...completed.  Station will be charged for the next "@ floor(%time+0.5) @" seconds.");
					GameBase::setEnergy(%player,0);
					%target.poweron = "True";
					GameBase::playSequence(%target,0,"power");
					GameBase::playSequence(%target,1);
					schedule ("StopTempPower(" @ %target @ ");",%time);
				}
			}
			else
				Client::sendMessage(Player::getClient(%player),1,"Error - Wrong Team~waccess_denied.wav");
		}
		else if(%target != -1)
			Client::sendMessage(Player::getClient(%player),1,"Error - This object cannot be externally powered.~waccess_denied.wav");
	
		Player::trigger(%player,$WeaponSlot,False);
	}
}

//------------------------------------------------------------------------------------------------
// Hack Gun Beam Used this from the RSP - Is now alternate weapon setting for EngRepairGun
//------------------------------------------------------------------------------------------------
RepairEffectData HackBolt
{
   bitmapName       = "lightningNewSub.bmp"; //"lightningNew.bmp";
   boltLength       = 10.0;
   segmentDivisions = 4;
   beamWidth        = 0.35; //0.2;

   updateTime   = 450;
   skipPercent  = 0.6;
   displaceBias = 0.15;

   lightRange = 3.0;
   lightColor = { 1.25, 0.25, 0.15}; //{ 0.25, 0.25, 0.85 };

   soundId = SoundELFFire;
};

function HackBolt::onRelease(%this, %player)
{
	%client = Player::getClient(%player);	
	$hacking[%client] = "false";
	if ($debug) echo ("STOPPED " @ %client);
}

function HackBolt::onAcquire(%this, %player, %target)
{
	%client = Player::getClient(%player);
	%data = GameBase::getDataName(%target);
	%shape = %data.shapeFile;
	%name = GameBase::getMapName(%target);

	if($Shifter::AllowHacking || (%name == False && %shape == "magcargo") || String::findSubStr(%name,"SatchelPack") != -1)
	{
		if (%target != %player)
		{
			%player.repairTarget = %target;
			%name = GameBase::getMapName(%target);
			%type = getObjectType(%target);
			%data = GameBase::getDataName(%target);
			%team = GameBase::getTeam(%target);
			%pTeam = GameBase::getTeam(%player);
			%pName = Client::getName(%client);
			%tName = getTeamName(%team);
if($debug) echo ("basep 1");
			if(%name == "" || %name == False)
			{
				%name = %data.description;
			}
	
if($debug) echo ("basep 2");
	
			if(%team == %pTeam)
			{
				//echo ("Infecting");
				
				if (%target.infected == "true")
				{
					Client::sendMessage(%client,0," Your team's " @ %name @ " is already protected from hacking.");	
					return;
				}
				else if(!checkHackable(%name, %shape) && %type != "Player")
				{
					$hacking[%client] = "true";
				//echo ("Orgin Team = " @ $origTeam[%target]);
					if($origTeam[%target] == "")
					{
				//echo ("No original team set. Marking.");
						$origTeam[%target] = %team;
						if(%target < $minHacked || $minHacked == -1)
							$minHacked = %target;
						if(%target > $maxHacked || $maxHacked == -1)
							$maxHacked = %target;

						$hackedobj[$hackedobjs] = %target;
						$hackedobjs++;
					}
					
					Client::sendMessage(%client,0,"Infecting " @ %name @ ". Please wait...");
					
					hackingItem(%target, %pTeam, %pName, %tName, %name, %team, $Shifter::HackTime, %client);
					return;
				}
				return;
			}
if($debug) echo ("basep 3");
				
			if((checkHackable(%name, %shape) || (%type == "Player" && !Player::isAIControlled(%target))) && %data.className != "mine" && %data.className != "Mine")
			{
				if(%type == "Player")
				{
					Client::sendMessage(%client,0,"You can not hack another player.");
				}
				else
				{
					Client::sendMessage(%client,0,"It is not possible to hack in to a " @ %name);
					Player::trigger(%player,$Weaponslot,false);
					return;
				}
			}
			else
			{
if($debug) echo ("basep 4");
				if(%name == "False" && %shape == "magcargo")
				{
					Client::sendMessage(%client,0,"Disarming the Nuke Pack. Please wait...");
				}
				else if(String::findSubStr(%name,"SatchelPack") != -1)
				{
					Client::sendMessage(%client,0,"Disarming the Satchel Charge. Please wait...");
				}
				else
				{
					Client::sendMessage(%client,0,"Hacking " @ %name @ ". Please wait...");
				}

				$hacking[%client] = "true";
if($debug) echo ("basep 5");
				
				if ($debug) echo ("Orgin Team = " @ $origTeam[%target]);
				if($origTeam[%target] == "")
				{
					if ($debug) echo ("No original team set. Marking.");
					$origTeam[%target] = %team;
					if(%target < $minHacked || $minHacked == -1)
						$minHacked = %target;
					if(%target > $maxHacked || $maxHacked == -1)
						$maxHacked = %target;
				}
				
if($debug) echo ("basep 6");
				
				hackingItem(%target, %pTeam, %pName, %tName, %name, %team, $Shifter::HackTime, %client);
			}
		}	
	}
	else
	{
		Client::sendMessage(%client,0,"Hacking/Infecting disabled on this server");
	}
}

// Drain Bolt - Same as Repair, But drains, used with regeneration pack and Eng option for Eng Gun
//------------------------------------------------------------------------------------------------------------------------

RepairEffectData DrainBolt
{
   bitmapName       = "repairadd.bmp";
   boltLength       = 25.0;
   segmentDivisions = 2;
   beamWidth        = 0.525;

   updateTime   = 450;
   skipPercent  = 0.6;
   displaceBias = 0.15;

   lightRange = 3.0;
   lightColor = { 0.25, 0.25, 1.95 };
};

function DrainBolt::onAcquire(%this, %player, %target)
{
	%client = Player::getClient(%player);
	%shape = ((GameBase::getDataName(%target)).shapeFile);

	if ($debug) echo ("Shape Drained = " @ %shape);
	
	if (%target == %player)
	{	
		%player.drainTarget = -1;
		
		if (GameBase::getDamageLevel(%player) == 0)
		{
			Client::sendMessage(%client,0,"You are not damaged, can not drain!");
			Player::trigger(%player, $WeaponSlot, false);
			return;
		}
		else
		{
			Client::sendMessage(%client,0,"Must find powered object to drain!");
			Player::trigger(%player, $WeaponSlot, false);
			return;
		}	   	
	}
	else
	{
     		%player.drainTarget = %target;

		if (gamebase::Getteam(%player) != gamebase::Getteam(%target)) // && gamebase::getteam(%target) != "-1")
		{
			//============================================================= Get Name Of Object Or Player Being Drained
			if (getObjectType(%player.drainTarget) == "Player")
			{
				%rclient = Player::getClient(%player.drainTarget);
				%name = Client::getName(%rclient);
			}
			else
			{
				%name = GameBase::getMapName(%target);
				if(%name == "") 
				{
					%name = (GameBase::getDataName(%player.drainTarget)).description;
				}
			}

			//============================================================= Get Damage Level Of Object

			//echo ("Drain Target  " @ %target);
			//echo ("Target Damage " @ (GameBase::getDataName(%target)).maxDamage);

			if (GameBase::getDamageLevel(%player.drainTarget) < (GameBase::getDataName(%target)).maxDamage)
			{
				Client::sendMessage(%client,0,%name @ " being drained!");
				Player::trigger(%player,$WeaponSlot,true);
			}
			else
			{
				Client::sendMessage(%client,0,%name @ " has no energy to drain!!!");
				Player::trigger(%player,$WeaponSlot,false);
				return;
			}

			if (getObjectType(%player.drainTarget) == "Player") 
			{
				Client::sendMessage(%rclient,0,"Being drained by " @ Client::getName(%client));
			}

			Client::sendMessage(%client,0,"Draining " @ %name);

			$PlayerDraining[%player] = "True";						//=== Player Is Repairing
			$PlayerRepairTar[%player] = (GameBase::getDamageLevel(%player.drainTarget));   //=== Amount Of Damage Starting

			if ($Debug) echo ("***  Drain Progress Started " @ $PlayerDraining[%player] @ " Starting Damage Level = " @ $PlayerRepairTar[%player]);
		}
		else if (gamebase::getteam(%player) == gamebase::getteam(%target))
		{
			%player.powerTarget = %target;
			%player.powertime = ($Shifter::HackTime);
			%objType = getObjectType(%target); 
			%obj = GameBase::getDataName(%target);
			%shape = (GameBase::getDataName(%target)).shapeFile;
			%class = (GameBase::getDataName(%target)).className;
			if(%objType == "Player") 
			{
				if(%target == %player) 
				{ 
					Client::sendMessage(%client,0,"Nothing to power in range"); 
					Player::trigger(%player, $WeaponSlot, false); 
					return; 
				}
				%tc = Player::getClient(%target); 
				%armor = Player::getArmor(%target);
				%maxen = %armor.maxEnergy;
				%energy = Gamebase::getEnergy(%tc);

				if($emptime[%tc] > 2)
				{
					Client::sendMessage(%client,1, "Charging " @ Client::getName(%tc)); 
					Client::sendMessage(%tc,1, "You are being charged by " @ Client::getName(%client));
				}
				else if (%target.shieldStrength < 0.025 && !%target.shieldon)
				{
					Client::sendMessage(%client,1, "Shielding " @ Client::getName(%tc)); 
					Client::sendMessage(%tc,1, "Receiving shielding from " @ Client::getName(%client)); 
				} 
				else
				{
					Client::sendMessage(%client,1, "Powering " @ Client::getName(%tc)); 
					Client::sendMessage(%tc,1, "Receiving power from " @ Client::getName(%client)); 
				}
			}
			else if(%objType == "Flier")
			{
				Client::sendMessage(%client,0, "Shielding " @ $VehicleToItem[GameBase::getDataName(%target)].description); 
			}
			if(%shape == inventory_sta || %shape == cmdpnl || %shape == ammounit) //(%obj == "InventoryStation" || %obj == "AmmoStation" || %obj == "CommandStation") 
			{ 						
				Client::sendMessage(%client,0, "Powering " @ %obj.description); 
			}			
			if(%obj == "PlasmaTurret" || %obj == "ELFTurret" || %obj == "RocketTurret" || %obj == "IndoorTurret" || %obj == "PulseSensor" || %obj == "MediumPulseSensor" || %obj == "MortarTurret" || %shape == "remoteturret" || %shape == "mortar_turret" || %shape == "hellfiregun" || %shape == "indoorgun" || %shape == "chainturret") 
			{ 
				Client::sendMessage(%client,1, "Upgrading Shielding on " @ %obj.description); 
			}
			else if(%class == "Generator" || %class == "Turret")
			{
				Client::sendMessage(%client,1, "Adding Shielding to " @ %obj.description);
			} 				
		}
	}
}


function DrainBolt::checkDone(%this, %player)
{
	%client = Player::getClient(%player);
	%object = %player.drainTarget;
	%target = %player.drainTarget;
	
	if ($Debug) echo ("*** Checking Drain Progress " @ $PlayerDraining[%player] @ " -> " @ %target);

	if (Player::isTriggered(%player,$WeaponSlot) && (Player::getMountedItem(%player,$WeaponSlot) == Regen) && %target != -1)
	{
		
		//======================================================================================= USED AGAINST NME
		if (gamebase::Getteam(%player) != gamebase::Getteam(%object)) // && gamebase::getteam(%object) != "-1")
		{
			if (%object == %player)
			{
				if (GameBase::getDamageLevel(%player) >= (GameBase::getDataName(%object)).maxDamage)
				{
					$PlayerDraining[%player] = "False";
					Player::trigger(%player,$WeaponSlot,false);
					return;
				}
			}
			else
			{
				if (GameBase::getDamageLevel(%object) < (GameBase::getDataName(%object)).maxDamage)
				{
					if ($PlayerDraining[%player] = True)
					{
						%damage = (GameBase::getDataName(%object)).maxDamage / 20;
						if((GameBase::getDataName(%object)).maxDamage < 35 || ($Shifter::RegenFix == "false" && $MatchConfig != true))
						{
							GameBase::applyDamage(%object,$FlashDamageType, %damage,GameBase::getPosition(%player),"0 0 0","0 0 0",%player);
						}
						//=== We'll do both, so the player gets instant health AND a delayed healing effect
						GameBase::repairDamage(%player,(%damage / 30));
						%level = GameBase::getDamageLevel(%player) - (%damage/30);
						if(%level < 0)
							%level = 0;
						GameBase::setDamageLevel(%player,%level);
					}
					Player::trigger(%player,$WeaponSlot,true);
				}
			}
		}
		//======================================================================================= USED ON TEAM
		else if (gamebase::getteam(%player) == gamebase::getteam(%object))
		{	
			if(%player.powertime > 0)
			{
				if(%player.powerTarget)
				{		
					%player.powertime--;
					return;
				}
			}
			else if ((%player.powertime < 0 || %player.powertime == 0) && %player.powerTarget)
			{
				%target = %player.powerTarget;
				%objType = getObjectType(%target); 
				%obj = GameBase::getDataName(%target);
				%shape = (GameBase::getDataName(%target)).shapeFile;
				%class = (GameBase::getDataName(%target)).className; 
				
				if(%objType == "Player") 
				{
					if(%target == %player) 
					{ 
						Client::sendMessage(%client,0,"Nothing to power in range"); 
						Player::trigger(%player, $WeaponSlot, false); 
						return; 
					}

					%tc = Player::getClient(%target); 
					%armor = Player::getArmor(%target);
					%maxen = %armor.maxEnergy;
					%energy = Gamebase::getEnergy(%tc);

					if($emptime[%tc] > 2) //New stuff.  Cure your teammate's EMP
					{
						Player::trigger(%player, $WeaponSlot, false); 
//						Client::sendMessage(%client,1, "Charging " @ Client::getName(%tc)); 
//						Client::sendMessage(%tc,1, "You are being charged by " @ Client::getName(%client));
						%energy = Gamebase::getEnergy(%tc);
						%energy += 50;
						Gamebase::setEnergy(%tc,%energy);
						$emptime[%tc] = 2;
						Player::trigger(%player, $WeaponSlot, false); 
						return; 
					}
					else if($shieldTime[%tc] <= 0)//(%target.shieldStrength < 0.025 && !%target.shieldon) //Shield your teammate
					{
//						Client::sendMessage(%client,1, "Shielding " @ Client::getName(%tc)); 
//						Client::sendMessage(%tc,1, "Receiving shielding from " @ Client::getName(%client)); 
//						%target.shieldStrength = 0.025;
//						%target.shieldon = true; //perhaps this will help
//						schedule ("" @ %target @ ".shieldStrength = 0;",240);
//						schedule ("" @ %target @ ".shieldon = false;",240);  //maybe this as well

						%player.powerTarget = ""; 
						Shifter_startShield(%tc,%target);
						$shieldTime[%tc] = 240;
						schedule ("Player::trigger("@%player@", $WeaponSlot, false);", 0.7);
						return; 
					} 
					else //New stuff.  Give your teammate energy
					{
//						Client::sendMessage(%client,1, "Powering " @ Client::getName(%tc)); 
//						Client::sendMessage(%tc,1, "Receiving power from " @ Client::getName(%client)); 
						GameBase::setEnergy(%target,%maxen);
						Player::trigger(%player,$WeaponSlot,false);
						return;
					}
				}
				else if(%objType == "Flier")
				{
					%player.powerTarget = ""; 
					%target.shieldStrength = 0.013; 
//					Client::sendMessage(%client,0, "Shielding " @ $VehicleToItem[GameBase::getDataName(%target)].description); 
					Player::trigger(%player, $WeaponSlot, false); 
					return; 
				}
				else if(GameBase::isPowered(%target) || %target.poweron == "True") 
				{ 
					if(%shape == inventory_sta || %shape == cmdpnl || %shape == ammounit) //%obj == "InventoryStation" || %obj == "AmmoStation" || %obj == "CommandStation") 
					{
						%player.powerTarget = ""; 					
//						Client::sendMessage(%client,0, %obj.description @ " is already powered"); 
						Player::trigger(%player, $WeaponSlot, false); 
						return; 
					}
				}
				else 
				{
					if(%shape == inventory_sta || %shape == cmdpnl || %shape == ammounit) //(%obj == "InventoryStation" || %obj == "AmmoStation" || %obj == "CommandStation") 
					{ 
						%player.powerTarget = "";
						
//						Client::sendMessage(%client,0, "Powering " @ %obj.description); 
						GameBase::playSequence(%target,0,"power"); 
						GameBase::playSequence(%target,1);
						
						%target.poweron = "True";
						if($Shifter::HackedTime > 10)
						{
							schedule ("StopTempPower(" @ %target @ ");",$Shifter::HackedTime);

//							schedule ("" @ %target @ ".poweron = false;",$Shifter::HackedTime);
//							schedule ("GameBase::stopSequence(" @ %target @ ",0);",$Shifter::HackedTime);
//							schedule ("GameBase::pauseSequence(" @ %target @ ",1);",$Shifter::HackedTime);
//							schedule ("GameBase::pauseSequence(" @ %target @ ",2);",$Shifter::HackedTime);
//							schedule ("Station::checkTarget(" @ %target @ ");",$Shifter::HackedTime);
						}

						Player::trigger(%player, $WeaponSlot, false); 
						return; 
					}
				}
				
				if((%obj == "PlasmaTurret" || %obj == "ELFTurret" || %obj == "RocketTurret" || %obj == "IndoorTurret" || %obj == "PulseSensor" || %obj == "MediumPulseSensor" || %obj == "MortarTurret" || %shape == "remoteturret" || %shape == "mortar_turret" || %shape == "hellfiregun" || %shape == "indoorgun" || %shape == "chainturret") && %target.shieldstrength < 0.03) 
				{ 
					%player.powerTarget = ""; 
//					Client::sendMessage(%client,1, "Upgrading Shielding on " @ %obj.description); 
					%target.shieldStrength = 0.03; 
					GameBase::setRechargeRate(%target,10); 
					Player::trigger(%player, $WeaponSlot, false); 
					return; 
				} 
				else if((%class == "Generator" || %class == "Turret") && %target.shieldstrength < 0.017)
				{
					%player.powerTarget = "";
//					Client::sendMessage(%client,1, "Adding Shielding to " @ %obj.description);
					%target.shieldStrength = 0.017;
					GameBase::setRechargeRate(%target,10);
					GameBase::setActive(%target,true);
					Player::trigger(%player, $WeaponSlot, false);
					return;
				}
				if(%obj == "DeployableInvStation" || %obj == "DeployableAmmoStation")
				{
					if ((%obj == "DeployableInvStation" && %target.Energy < ($RemoteInvEnergy + 2000)) || (%obj == "DeployableAmmoStation" && %target.Energy < ($RemoteAmmoEnergy + 2000)))
					{
						%player.powerTarget = "";
						%target.Energy += 1000;
//						if($Uped[%target] < 0 || $Uped[%target] > 3 || !$Uped[%target])
//							$Uped[%target] = 0;
//						$Uped[%target]++;
						Client::sendMessage(%client,1, "Station Recharged - Energy at " @ %target.Energy @ ""); //" @ %obj.description @ " 
						Player::trigger(%player, $WeaponSlot, false); 
						return; 
					}
					else 
					{
						Client::sendMessage(%client,1, "" @ %obj.description @ " is fully charged."); 
						Player::trigger(%player, $WeaponSlot, false); 
						return; 
					}
					
//					if ($Uped[%target] == 2)
//					{
//						Client::sendMessage(%client,1, "" @ %obj.description @ " will overload after another charge..."); 
//					}
//					else if ($Uped[%target] == 3)
//					{					
//						Client::sendMessage(%client,1, "" @ %obj.description @ " will overload in 5 seconds..."); 
//						GameBase::applyDamage(%client,$FlashDamageType,0.30,GameBase::getPosition(%client),"0 0 0","0 0 0",%target);
//						schedule("GameBase::applyRadiusDamage("@ $NukeDamageType @", getboxcenter("@ %target @"), 10, 5, 100, "@ %player @");", 5);
//					}
				}
				Client::sendMessage(%client,1, "No Effect On " @ %obj.description @ "."); 
				Player::trigger(%player, $WeaponSlot, false); 
				return; 
			}
		}
	}
}

function DrainBolt::onRelease(%this, %player)
{
	%client = Player::getClient(%player);

	$PlayerDraining[%player] = "False";
	//echo ("***  Drain Progress Stopped " @ $PlayerDraining[%player]);
	GameBase::repairDamage(%player,0);
	
	%object = %player.drainTarget;
	if (%object != -1)
	{
		%client = Player::getClient(%player);
		if (%object == %player)
		{
			Client::sendMessage(%client,0,"AutoRepair Off");
		}
		else
		{
			if (GameBase::getDamageLevel(%object) == 0)
			{
				Client::sendMessage(%client,1,"Done.");
				GameBase::repairDamage(%player,0);
			}
			else
			{
				Client::sendMessage(%client,1,"Done.");
				GameBase::repairDamage(%player,0);
			}
		}
	}
}

function StopTempPower(%target)
{
	%target.poweron = false;
	if(!GameBase::isPowered(%target))
	{
		GameBase::stopSequence(%target,0);
		GameBase::pauseSequence(%target,1);
		GameBase::pauseSequence(%target,2);
		Station::checkTarget(%target);
	}
}

// Disasymbler - Alternate To Engineer Repair Gun.
//------------------------------------------------------------------------------------------------------------------------
RepairEffectData DisaBolt
{
   bitmapName       = "lightningNew.bmp";
   boltLength       = 20.0;
   segmentDivisions = 4;
   beamWidth        = 0.3;

   updateTime   = 450;
   skipPercent  = 0.6;
   displaceBias = 0.25;

   lightRange = 3.0;
   lightColor = { 0.25, 0.25, 0.85 };

   soundId = SoundELFFire;
};

function DisaBolt::onAcquire(%this, %player, %target)
{
	%client = Player::getClient(%player);

	if (%target != %player)
	{
		%player.repairTarget = %target;
		%name = GameBase::getMapName(%target);
		%team = GameBase::getTeam(%target);
		%pTeam = GameBase::getTeam(%player); //added
		%pName = Client::getName(%client); //added
		%tName = getTeamName(%team); //added
		
		if(%name == "")
		{
			%name = (GameBase::getDataName(%player.repairTarget)).description;
		}

		%shape = (GameBase::getDataName(%player.repairTarget)).shapeFile;
		
		if(getObjectType(%player.repairTarget) == "Player")
		{
			Client::sendMessage(%client,0,"You cannot disassymble another player, however funny that might be.");
			Player::trigger(%player,$WeaponSlot,false);
		}
		else if(String::findSubStr(%name,"SatchelPack") != -1 || (%name == "False" && %shape == "magcargo"))
		{
			Client::sendMessage(%client,0,"Error, cannot disassymble.  Target may respond to hacking instead.");
			Player::trigger(%player,$WeaponSlot,false);
			Player::useItem(%player,HackIt);
		}
		else
		{
			Client::sendMessage(%client,0,"Disassymbling " @ %name @ ". Please wait...");
			%disatime = 5;
			$disassymble[%player] = True;
			objectColapsable(%target, %player, %name, %shape, %disatime);
			if ($Debug) echo ("Done.");
		}
	}	
}

function DisaBolt::onRelease(%this, %player)
{
	$disassymble[%player] = false;
}


function removeflagdefpoints(%player)
{
	%client = Player::getClient(%player);
	%client.score = %client.score - $Score::FlagDef;
	if ($ScoreOn) bottomprint(%Client, "Score - " @ $Score::FlagDef @ " = " @ %client.score @ " Total Score, for removing flag defensive." ,3);
	Game::refreshClientScore(%client);
}

function objectColapsable(%this, %player, %name, %shape, %disatime)
{	
	%client = Player::getClient(%player);
	%pos = gamebase::GetPosition (%this);
	%description = %name;
	%playerteam = Client::getTeam(%client);				//== Player Team
	%playerpos = GameBase::getPosition(%player);			//== Player Position
	%homepos = ($teamFlag[%playerteam]).originalPosition;
	%flagdist = Vector::getDistance(%pos,%homepos);
	%team = GameBase::getTeam(%this);
	if($origteam[%this]) //== Make sure we get the correct team if we're trying to break down a hacked item
		%team = $origteam[%this];
		
	%item = "";

	if($debug) echo(%name);

	if (Player::getmounteditem(%player, $BackPackSlot) != "-1" && !(String::findSubStr(%name, "Cloaking Camera") >= 0))
	{
		bottomprint( %client, "<jl><f1> You cannot disassymble the " @ %description @ ", drop your current pack first...", 3);
		return 0;
	}

	if ($disassymble[%player])
	{
		if (%disatime > 0)
		{
			%disatime = %disatime - 1;
			schedule ("objectColapsable ( '" @ %this @ "', '" @ %player @ "', '" @ %name @ "', '" @ %shape @ "', '" @ %disatime @ "'); ",1);
			return 0;
		}
	}
	else
	{
		return 0;
	}
	
	if ($Debug) echo ("Attempting To Dismantle " @ %name);

	//== Special cases at the top, things that require special operations

	//================================================================================================= Teleport Pad
	if (String::findSubStr(%name, "Teleport Pad") >= 0)
	{
		%item = "TeleportPack";		
		Client::sendMessage(%client,0,"Disassymbling " @ %name);	  		
  		$TeamItemCount[GameBase::getTeam(%this) @ "DeployableTeleport"]--;

		
		Player::setItemcount (%client, %item, 1);
		Player::mountItem(%client,%item,$BackpackSlot);
		Item::playPickupSound(%this);

		bottomprint( %client, "<jl><f1> Disassymbling " @ %description @ ".", 3);
		
		RemoveBeam(%this.beam1);
		deleteObject(%this);
		return 1;
	}	
	//======================================================================================== Command Station
	else if (String::findSubStr(%name, "Remote Command Station") >= 0)
	{
		%item = "DeployableComPack";		
		Client::sendMessage(%client,0,"Disassymbling " @ %name);	  		
  		$TeamItemCount[GameBase::getTeam(%this) @ "DeployableComPack"]--;

			Player::setItemcount (%client, %item, 1);
			Player::mountItem(%client,%item,$BackpackSlot);
			Item::playPickupSound(%this);

		bottomprint( %client, "<jl><f1> Disassymbling " @ %description @ ".", 3);
		deleteObject(%this);
		return 1;
	}
	//================================================================================================= Camera 
	else if (String::findSubStr(%name, "Cloaking Camera") >= 0)
	{
		%item = "EngBeacons";		
		Client::sendMessage(%client,0,"Disassymbling " @ %name);	  		
  		$TeamItemCount[GameBase::getTeam(%this) @ %item]--;

			Player::incItemCount(%client,Beacon);
			Item::playPickupSound(%this);

		bottomprint( %client, "<jl><f1> Disassymbling " @ %description @ ".", 3);
		
		$disassymble[%player] = false;
		deleteObject(%this);
		return 1;
	}
	//================================================================================================= Rocket Turret
	else if (String::findSubStr(%name, "RMT Rocket Turret") >= 0)
	{
		%item = "RocketPack";		
		if (%flagdist < 100) removeflagdefpoints(%player);
	}
	//================================================================================================= Plasma Turret
	else if (String::findSubStr(%name, "RMT Plasma Turret") >= 0)
	{
		%item = "PlasmaTurretPack";		
		if (%flagdist < 35) removeflagdefpoints(%player);
	}
	//================================================================================================= Elf Turret
	else if (String::findSubStr(%name, "Deployable Elf Turret") >= 0)
	{
		%item = "DeployableElf";		
		if (%flagdist < 20) removeflagdefpoints(%player);
	}
	//================================================================================================= EMP Turret
	else if (String::findSubStr(%name, "EMP Turret") >= 0)
	{
		%item = "ShockPack";		
		if (%flagdist < 10) removeflagdefpoints(%player);
	}
	//================================================================================================= Remote Mortar
	else if (String::findSubStr(%name, "Remote Mortar Turret") >= 0)
	{
		%item = "TargetPack";		
		if (%flagdist < 55) removeflagdefpoints(%player);
	}
	//================================================================================================= Laser Turret
	else if (String::findSubStr(%name, "Laser Turret") >= 0)
	{
		%item = "LaserPack";		
		if (%flagdist < 55) removeflagdefpoints(%player);
	}
	//================================================================================================= Ion Turret
	else if (String::findSubStr(%name, "Ion Turret") >= 0)
	{
		%item = "TurretPack";		
		if (%flagdist < 35) removeflagdefpoints(%player);
	}
	//================================================================================================= AATurret
	else if (String::findSubStr(%name, "Anti-AirCraft Turret") >= 0)
	{
		%item = "BarragePack";		
		if (%flagdist < 100) removeflagdefpoints(%player);
	}
	//================================================================================================= Portable Generator
	else if (String::findSubStr(%name, "PortGenerator") >= 0)
	{
		%item = "PowerGeneratorPack";
		//added because I have this feeling it's interferring with PowerCheck
		GameBase::stopSequence(%this,0);
	 	GameBase::generatePower(%this, false);		
	}
	//=== And now the basic stuff below, kept mostly for COA purposes

	//================================================================================================= AccelPad
	else if (String::findSubStr(%name, "Accel Pad") >= 0)
	{
		%item = "AccelPPack";		
	}
	//================================================================================================= Launch Pad
	else if (String::findSubStr(%name, "Launchboard") >= 0)
	{
		%item = "LaunchPack";		
	}
	//========================================================================================== Sensor Jammer
	else if (String::findSubStr(%name, "Sensor Jammer") >= 0)
	{
		%item = "DeployableSensorJammerPack";
	}
	//================================================================================================= Pulse Sensor
	else if (String::findSubStr(%name, "Remote Pulse Sensor") >= 0)
	{
		%item = "PulseSensorPack";		
	}
	//================================================================================================= Motion Sensor
	else if (String::findSubStr(%name, "Motion Sensor") >= 0)
	{
		%item = "MotionSensorPack";		
	}
	//================================================================================================= Camera 
	else if (String::findSubStr(%name, "Camera") >= 0)
	{
		%item = "CameraPack";		
	}
	//================================================================================================= Blast Wall
	else if (String::findSubStr(%name, "Blast Wall") >= 0)
	{
		%item = "BlastWallPack";		
	}
	//================================================================================================= Blast Floor
	else if (String::findSubStr(%name, "Blast Floor") >= 0)
	{
		%item = "BlastFloorPack";		
	}
	//================================================================================================= Small Force Field
	else if (String::findSubStr(%name, "Small Force Field") >= 0)
	{
		%item = "ForceFieldPack";		
	}
	//================================================================================================= Large Force Field
	else if (String::findSubStr(%name, "Large Force Field") >= 0)
	{
		%item = "LargeForceFieldPack";		
	}
	//================================================================================================= Large Shock Force Field
	else if (String::findSubStr(%name, "Large Shock Force Field") >= 0)
	{
		%item = "LargeShockForceFieldPack";		
	}
	//================================================================================================= Small Shock Force Field
	else if (String::findSubStr(%name, "Small Shock Force Field") >= 0)
	{
		%item = "ShockForceFieldPack";		
	}
	//========================================================================================= Deployable Platform
	else if (String::findSubStr(%name, "DeployablePlatform") >= 0)
	{
		%item = "PlatformPack";		
	}	
	//==================================================================================== Healing Plant
	else if (String::findSubStr(%name, "Healing Plant") >= 0)
	{
		%item = "PlantPack";		
	}
	//================================================================================================= Arbitor Beacon
	else if (String::findSubStr(%name, "ArbitorBeacon") >= 0)
	{
		%item = "ArbitorBeaconPack";		
	}
	//================================================================================================= Shield Beacon
	else if (String::findSubStr(%name, "ShieldBeacon") >= 0)
	{
		%item = "ShieldBeaconPack";		
	}
	//================================================================================================= EMPBeacon
	else if (String::findSubStr(%name, "EMPBeacon") >= 0)
	{
		%item = "EMPBeaconPack";		
	}
	//================================================================================================= Jammer Beacon
	else if (String::findSubStr(%name, "JammerBeacon") >= 0)
	{
		%item = "JammerBeaconPack";		
	}
	//================================================================================================= Shock Floor
	else if (String::findSubStr(%name, "Shock Floor") >= 0)
	{
		%item = "ShockFloorPack";		
	}
	else //== If all else fails, use the deploy source variable
		%item = %this.depsource;

	if(%item != "" && %item != false)
	{
		Client::sendMessage(%client,0,"Disassymbled " @ %name);	  		
  		$TeamItemCount[%team @ %item]--;

		Player::setItemcount (%client, %item, 1);
		Player::mountItem(%client,%item,$BackpackSlot);
		Item::playPickupSound(%this);

		bottomprint( %client, "<jl><f1> Disassymbled " @ %description @ ".", 3);
		
		$disassymble[%player] = false;
		deleteObject(%this);
		return 1;
	}

	Client::sendMessage(%client,0,"Disassymbling " @ %name @ " failed...");
	Player::trigger(%client,$WeaponSlot,false);
	$disassymble[%player] = false;
	return 0;
}

//===============================================================================================================
//													 Lock Jaw
//===============================================================================================================

RepairEffectData LockJaw
{
   bitmapName       = "lightningNew.bmp";
   boltLength       = 700.0;
   segmentDivisions = 2;
   beamWidth        = 0.05;
   updateTime   = 150;
   skipPercent  = 1.0;
   displaceBias = 0.25;

   lightRange = 3.0;
   lightColor = { 0.25, 0.25, 0.85 };
   soundId = SoundELFFire;
};

function LockJaw::onAcquire(%this, %player, %target)
{
	%client = Player::getClient(%player);

	if (!%client.target || %client.target == "-1" || %client.target == %player)
		%client.target = %target;

	%name = GameBase::getDataName(%target);
	%team = GameBase::getTeam(%target);
	%pTeam = GameBase::getTeam(%player);
	%pName = Client::getName(%client);

	if ($debug) echo ("Target       " @ %client.target);
	if ($debug) echo ("Target Name  " @ %name);
	if ($debug) echo ("Target Team  " @ %team);
	if ($debug) echo ("Player Team  " @ %pTeam);
	if ($debug) echo ("Player Name  " @ %pName);

	if (!%client.target || %client.target == "-1" || %client.target == %player)
	{
		schedule("bottomprint(" @ %client @ ", \"<jc><f1>No Lock, Attempting To Acquire!\", 3);", 0);
		schedule("Client::sendMessage(" @ %client @ ",1,\"No Lock, Attempting To Acquire!~waccess_denied.wav\");",0);
		%client.target = -1;
		return;
	}
	if (%client.target != "-1")
	{
		if (gamebase::getteam(%client.target) == gamebase::getteam(%player) && $Shifter::DeathMatch != "true")
		{
			schedule("bottomprint(" @ %client @ ", \"<jc><f1>Lock Failed, Can Not Target Friendlies!\", 3);", 0);
			schedule("Client::sendMessage(" @ %client @ ",1,\"Lock Failed, Can Not Target Friendlies!~waccess_denied.wav\");",0);
			%client.target = -1;
			return;
		}
		schedule("Client::sendMessage(" @ %client @ ",1,\"** LockJaw Aquired - Active For Next 15 Seconds!!!~wmine_act.wav\");",0);			
		schedule("bottomprint(" @ %client @ ", \"<jc><f1>LockJaw Aquired - Active For Next 15 Seconds! - Fire Now To Launch!\", 3);", 0);
		schedule("bottomprint(" @ %client @ ", \"<jc><f1>LockJaw Lost Lock!\", 3);", 15);
		schedule("" @ %client @ ".target = \"-1\";", 15);
		schedule ("playSound(TargetingMissile,GameBase::getPosition(" @ %player @ "));",0);
		%targetId = Player::getClient(%target);
		LockJaw(%client,%targetId);			
	}
}
function LockJaw(%clientId, %targetId) 
{
	if(%targetId) 
	{
		%name = Client::getName(%clientId);
		 Client::sendMessage(%targetId,0,"** WARNING ** - " @ %name @ " has you in LockJaw!!!~waccess_denied.wav");
		 schedule("Client::sendMessage(" @ %targetId @ ",0,\"~waccess_denied.wav\");",0.5);
		 schedule("Client::sendMessage(" @ %targetId @ ",0,\"~waccess_denied.wav\");",1.0);
		 schedule("Client::sendMessage(" @ %targetId @ ",0,\"~waccess_denied.wav\");",1.5);
	}
} 
function LockJawFire(%player, %target)
{
	if ($debug) echo ("Firing Locker");
	
	%client = Player::getClient(%player);

	Player::decItemCount(%player,$WeaponAmmo[RocketLauncher],1);
	%trans = GameBase::getMuzzleTransform(%player);
	%vel = Item::getVelocity(%player);	
	
	$targetingmissile = %client.target;
	Projectile::spawnProjectile("MiniMissileTracker",%trans,%player,%vel,%client.target);
	schedule ("playSound(SoundMissileTurretFire,GameBase::getPosition(" @ %player @ "));",0);
	schedule("Client::sendMessage(" @ Player::getClient(%target) @ ",0,\"~waccess_denied.wav\");",0.5);

}

function LockJaw::onRelease(%this, %player)
{
	%client = Player::getClient(%player);
	%object = %player.target;
	
	if ($debug) echo ("Object Target " @ %player.target);
	if ($debug) echo ("Shootr Client " @ %client);
}

//========================================================================= Heat Seeker (stolen from Grey)

LightningData LockJaw2
{
	//bitmapName       = "";  //paintPulse.bmp

	damageType       = $GravDamageType;
	coneAngle        = 10.0;
	damagePerSec      = 0.001;
	energyDrainPerSec = 0.001;

	boltLength       = 350.0;
	segmentDivisions = 2;
	numSegments    = 1;
	beamWidth        = 0.001;
	updateTime   = 100;
	skipPercent  = 0.9;
	displaceBias = 0.25;

	lightRange = 3.0;
	lightColor = { 0.15, 0.15, 0.95 };

	soundId = SoundELFFire;
};

function LockJaw2::damageTarget(%target, %timeSlice, %damPerSec, %enDrainPerSec, %pos, %vec, %mom, %player)
{
  %client = Player::getClient(%player);
	if ((!%client.target || %client.target == "-1" || %client.target == %player) && %client.lj)
	{
		%client.target = %target; 
		if(%client.lj)deleteobject(%client.lj);
		%client.lj = 0;
		%type = getObjectType(%target);
		if (gamebase::getteam(%target) == gamebase::getteam(%player) && $Shifter::DeathMatch != "true")
		{
			bottomprint(%client, "<jc><f1>Lock Failed, Can Not Target Friendlies!", 3);
			Client::sendMessage(%client,1,"Lock Failed, Can Not Target Friendlies!~waccess_denied.wav");
			%client.target = -1;
		}
		else if (%type == "Flier")
		{
			Client::sendMessage(%client,1,"** Heat Lock Aquired - Active For Next 15 Seconds!!!~wmine_act.wav");			
			bottomprint(%client, "<jc><f1>Heat Lock Aquired - Active For Next 15 Seconds! - Fire Now To Launch!", 3);
			playSound(TargetingMissile,GameBase::getPosition(%player));
			Player::trigger(%player,$WeaponSlot,false);
			schedule("bottomprint(" @ %client @ ", \"<jc><f1>Lost Heat Lock!\", 3);", 15);
			schedule(%client @ ".target = -1;", 15);
		}
		else if(%type == "Player")
		{	
			%pack =Player::getMountedItem(%target,$BackpackSlot);

			if(%pack == DeployableSensorJammerPack || %pack == SensorJammerPack || Player::getSensorSupression(%target) > 19)
			{
				bottomprint(%client, "<jc><f1>Lock Failed, Target Jammed!", 3);
				Client::sendMessage(%client,1,"Lock Failed, Target Jammed!~waccess_denied.wav");
				%client.target = -1;
			}
			else
			if (GameBase::virtual(%target, "getHeatFactor") <= 0.5)
			{
				bottomprint(%client, "<jc><f1>Lock Failed, No Heat Source!", 3);
				Client::sendMessage(%client,1,"Lock Failed, No Heat Source!~waccess_denied.wav");
				%client.target = -1;
			}
			else
			{
				Client::sendMessage(%client,1,"** Heat Lock Aquired - " @ Client::getName(Player::GetClient(%target)) @ " - Active For Next 15 Seconds!!!~wmine_act.wav");			
				bottomprint(%client, "<jc><f1>Heat Lock Aquired - Active For Next 15 Seconds! - Fire Now To Launch!", 3);
				playSound(TargetingMissile,GameBase::getPosition(%player));
				Player::trigger(%player,$WeaponSlot,false);
				schedule(%client @ ".target = -1;", 15);
				schedule("bottomprint(" @ %client @ ", \"<jc><f1>Lost Heat Lock!\", 3);", 15);
			}
		}
		else
		{
			bottomprint(%client, "<jc><f1>Lock Failed, No Targetable Object!", 3);
			Client::sendMessage(%client,1,"Lock Failed, No Targetable Object!~waccess_denied.wav");
			%client.target = -1;
		}
	}	
}

function LockJaw2Warn(%clientId, %targetId) 
{
	if(%targetId) 
	{
		%name = Client::getName(%clientId);
		Client::sendMessage(%targetId,0,"** WARNING ** - " @ %name @ " is tracking your jetpack heat signature!!~waccess_denied.wav");
		schedule("Client::sendMessage(" @ %targetId @ ",0,\"~~waccess_denied.wav\");",0.5);//access_denied.wav
	}
} 

function LockJaw2Fire(%player, %target, %rnd)
{
//	if (getObjectType(%target) == "Player")
//	{
		if(GameBase::virtual(%target, "getHeatFactor") >= 0.5)
		{
			%client = Player::getClient(%player);
			%targetid = Player::getClient(%target);
			LockJaw2Warn(%client, %targetID);
			Player::decItemCount(%player,$WeaponAmmo[RocketLauncher],1);
			%trans = GameBase::getMuzzleTransform(%player);
			%vel = Item::getVelocity(%player);	
			$targetingmissile = %client.target;
			Projectile::spawnProjectile("MiniMissileTracker",%trans,%player,%vel,%target);
			%pos = GameBase::getPosition(%player);
			playSound(SoundMissileTurretFire,%pos);
			playSound(SoundMissileTurretFire,%pos);
		}
//	}
}

//===============================================================================================================
//						Special Functions
//===============================================================================================================
function NuclearExplosion(%this)
{
	%cl = %this.deployer;
	%player = client::getownedobject(%cl);
	%vel = "0 0 0";
	
	if (!%player)
		return;

	if($Shifter::LimitNukes != "false" && !%this.deaddeploy && Client::getName(%cl) != "" && $Nukecount[GameBase::getTeam(%cl)] < $Shifter::AllNukeLimit && !Player::isAIControlled(%player))
	{
		$Nukecount[GameBase::getTeam(%cl)]++;
		TeamMessages(1,GameBase::getTeam(%cl),Client::getName(%cl) @ " has used #" @ $Nukecount[GameBase::getTeam(%cl)] @ " of your team's " @ $Shifter::AllNukeLimit @ " nuclear devices.");
	}
	%this.deaddeploy = "";

	%pos1 = gamebase::getposition(%this);

	// Prevent nukes from going through solid objects, if enabled
	if($Shifter::SolidNuke != "false")
	{
		%dpos = newObject("","Turret",cameraturret,true);	// for determining Z
		GameBase::setPosition(%dpos,%pos1);
		GameBase::getLOSInfo(%dpos,1024,"1.57 0 0");	// Z LOS
		deleteObject(%dpos);
	
		if($los::position != "0 0 0" && $los::position != "")
			%dist = Vector::getDistance($los::position,%pos1);
		else
			%dist = 100;
	}
	else
		%dist = 100;

	%rot = "0 0 0";
	%dir = (Vector::getfromrot(%rot));	
	%trans1 = (%rot @ " " @ %dir @ " " @ %rot);

	if(%dist < 2.0)
		%padd = "0 0 "@%dist;
	else
		%padd = "0 0 2.0";
	%pos = Vector::add(%pos1, %padd);
	%trans = "0 0 0 0 0 0 0 0 0 " @ %pos;
	schedule ("Projectile::spawnProjectile(NBase, \"" @ %trans @ "\", \"" @ %player @ "\", \"" @ %vel @ "\");",0.1);

	if(%dist < 3.0)
		%padd = "0 0 "@%dist;
	else
		%padd = "0 0 3.0";
	%pos = Vector::add(%pos1, %padd);
	%trans = "0 0 0 0 0 0 0 0 0 " @ %pos;
	schedule ("Projectile::spawnProjectile(NRing, \"" @ %trans @ "\", \"" @ %player @ "\", \"0 0 10\");",1.1);

	if(%dist < 4.0)
		%padd = "0 0 "@%dist;
	else
		%padd = "0 0 4.0";
	%pos = Vector::add(%pos1, %padd);
	%trans = "0 0 0 0 0 0 0 0 0 " @ %pos;
	schedule ("Projectile::spawnProjectile(NRing, \"" @ %trans @ "\", \"" @ %player @ "\", \"0 0 10\");",0.2);

	if(%dist < 8.0)
		%padd = "0 0 "@%dist;
	else
		%padd = "0 0 8.0";
	%pos = Vector::add(%pos1, %padd);
	%trans = "0 0 0 0 0 0 0 0 0 " @ %pos;
	schedule ("Projectile::spawnProjectile(NRing, \"" @ %trans @ "\", \"" @ %player @ "\", \"0 0 10\");",0.2);
	
	%obj = newObject("","Mine","NRing1"); 
 	addToSet("MissionCleanup", %obj);
	GameBase::throw(%obj,%player,0,false);
 	gamebase::setposition(%obj, %pos);
 
	if(%dist < 10.0)
		%padd = "0 0 "@%dist;
	else
		%padd = "0 0 10.0";
	%pos = Vector::add(%pos1, %padd);
	%trans = "0 0 0 0 0 0 0 0 0 " @ %pos;
	schedule ("Projectile::spawnProjectile(NBlast, \"" @ %trans @ "\", \"" @ %player @ "\", \"" @ %vel @ "\");",0.3);
	
	%obj = newObject("","Mine","NRing1"); 
 	addToSet("MissionCleanup", %obj);
	GameBase::throw(%obj,%player,0,false);
 	gamebase::setposition(%obj, %pos);
 
	if(%dist < 25.0)
		%padd = "0 0 "@%dist;
	else
		%padd = "0 0 25.0";
	%pos = Vector::add(%pos1, %padd);
	%trans = "0 0 0 0 0 0 0 0 0 " @ %pos;
	schedule ("Projectile::spawnProjectile(NBlast, \"" @ %trans @ "\", \"" @ %player @ "\", \"" @ %vel @ "\");",0.1);

	if(%dist < 35.0)
		%padd = "0 0 "@%dist;
	else
		%padd = "0 0 35.0";
	%pos = Vector::add(%pos1, %padd);
	%trans = "0 0 0 0 0 0 0 0 0 " @ %pos;
	schedule ("Projectile::spawnProjectile(NBlast, \"" @ %trans @ "\", \"" @ %player @ "\", \"" @ %vel @ "\");",0.1);

	if(%dist < 45.0)
		%padd = "0 0 "@%dist;
	else
		%padd = "0 0 45.0";
	%pos = Vector::add(%pos1, %padd);
	%trans = "0 0 0 0 0 0 0 0 0 " @ %pos;
	schedule ("Projectile::spawnProjectile(NBlast, \"" @ %trans @ "\", \"" @ %player @ "\", \"" @ %vel @ "\");",0.1);

	if(%dist < 60.0)
		%padd = "15.0 0 "@%dist;
	else
		%padd = "15.0 0 60.0";
	%pos = Vector::add(%pos1, %padd);
	%trans = "0 0 0 0 0 0 0 0 0 " @ %pos;
	schedule ("Projectile::spawnProjectile(NCloud, \"" @ %trans @ "\", \"" @ %player @ "\", \"" @ %vel @ "\");",0.1);

	if(%dist < 60.0)
		%padd = "-15.0 0 "@%dist;
	else
		%padd = "-15.0 0 60.0";
	%pos = Vector::add(%pos1, %padd);
	%trans = "0 0 0 0 0 0 0 0 0 " @ %pos;
	schedule ("Projectile::spawnProjectile(NCloud, \"" @ %trans @ "\", \"" @ %player @ "\", \"" @ %vel @ "\");",0.1);

	if(%dist < 60.0)
		%padd = "0 15.0 "@%dist;
	else
		%padd = "0 15.0 60.0";
	%pos = Vector::add(%pos1, %padd);
	%trans = "0 0 0 0 0 0 0 0 0 " @ %pos;
	schedule ("Projectile::spawnProjectile(NCloud, \"" @ %trans @ "\", \"" @ %player @ "\", \"" @ %vel @ "\");",0.1);

	if(%dist < 60.0)
		%padd = "0 -15.0 "@%dist;
	else
		%padd = "0 -15.0 60.0";
	%pos = Vector::add(%pos1, %padd);
	%trans = "0 0 0 0 0 0 0 0 0 " @ %pos;
	schedule ("Projectile::spawnProjectile(NCloud, \"" @ %trans @ "\", \"" @ %player @ "\", \"" @ %vel @ "\");",0.1);

	if(%dist < 75.0)
		%padd = "0 0 "@%dist;
	else
		%padd = "0 0 75.0";
	%pos = Vector::add(%pos1, %padd);
	%trans = "0 0 0 0 0 0 0 0 0 " @ %pos;
	schedule ("Projectile::spawnProjectile(NCloud, \"" @ %trans @ "\", \"" @ %player @ "\", \"" @ %vel @ "\");",0.1);

	if(%dist < 65.0)
		%padd = "0 0 "@%dist;
	else
		%padd = "0 0 65";
	%pos = Vector::add(%pos1, %padd);
	%trans = "0 0 0 0 0 0 0 0 0 " @ %pos;
	schedule ("Projectile::spawnProjectile(NRing, \"" @ %trans @ "\", \"" @ %player @ "\", \"" @ %vel @ "\");",0.2);
	
	%obj = newObject("","Mine","NRing1"); 
 	addToSet("MissionCleanup", %obj);
	GameBase::throw(%obj,%player,0,false);
 	gamebase::setposition(%obj, %pos);
	AOE::deployShape(%this, 50, -1, 15, %cl, 0.40); //== added, so nukes are a little more powerful
	deleteObject(%this);
}

function DeployBomblets(%this, %count) 
{
        %clientId = %this.deployer;
        %player = Client::GetOwnedObject(%clientId);
	
	GameBase::setTeam(%this,GameBase::getTeam(%player));

	if(%count && %this)
	{
		%obj = newObject("","Mine","Bomblet1");
		%obj.deployer = %clientId;
		GameBase::throw(%obj,%player,-20,false);
 		addToSet("MissionCleanup", %obj);
		GameBase::setPosition(%obj, gamebase::getposition(%this));

		%obj = newObject("","Mine","Bomblet2");
		%obj.deployer = %clientId;
		GameBase::throw(%obj,%player,60,true);
	 	addToSet("MissionCleanup", %obj);
		GameBase::setPosition(%obj, gamebase::getposition(%this));

		%obj = newObject("","Mine","Bomblet3");
		%obj.deployer = %clientId;
		GameBase::throw(%obj,%player,50,true);
		addToSet("MissionCleanup", %obj);
		GameBase::setPosition(%obj, gamebase::getposition(%this));

		%count -= 1;
		schedule("DeployBomblets(" @ %this @ ", " @ %count @ ");",0.5,%this);
	}
}

function Grenade::isatRest(%this)
{
	%pos = GameBase::getPosition(%this);
	if($debug) echo("Grenade position - " @ %pos);

	if(!$pos[%this])
		return false;

	%diff = Vector::sub(%pos,$pos[%this]);
	if($debug) echo("Grenade change - " @ %diff);

	%xdif = getword(%diff,0);
	%ydif = getword(%diff,1);
	%zdif = getword(%diff,2);

	if(%xdif > 8 || %xdif < -8 || %ydif > 8 || %ydif < -8 || %zdif > 10 || %zdif < -10)
		return false;
	else
		return true;
}