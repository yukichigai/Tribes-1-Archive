//====================================
// Grenades
//====================================

// Standard	- Merc
// Tranq	- Arbitor
// Emp		- Engineer
// Concussion	- Scout
// Plastique	- Chemeleon
// Mortar	- Dreadnaught
// FireBomb	- Goliath


//==================================================================================================== Standard Grenade

MineData Handgrenade
{
	mass = 0.3;
	drag = 1.0;
	density = 2.0;
	elasticity = 0.15;
	friction = 1.0;
	className = "Handgrenade";
	description = "Handgrenade";
	shapeFile = "grenade";
	shadowDetailMask = 4;
	explosionId = grenadeExp;
	explosionRadius = 10.0;
	damageValue = 0.5;
	damageType = $ShrapnelDamageType;
	//damageType = $EnergyDamageType;

	kickBackStrength = 200;
	triggerRadius = 0.5;
	maxDamage = 2.0;
};

function Handgrenade::onAdd(%this)
{
	%data = GameBase::getDataName(%this);
	schedule("Mine::Detonate(" @ %this @ ");",2.0,%this);
}


//==================================================================================================== TranqGrenade

MineData Tranqgrenade
{
	mass = 0.3;
	drag = 1.0;
	density = 2.0;
	elasticity = 0.15;
	friction = 1.0;
	className = "Handgrenade";
	description = "Handgrenade";
	shapeFile = "grenade";
	shadowDetailMask = 4;
	explosionId = mortarExp;
	explosionRadius = 10.0;
	damageValue = 0.55;

	damageType = $EnergyDamageType;

	kickBackStrength = 0;
	triggerRadius = 0.5;
	maxDamage = 2.0;
};

function Tranqgrenade::onAdd(%this)
{
	%data = GameBase::getDataName(%this);
	schedule("Mine::Detonate(" @ %this @ ");",2.0,%this);
}

function Tranqgrenade::onDamage(%this,%type,%value,%pos,%vec,%mom,%object)
{
   if (%type == $MineDamageType)
      %value = %value * 0.25;

	%damageLevel = GameBase::getDamageLevel(%this);
	GameBase::setDamageLevel(%this,%damageLevel + %value);
}

function Tranqgrenade::Detonate(%this)
{
	%data = GameBase::getDataName(%this);
	GameBase::setDamageLevel(%this, %data.maxDamage);

}

//==================================================================================================== EMP Grenade

MineData EMPgrenade
{
	mass = 0.3;
	drag = 1.0;
	density = 2.0;
	elasticity = 0.15;
	friction = 1.0;
	className = "Handgrenade";
	description = "Handgrenade";
	shapeFile = "grenade";
	shadowDetailMask = 4;
	explosionId = LargeShockwave;
	explosionRadius = 25.0;
	damageValue = 0.4;
	damageType = $FlashDamageType;
	kickBackStrength = 50;
	triggerRadius = 0.5;
	maxDamage = 2.0;
};

function EMPgrenade::onAdd(%this)
{
	%data = GameBase::getDataName(%this);
	schedule("Mine::Detonate(" @ %this @ ");",2.0,%this);
}

function EMPgrenade::onDamage(%this,%type,%value,%pos,%vec,%mom,%object)
{
   if (%type == $FlashDamageType)
      %value = %value * 0.25;

	%damageLevel = GameBase::getDamageLevel(%this);
	GameBase::setDamageLevel(%this,%damageLevel + %value);
}


//==================================================================================================== Concussion Grenade

MineData Concussion
{
	mass = 0.3;
	drag = 1.0;
	density = 2.0;
	elasticity = 0.15;
	friction = 1.0;
	className = "Handgrenade";
	description = "Handgrenade";
	shapeFile = "grenade";
	shadowDetailMask = 4;
	explosionId = grenadeExp;
	explosionRadius = 35.0;
	damageValue = 0.50;
	damageType = $PlasmaDamageType;
	kickBackStrength = 350;
	triggerRadius = 0.5;
	maxDamage = 2.0;
};

function Concussion::onAdd(%this)
{
	%data = GameBase::getDataName(%this);
	schedule("Mine::Detonate(" @ %this @ ");",2.0,%this);
}

function Concussion::onDamage(%this,%type,%value,%pos,%vec,%mom,%object)
{
   if (%type == $MineDamageType)
      %value = %value * 0.25;

	%damageLevel = GameBase::getDamageLevel(%this);
	GameBase::setDamageLevel(%this,%damageLevel + %value);
}

function Concussion::Detonate(%this)
{
	%data = GameBase::getDataName(%this);
	GameBase::setDamageLevel(%this, %data.maxDamage);
}

MineData Concussion1
{
	mass = 0.3;
	drag = 1.0;
	density = 2.0;
	elasticity = 0.15;
	friction = 1.0;
	className = "Handgrenade";
	description = "Handgrenade";
	shapeFile = "grenade";
	shadowDetailMask = 4;
	explosionId = grenadeExp;
	explosionRadius = 35.0;
	damageValue = 0.50;
	damageType = $FlareDamageType; //$PlasmaDamageType;
	kickBackStrength = 0;
	triggerRadius = 0.5;
	maxDamage = 2.0;
};

function Concussion1::onAdd(%this)
{
	%data = GameBase::getDataName(%this);
	schedule("Mine::Detonate(" @ %this @ ");",2.0,%this);
}

function Concussion1::onDamage(%this,%type,%value,%pos,%vec,%mom,%object)
{
   if (%type == $MineDamageType)
      %value = %value * 0.25;

	%damageLevel = GameBase::getDamageLevel(%this);
	GameBase::setDamageLevel(%this,%damageLevel + %value);
}

function Concussion1::Detonate(%this)
{
	%data = GameBase::getDataName(%this);
	GameBase::setDamageLevel(%this, %data.maxDamage);
}



// Concussion
MineData Concussion2
{
   mass = 0.3;
   drag = 1.0;
   density = 2.0;
	elasticity = 0.15;
	friction = 1.0;
	className = "Handgrenade";
   description = "Handgrenade";
   shapeFile = "grenade";
   shadowDetailMask = 4;
   explosionId = grenadeExp;
	explosionRadius = 35.0;
	damageValue = 0.50;
	damageType = $FlareDamageType; //$PlasmaDamageType; // burn the victim
	kickBackStrength = 0;
	triggerRadius = 0.5;
	maxDamage = 2.0;
};

function Concussion2::onAdd(%this)
{
	%data = GameBase::getDataName(%this);
	schedule("Mine::Detonate(" @ %this @ ");",5.0,%this);
}

function Concussion2::onDamage(%this,%type,%value,%pos,%vec,%mom,%object)
{
   if (%type == $MineDamageType)
      %value = %value * 0.25;

	%damageLevel = GameBase::getDamageLevel(%this);
	GameBase::setDamageLevel(%this,%damageLevel + %value);
}

function Concussion2::Detonate(%this)
{
	%data = GameBase::getDataName(%this);
	GameBase::setDamageLevel(%this, %data.maxDamage);
}


//==================================================================================================== Plastique

MineData Nukebomb
{
	mass = 0.3;
	drag = 1.0;
	density = 2.0;
	elasticity = 0.0;
	friction = 99.0;
	className = "Handgrenade";
	description = "Plastique";
	shapeFile = "sensor_small";
	shadowDetailMask = 4;
	explosionId = rocketExp;
	explosionRadius = 10.0;
	damageValue = 2.0;
	damageType = $MortarDamageType;
	kickBackStrength = 300;
	triggerRadius = 0.5;
	maxDamage = 2.0;
};

function Nukebomb::onAdd(%this)
{	
	%obj = %this;
	%data = GameBase::getDataName(%this);
}

function Nukebomb::onCollision(%this,%obj)
{
    	if(getObjectType(%obj) != "Player")
	{
        	return;
	}

    	if(Player::isDead(%obj))
	{
        	return;
	}

	%c = Player::getClient(%obj);
	%playerTeam = GameBase::getTeam(%obj);
	%teleTeam = GameBase::getTeam(%this);
	
	%armor = Player::getArmor(%obj);
	if (%armor == "earmor" || %armor == "efemale")
	{
		%rnd = floor(getRandom() * 10);
		if(%rnd > 9) //6
		{	
			Client::sendMessage(%c,1,"OOPS! You cut the wrong wire...");
			%data = GameBase::getDataName(%this);
			GameBase::setDamageLevel(%this, %data.maxDamage);
			return;
		}
		else
		{	
			deleteObject(%this);
			Client::sendMessage(%c,1,"You disarm the Plastique Explosive.");
		}
	}  
}

function Nukebomb::onDamage(%this,%type,%value,%pos,%vec,%mom,%object)
{
   if (%type == $MineDamageType)
      %value = %value * 0.25;

	%damageLevel = GameBase::getDamageLevel(%this);
	GameBase::setDamageLevel(%this,%damageLevel + %value);
}

function Nukebomb::Detonate(%this)
{
	%data = GameBase::getDataName(%this);
	GameBase::setDamageLevel(%this, %data.maxDamage);
}


//==================================================================================================== Mortar Grenade

MineData Mortarbomb
{
	mass = 0.3;
	drag = 1.0;
	density = 2.0;
	elasticity = 0.15;
	friction = 1.0;
	className = "Handgrenade";
	description = "Handgrenade";
	shapeFile = "mortar";
	shadowDetailMask = 4;
	explosionId = mortarExp;

	explosionRadius = 20.0;
	damageValue = 1.0;
	damageType = $MortarDamageType;
	kickBackStrength = 250;
	triggerRadius = 1.5;
	maxDamage = 2.0;
};

function Mortarbomb::onAdd(%this)
{
	%data = GameBase::getDataName(%this);
	schedule("Mine::Detonate(" @ %this @ ");",5.0,%this);
}

function Mortarbomb::onCollision(%this, %object)
{
	%type = getObjectType(%object);
	if (%type == "Player")
	{	
		%data = GameBase::getDataName(%this);
		schedule("Mine::Detonate(" @ %this @ ");",0.1,%this);
	}
}


MineData Mortarbomb2
{
	mass = 0.3;
	drag = 1.0;
	density = 2.0;
	elasticity = 0.15;
	friction = 1.32;
	className = "Handgrenade";
	description = "Handgrenade";
	shapeFile = "mortar"; //"mortarammo";
	shadowDetailMask = 4;
	explosionId = mortarExp;

	explosionRadius = 30.0;
	damageValue = 1.32;
	damageType = $MortarDamageTurret;
	kickBackStrength = 250;
	triggerRadius = 1.5;
	maxDamage = 2.0;
};


function Mortarbomb2::onCollision(%this, %object)
{
	%type = getObjectType(%object);
	if (%type == "Player")
	{	
		%data = GameBase::getDataName(%this);
		schedule("Mine::Detonate(" @ %this @ ");",0.1,%this);
	}
}
//==================================================================================================== Fire Bomb Grenade

MineData Firebomb
{
	mass = 0.3;
	drag = 1.0;
	density = 2.0;
	elasticity = 0.15;
	friction = 1.0;
	className = "Handgrenade";
	description = "Handgrenade";
	shapeFile = "grenade";
	shadowDetailMask = 4;
	explosionId = flashExpLarge;
	explosionRadius = 35.0;
	damageValue = 0.1;
	damageType = $ElectricityDamageType;
	kickBackStrength = 650;
	triggerRadius = 0.5;
	maxDamage = 2.0;
};

function Firebomb::onAdd(%this)
{
	%data = GameBase::getDataName(%this);
	schedule("Mine::Detonate(" @ %this @ ");",2.0,%this);
}

//==================================================================================================== Tesla Grenade

MineData TeslaGren
{
	mass = 0.3;
	drag = 1.0;
	density = 2.0;
	elasticity = 0.15;
	friction = 1.0;
	className = "Handgrenade";
	description = "Handgrenade";
	shapeFile = "grenade";
	shadowDetailMask = 4;
	explosionId = flashExpLarge;
	explosionRadius = 20.0;
	damageValue = 0.5;
	damageType = $ElectricityDamageType;
	kickBackStrength = 0;
	triggerRadius = 0.5;
	maxDamage = 2.0;
};

function TeslaGren::onAdd(%this)
{
	%data = GameBase::getDataName(%this);
	schedule("TeslaGren::Detonate(" @ %this @ ");",2.0,%this);
}

function TeslaGren::Detonate(%this)
{
	%pos = GameBase::getPosition(%this);
	Mine::Detonate(%this);
	//== scatter function goes here
	%cnt = floor(getRandom()*9) + 4;
	%blammo = MiniFusionBolt;
	for (%j=0; %j < %cnt; %j++)
	{
		%neg1 = (floor(getRandom() * 2) * -2) + 1;
		%neg2 = (floor(getRandom() * 2) * -2) + 1;
		%neg3 = (floor(getRandom() * 2) * -2) + 1;	
		%dir = (getRandom() * %neg2 @ " " @ getRandom() * %neg1 @ " " @ getRandom() * %neg3);
		%dir1 = (getRandom() * %neg3 @ " " @ getRandom() * %neg2 @ " " @ getRandom() * %neg1);
		%dir2 = (getRandom() * %neg1 @ " " @ getRandom() * %neg2 @ " " @ getRandom() * %neg3);
		%fired = Projectile::spawnProjectile(%blammo,(%dir @ " " @ %dir1 @ " " @ %dir2 @ " " @ %pos),%this,"0 0 0");
	}
}

//==================================================================================================== Mortar Grenade

MineData Detbomb
{
	mass = 0.3;
	drag = 1.0;
	density = 4.0;
	elasticity = 0.25;
	friction = 1.0;
	className = "Handgrenade";
	description = "Handgrenade";
   	shapeFile = "mine";
	shadowDetailMask = 4;
	explosionId = flashExpLarge;

	explosionRadius = 15.0;
	damageValue = 0.45;
	damageType = $EnergyDamageType;
	kickBackStrength = 250;
	triggerRadius = 1.5;
	maxDamage = 2.0;
};

function Detbomb::onAdd(%this)
{
	%data = GameBase::getDataName(%this);
	schedule("Mine::Detonate(" @ %this @ ");",3.0,%this);
}

function Detbomb::onCollision(%this, %object)
{
	%type = getObjectType(%object);
	if (%type == "Player")
	{	
		%data = GameBase::getDataName(%this);
		schedule("Mine::Detonate(" @ %this @ ");",0.1,%this);
	}
}