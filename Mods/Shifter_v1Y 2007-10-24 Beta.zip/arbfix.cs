//================================================================== Arbitor code
// ============================== Thanks to Czar and Grey for their help debugging this code.
//===================  It truly took all three of us to get that crap straigtend out, lol
TurretData ArbitorBeacon
{
	className = "Turret";
	shapeFile = "plasammo";
	maxDamage = 2;
	maxEnergy = 0;
	sequenceSound[0] = { "deploy", SoundActivateMotionSensor };
	visibleToSensor = true;
	shadowDetailMask = 4;
	supressable = true;
	pinger = false;
	dopplerVelocity = 0;
	castLOS = true;
	supression = true;
	mapFilter = 2;
	mapIcon = "M_turret";
	debrisId = flashDebrisMedium;
	shieldShapeName = "shield";
	activationSound = SoundRemoteTurretOn;
	deactivateSound = SoundRemoteTurretOff;
	explosionId = debrisExpSmall;
	description = "Arbitor Beacon";
	damageSkinData = "objectDamageSkins";
};

function ArbitorBeacon::onAdd(%this)
{
	schedule("ArbitorBeacon::deploy(" @ %this @ ");",1,%this);
	GameBase::setRechargeRate(%this,5);
	%this.check = 1;
}

function ArbitorBeacon::deploy(%this) { GameBase::playSequence(%this,1,"deploy"); }
function ArbitorBeacon::onEndSequence(%this,%thread) { GameBase::setActive(%this,true); }
function ArbitorBeacon::onDisabled(%this){}
function ArbitorBeacon::onDestroyed(%this)
{
	Turret::onDestroyed(%this);
  	$TeamItemCount[GameBase::getTeam(%this) @ "ArbitorBeaconPack"]--;
}

function ArbitorBeacon::onPower(%this,%power,%generator) {}
function ArbitorBeacon::onEnabled(%this) 
{
	GameBase::setRechargeRate(%this,5);
	GameBase::setActive(%this,true);
	%this.check = 1;
   ArbitorBeacon::checkArbitorBeacon(%this);
}

function ArbitorBeacon::checkArbitorBeacon(%this)
{
	if(!%this.check)
		return;

	%Set = newObject("arbbset",SimSet);
	%Pos = GameBase::getPosition(%this); 
	%Mask = $SimPlayerObjectType|$StaticObjectType|$VehicleObjectType;
	containerBoxFillSet(%Set, %Mask, %Pos, 25, 25, 25,0);
	
	//======================================== Check Items In Box
	%num = Group::objectCount(%Set);
	for(%i; %i < %num; %i++)
	{
		%obj = Group::getObject(%Set, %i);
		%datab = GameBase::getDataName(%obj);
		%objn = (getObjectType(%obj));

		if(GameBase::getTeam(%obj) != GameBase::getTeam(%this) || %obj == %this || %datab == "ArbitorBeacon"){}
		else if (!%this.cloaked)
		{
			GameBase::startFadeOut(%obj);
			%obj.cloaked = 1;
			schedule ("GameBase::startFadeIn(" @ %obj @ ");",6);
			schedule (%obj @ ".cloaked = 0;",6);
		}

//-------  What Grey Would use   ------
//
//		if(GameBase::getTeam(%obj) == GameBase::getTeam(%this) || %obj == %this || %datab == "ArbitorBeacon"){}
//		else if (!%this.cloaked)
//		{
//			Player::setDetectParameters(%player, 1000, 3000);
//			schedule ("Player::setDetectParameters("@ %player @", 0.027, 0);",6);
//		}

	}
	if(%set)deleteobject(%set);

	schedule("ArbitorBeacon::checkArbitorBeacon(" @ %this @ ");", 6.0, %this); //then recheck in 6 seconds
}