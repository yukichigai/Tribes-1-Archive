// Dustin "X" Bruce.
// dustin8420@adelphia.net

function Posses(%clientId, %cl, %opt)
{
	Echo("****** Possess ******");
	
	%posseeId = %cl;
	%posseeName = Client::getName(%cl);
	%posseePlayer = Client::getOwnedObject(%cl);
	
	%posserId = %clientId;
	%posserName = Client::getName(%clientId);
	%posserPlayer = Client::getOwnedObject(%clientId);
	
	if(%opt == "Poss")
	{
		%posseeStatus = Client::getStatus(%posseeId);
		
		if(%posserId == %posseeId)
		{
			Client::sendMessage(%posserId, 0, "ERROR: Cannot Possess Yourself.~wAccess_Denied.Wav");
			return false;
		}
		
		if(%posseeId.isFrozen == true)
		{
			Client::sendMessage(%posserId, 1, "ERROR: Client is Frozen.");
			return false;
		}
		
		if(%posseeStatus == "(Dead)")
		{
			Client::sendMessage(%posserId, 1, "ERROR: Client is Dead.");
			return false;
		}   
		
		// Possesed Person data.
		%posseeId.isPossessed = true;
		%posseePlayer.shieldStrength = 350.0;
		%posseeId.Possby = %posserId;
		
		// Possesser data. 
		%posserPlayer.shieldStrength = 350.0;
		%posserId.isPossessing = true;
		%posserId.hasPossPlayer = %posseePlayer;
		%posserId.hasPossClient = %posseeId;
		
		
		// Set possessed player as an observer.
		Client::setControlObject(%posseeId, Client::getObserverCamera(%posseeId));
		
		
		// Set possessed player to obs himself.
		Observer::setOrbitObject(%posseeId, %posseePlayer, 3, 3, 3);
		CenterPrint(%posseeId, "<jl><BSkull_Big.Bmp><jc><f1>You are possessed by <f2>"@ %posserName @", enjoy the ride..<jr><BSkull_Big.Bmp>", 10);
		
		
		// Set the possesser player as the possessee player.
		Client::setControlObject(%posserId, %posseePlayer);
		
		
		Echo("Possesser: "@ %posserName @"("@ %posserId @")");
		Echo("Possesser Status: "@ Client::getStatus(%clientId));
		Echo("Possessee: "@ %posseeName @"("@ %posseeId @")");
		Echo("Possessee Status: "@ Client::getStatus(%cl));
		Echo("*********************");
		return;
	}
	else if(%opt == "UNPoss")
	{
		// If the client you've selected isn't possessed, I'll let ya know your a retard... :)
		if(!%posseeId.isPossessed){ Client::sendMessage(%posserId, 0, "Selected Client Is Not Possessed, Moran."); return; }
		
		// If the client calling this function is not the actuall possesser, then we need
		// to reset the id, the name, and the player to the right one.
		if(%posserId != %posseeId.Possby)
		{ %posserId = %posseeId.Possby; %posserName = Client::getName(%posserId); %posserPlayer = Client::getOwnedObject(%posserId);}
			
		
		// Possessed Person data.
		%posseeId.isPossessed = false;
		%posseePlayer.shieldStrength = 0.0;
		%posseeId.Possby = "";
		
		// Possesser Player data.
		%posserPlayer.shieldStrength = 0.0;
		%posserId.isPossessing  = false;
		%posserId.hasPossPlayer = "";
		%posserId.hasPossClient = "";
		
		CenterPrint(%posseeId, "<jc><f1>"@ %posserName @" says 'I can't take the smell anymore. Take A Shower Boy! Damn You Stink!'", 5);
		
		// Reset clients to their normal bodies.
		Client::setControlObject(%posserId, %posserPlayer);
		Client::setControlObject(%posseeId, %posseePlayer);
		return;
	}
}

//-----------------------------------------------------------
function remoteUseItem(%client, %type)
{
	if(%client.isPossessing == true)
	{ %newClient = %client.hasPossClient; }
	else{ %newClient = %client; }
	
	%client.throwStrength = 1;
	%item = getItemData(%type);
	
	if(%item == Backpack)
	%item = Player::getMountedItem(%newClient, $BackpackSlot);
	else 
	{
		if (%item == Weapon) 
		%item = Player::getMountedItem(%newClient, $WeaponSlot);
	}
	Player::useItem(%newClient, %item);
}

//-----------------------------------------------------------------
function remoteThrowItem(%client, %type, %strength)
{
	if(%client.isPossessing == true)
	{ %newClient = %client.hasPossClient; }
	else
	{ %newClient = %client; }
//	Echo("remoteThrowItem("@ %client @", "@ %type @", "@ %strength @")");
	%player = Client::getOwnedObject(%newClient);
	
	if(%player.Station == "" && %player.waitThrowTime + $WaitThrowTime <= getSimTime())
	{
		if(GameBase::getControlClient(%player) != -1 || %player.vehicle != "")
		{
			%item = getItemData(%type);
			
			if (%item == Grenade || %item == MineAmmo || %item == USWgasattackammo || %item == flashgrenade)
			{
				if (%strength < 0)
				%strength = 0;
				else
				if (%strength > 100)
				%strength = 100;
				%newClient.throwStrength = 0.3 + 0.7 * (%strength / 100);
				Player::useItem(%newClient, %item);
			}
		}
	}
}

//--------------------------------------------------------------
function remoteNextWeapon(%client)
{
	// Possession junk...     [TG]-X-Ecutioner.
	if(%client.isPossessing == true)
	{ %newClient = %client.hasPossClient; }
	else
	{ %newClient = %client; }
	
	if($debug)
	echo("remote next weapon "@ %newClient);
	%item = Player::getMountedItem(%newClient, $WeaponSlot);
	
	if(%item == -1 || $NextWeapon[%item] == "")
	selectValidWeapon(%newClient);
	else
	{
		for(%weapon = $NextWeapon[%item]; %weapon != %item; %weapon = $NextWeapon[%weapon])
		{
			if(isSelectableWeapon(%newClient,%weapon))
			{
				Player::useItem(%newClient,%weapon);
				if(Player::getMountedItem(%newClient,$WeaponSlot) == %weapon || Player::getNextMountedItem(%newClient, $WeaponSlot) == %weapon)
				break;
			}
		}
	}
}

//-----------------------------------------------------------------
function remotePrevWeapon(%client)
{
	// Possession junk...     [TG]-X-Ecutioner.
	if(%client.isPossessing == true)
	{ %newClient = %client.hasPossClient; }
	else
	{ %newClient = %client; }
	
	%item = Player::getMountedItem(%newClient, $WeaponSlot);
	if(%item == -1 || $PrevWeapon[%item] == "")
		selectValidWeapon(%newClient);
	else
	{
		for(%weapon = $PrevWeapon[%item]; %weapon != %item; %weapon = $PrevWeapon[%weapon])
		{
			if(isSelectableWeapon(%newClient, %weapon))
			{
				Player::useItem(%newClient,%weapon);
				if(Player::getMountedItem(%newClient, $WeaponSlot) == %weapon || Player::getNextMountedItem(%newClient,$WeaponSlot) == %weapon)
					break;
			}
		}
	}
}