//Weapons-FixedTarget Training
//--------------------------------------
//all these functions do is set up the scene for each weapon.
//upon killing each target assigned, the next weapon lesson will resume.
exec("game.cs");
if($dedicated)
{
	exec("dm.cs");
	
	
}
else
{
	exec("Training_AI.cs");

	//Globals
	//////////////
	$Train::missionType = "WEAPONS";
	$counter = 0;
	$AIkilled = 0;
	
	//-------------------------------------
	//fixedTargetsBlaster()
	//-------------------------------------
	function fixedTargetsBlaster(%playerId)
	{   
	   //weapon discription
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>This mission will introduce you to some of the many <f3>many <f1>weapons that are available in Shifter.\", 10);", 5);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 5);
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>Ready?\", 10);", 15);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 15);
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>Let's start with the blaster.  This is your basic energy-powered weapon.  It does fairly decent damage against players and items alike.  Only the Goliath and Juggernaught armors cannot carry it.\", 10);", 25);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 25);
	   
	   //mount weapons
	   schedule("Player::setItemCount(" @ %playerId @ ",Blaster, 1);", 25);
	   schedule("Player::mountItem(" @ %playerId @ ", Blaster, 0);", 25);
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>Time to do some shooting!  Somewhere around you a player (<f3>or a close approximation<f1>) is trying to infiltrate your base.  Eliminate 'em with the blaster.\", 10);", 35);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 35);
	   
	   //drone setup
	   %name = "Nailz";
	   %group = "\"MissionGroup\\\\AI\\\\guard1\"";
	   schedule("initAI(" @ %name @ ", " @ %group @ ", marmor);", 35);
	   schedule("setTarget(" @ %playerId @ ", " @ %name @ ");", 35);
	   $counter++;
	}
	
	//-------------------------------------
	//fixedTargetsHyperBlaster()
	//-------------------------------------
	function fixedTargetsHyperBlaster(%playerId)
	{   
	   //weapon discription
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>Now that you have seen the Blaster, why don't we check out the Hyper Blaster.\", 10);", 5);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 5);
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>The Hyper Blaster can only be carried by three armors: Scout, Mercenary and Arbitor.  Let's get in one of those armors.\", 10);", 15);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 15);
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>The Hyper Blaster fires three times faster than the Blaster, but does half as much damage per shot.  It also has a shorter range.\", 10);", 25);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 25);
	   
	   //mount weapons
	   if(Player::getArmor(%playerId) == "larmor")
		schedule("Player::setArmor(" @ %playerId @ ",sarmor);", 20);
	   else
		schedule("Player::setArmor(" @ %playerId @ ",sfemale);", 20);
	
	   schedule("messageAll(1, \"Now wearing Scout armor.\");", 20);
	   schedule("Player::setItemCount(" @ %playerId @ ",Blaster, 0);", 25);
	   schedule("Player::setItemCount(" @ %playerId @ ",HyperB, 1);", 25);
	   schedule("Player::mountItem(" @ %playerId @ ", HyperB, 0);", 25);
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>Another enemy is in your base, this time a bit closer.  Find them and use the Hyper Blaster to dispatch them quickly.\", 10);", 35);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 35);
	   
	   //drone setup
	   %name = "\"[TCSA] Spam Man\"";
	   %group = "\"MissionGroup\\\\AI\\\\guard2\"";
	   schedule("initAI(" @ %name @ ", " @ %group @ ", earmor);", 35);
	   schedule("setTarget(" @ %playerId @ ", " @ %name @ ");", 35);
	   $counter++;
	}
	
	//----------------------------------
	//fixedTargetsPlasma()
	//----------------------------------
	function fixedTargetsPlasma(%playerId)
	{   
	   //discription of weapon
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>Next is the plasma gun.\", 10);", 10);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 10);
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>The plasma gun is a good weapon against most armors.  It has three separate firing modes, accessed through the tab-key score menu. \", 10);", 20);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 20);
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>Go to the menu and select <f3>Weapon Options<f1>, then <f3>Plasma Options<f1>.  Any of the three firing modes will do for this training exercise.\", 10);",30);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 30);
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>This time an enemy in Dreadnaught armor has inflitrated your base.  Use the plasma gun and take him out.\", 10);", 40);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 40);
	   
	   //mount weapon
	   schedule("Player::setItemCount(" @ %playerId @ ",HyperB, 0);", 12);
	   schedule("Player::setItemCount(" @ %playerId @ ",Plasmagun, 1);", 12);
	   schedule("Player::setItemCount(" @ %playerId @ ",PlasmaAmmo, 100);", 45);
	   schedule("Player::mountItem(" @ %playerId @ ", Plasmagun, 0);", 12);
	   
	   //drone details
	   %name = "SymLink";
	   %group = "\"MissionGroup\\\\AI\\\\guard2\"";
	   schedule("initAI(" @ %name @ " ," @  %group @ " , darmor);", 45);
	   schedule("setTarget(" @ %playerId @ ", " @ %name @ ");", 45);
	   $counter++;
	}
	
	//--------------------------------------
	//fixedTargetsChain()
	//--------------------------------------
	function fixedTargetsChain(%playerId)
	{   
	   //weapon discription
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>Next, the Equalizer.  In some versions of Shifter this does relatively low damage, but in this particular one it tears through most armors.\", 10);", 10);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 10);
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>The Equalizer can be carried by most armors.  It fires explosive-tipped rounds which do massive damage but move very slowly, making it difficult to use in some cases.\", 10);", 20);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 20);
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>Fire a few rounds to get an idea of how the Equalizer works.  Try and take out the target that is crossing your path below your base tower.\", 10);", 30);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 30);
	
	   //weapon mounting
	   schedule("Player::setItemCount(" @ %playerId @ ",Chaingun, 1);", 12);
	   schedule("Player::setItemCount(" @ %playerId @ ",bulletAmmo, 10000);", 35);
	   schedule("Player::setItemCount(" @ %playerId @ ",disclauncher, 0);", 12);
	   schedule("Player::setItemCount(" @ %playerId @ ",discAmmo, 0);", 12);
	   schedule("Player::mountItem(" @ %playerId @ ", Chaingun, 0);", 12);
	   
	   //drone stuff
	   %name = "Slacker";
	   %group = "\"MissionGroup\\\\AI\\\\guard4\"";
	   schedule("initAI(" @ %name @ " ," @  %group @ " , barmor);", 35);
	   schedule("setTarget(" @ %playerId @ ", " @ %name @ ");", 35);
	   $counter++;
	}
	    
	//-----------------------------------
	//fixedTargetsdisc()
	//-----------------------------------
	function fixedTargetsdisc(%playerId)
	{   
	   //discribe the weapon
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>The next weapon available to you is the Disc Launcher.\", 10);", 10);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 10);
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>For light armors this weapon is invaluable.  While it doesn't measure up to the power of the Rocket Launcher directly, the Disc Launcher makes up for it in ammo capacity and availability.\", 10);", 20);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 20);
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>The best way to get a feel for this weapon is to shoot some discs.  See if you can find an enemy tribesman wandering around your tower, and take 'em out!\", 10);", 30);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 30);
	   
	   //mount the correct weapon
	   schedule("Player::setItemCount(" @ %playerId @ ",Disclauncher, 1);", 12);
	   schedule("Player::setItemCount(" @ %playerId @ ",Plasmagun, 0);", 12);
	   schedule("Player::setItemCount(" @ %playerId @ ",DiscAmmo, 100);", 32);
	   schedule("Player::mountItem(" @ %playerId @ ", Disclauncher, 0);", 12);
	   
	   //create a drone for them to shoot 
	   %name = "\"Cornboy!\"";
	   %group = "\"MissionGroup\\\\AI\\\\guard3\"";
	   schedule("initAI(" @ %name @ " ," @  %group @ " , spyarmor);", 35);
	   schedule("setTarget(" @ %playerId @ ", " @ %name @ ");", 35);
	   $counter++;
	}
	
	//-----------------------------------
	//fixedTargetsVulcan()
	//-----------------------------------
	function fixedTargetsVulcan(%playerId)
	{   
	   //discribe the weapon
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>Now it is time to try the Vulcan.\", 10);", 10);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 10);
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>Unlike the Equalizer the Vulcan is limited to only two armors: Mercenary and Dreadnaught.\", 10);", 20);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 20);
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>The Vulcan fires normal bullets, but at a <f3>very<f1> fast rate of fire.  Find the enemy and see if you can't kill him quicker than the last one.\", 10);", 30);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 30);
	   
	   //mount the correct weapon
	   if(Player::getArmor(%playerId) == "sarmor")
		schedule("Player::setArmor(" @ %playerId @ ",marmor);", 20);
	   else
		schedule("Player::setArmor(" @ %playerId @ ",mfemale);", 20);
	
	   schedule("messageAll(1, \"Now wearing Mercenary armor.\");", 20);
	   schedule("Player::setItemCount(" @ %playerId @ ",Chaingun, 0);", 22);
	   schedule("Player::setItemCount(" @ %playerId @ ",Vulcan, 1);", 22);
	   schedule("Player::setItemCount(" @ %playerId @ ",VulcanAmmo, 700);", 32);
	   schedule("Player::setItemCount(" @ %playerId @ ",BulletAmmo, 0);", 22);
	   schedule("Player::mountItem(" @ %playerId @ ", Vulcan, 0);", 22);
	   
	   //create a drone for them to shoot 
	   %name = "\"ll'\"";
	   %group = "\"MissionGroup\\\\AI\\\\guard3\"";
	   schedule("initAI(" @ %name @ " ," @  %group @ " , earmor);", 35);
	   schedule("setTarget(" @ %playerId @ ", " @ %name @ ");", 35);
	   $counter++;
	}
	
	//-----------------------------------
	//fixedTargetsSniper
	//-----------------------------------
	function fixedTargetsSniper(%playerId)
	{   
	   //discribe weapon
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>While base Tribes places much emphasis on the Laser Rifle, Shifter's prime sniper weapon is the Sniper Rifle.\", 10);", 5);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 5);
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>This weapon fires a bullet at almost instant speed.  Unfortunately this weapon is only weilded by the Assassin armor.\", 10);", 15);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 15);
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>The zoom feature enhances the value of the Sniper Rifle immensely. The default zoom key is E. To change the magnification, press the Z key.  You can change the magnification to two, five, ten or even twenty times normal vision!\", 10);", 25);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 25);
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>Since a head shot deals more damage than a shot to other parts of the body, being able to use the zoom feature quickly and accurately can make the difference between killing or being killed.\", 10);", 35);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 35);
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>Zoom in on an enemy tribesmen and take him out. Use your compass to locate the enemy to the north of you, then take him out with the Sniper Rifle.\", 10);", 45);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 45);
	
	   //mount weapon
	   if(Player::getArmor(%playerId) == "marmor")
		schedule("Player::setArmor(" @ %playerId @ ",larmor);", 18);
	   else
		schedule("Player::setArmor(" @ %playerId @ ",lfemale);", 18);
	
	   schedule("messageAll(1, \"Now wearing Assassin armor.\");", 18);
	   schedule("Player::setItemCount(" @ %playerId @ ",Vulcan, 0);", 18);
	   schedule("Player::setItemCount(" @ %playerId @ ",SniperRifle, 1);", 18);
	   schedule("Player::setItemCount(" @ %playerId @ ",SniperAmmo, 50);", 18);
	   schedule("Player::mountItem(" @ %playerId @ ", SniperRifle, 0);", 18);
	
	   //setup target to shoot
	   %group = "\"MissionGroup\\\\AI\\\\guard5\"";
	   %name = "\"GotM*lk?\"";
	   schedule("initAI(" @ %name @ " ," @  %group @ " , marmor);", 45);
	   schedule("setTarget(" @ %playerId @ ", " @ %name @ ");", 45);
	   $counter++;
	
	}
	
	//-----------------------------------
	//fixedTargetsRailgun
	//-----------------------------------
	function fixedTargetsRailgun(%playerId)
	{   
	   //discribe weapon
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>Another sniper weapon is the Railgun.  The Railgun does more damage than the Sniper Rifle, but has less ammo capacity and is somewhat slower.\", 10);", 5);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 5);
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>The Railgun is also used by the Assassin armor, but can also be used by the Engineer armor.\", 10);", 15);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 15);
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>It looks like reinforcements have arrived.  Use the Railgun and take her out.\", 10);", 25);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 25);
	   //mount weapon
	   if(Player::getArmor(%playerId) == "larmor")
		schedule("Player::setArmor(" @ %playerId @ ",earmor);", 18);
	   else
		schedule("Player::setArmor(" @ %playerId @ ",efemale);", 18);
	
	   schedule("messageAll(1, \"Now wearing Engineer armor.\");", 18);
	   schedule("Player::setItemCount(" @ %playerId @ ",Railgun, 1);", 18);
	   schedule("Player::setItemCount(" @ %playerId @ ",Railammo, 25);", 18);
	   schedule("Player::setItemCount(" @ %playerId @ ",SniperRifle, 0);", 18);
	   schedule("Player::setItemCount(" @ %playerId @ ",SniperAmmo, 0);", 18);
	   schedule("Player::mountItem(" @ %playerId @ ", Railgun, 0);", 18);
	
	   //setup target to shoot
	   %group = "\"MissionGroup\\\\AI\\\\guard5\"";
	   %name = "TierDrop";
	   schedule("initAI(" @ %name @ " ," @  %group @ " , afemale);", 25);
	   schedule("setTarget(" @ %playerId @ ", " @ %name @ ");", 25);
	   $counter++;
	
	}
	
	
	//---------------------------------------
	//fixedTargetsGrenade()
	//---------------------------------------
	function fixedTargetsGrenade(%playerId)
	{   
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>On to a more explosive weapon!  Let's take a look at the grenade launcher.  This weapon can be carried by all but two armors: Juggernaught and Arbitor.\", 10);", 5);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 5);
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>The grenades fired from this weapon have a timed impact detonation fuse.  After a certain time they will detonate on collision with an object.\", 10);", 15);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 15);
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>An enemy tribesman is thinking of trying to hide in a bunker.  Time to teach him the error of his ways.\", 10);", 25);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 25);
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>Watch the bunker at the bottom of your base tower.  Fire a couple of grenades when you see the enemy tribesman run inside.\", 10);", 35);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 35);
	
	   //mount weapon
	   schedule("Player::setItemCount(" @ %playerId @ ",grenadeAmmo, 50);", 40);
	   schedule("Player::setItemCount(" @ %playerId @ ",Railgun, 0);", 8);
	   schedule("Player::setItemCount(" @ %playerId @ ",Railammo, 0);", 8);
	   schedule("Player::setItemCount(" @ %playerId @ ",grenadelauncher, 1);", 8);
	   schedule("Player::mountItem(" @ %playerId @ ", grenadelauncher, 0);", 8);
	
	   //setup target to shoot
	   %group1 = "\"MissionGroup\\\\AI\\\\guard6\"";
	   %name1 = "Skeet";
	   schedule("initAI(" @ %name1 @ " ," @  %group1 @ " , barmor);", 40);
	   schedule("setTarget(" @ %playerId @ ", " @ %name1 @ ");", 40);
	   $counter++;
	}
	
	//---------------------------------------
	//fixedTargetsMortar()
	//---------------------------------------
	function fixedTargetsMortar(%playerId)
	{   
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>Now that you've seen the Grenade Launcher, try the Mortar on for size.\", 10);", 5);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 5);
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>While it is no doubt a powerful weapon, it can only be used by three armors: Golaith, Dreadnaught and Juggernaught.\", 10);", 15);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 15);
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>The Mortar has four firing modes, also accessed in the tab-key score menu.  Select <f3>Weapon Options<f1>, then <f3>Mortar Options <f1>to choose a firing mode.\", 10);", 25);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 25);
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>Once again some fool tribesman is trying to hide in the bunker.  Use any one of the Mortar's firing modes and take him out.\", 10);", 35);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 35);
	
	   //mount weapon
	   if(Player::getArmor(%playerId) == "earmor")
		schedule("Player::setArmor(" @ %playerId @ ",barmor);", 18);
	   else
		schedule("Player::setArmor(" @ %playerId @ ",bfemale);", 18);
	
	   schedule("messageAll(1, \"Now wearing Golaith armor.\");", 18);
	
	   schedule("Player::setItemCount(" @ %playerId @ ",grenadeAmmo, 0);", 18);
	   schedule("Player::setItemCount(" @ %playerId @ ",Mortar, 1);", 18);
	   schedule("Player::setItemCount(" @ %playerId @ ",MortarAmmo, 50);", 18);
	   schedule("Player::setItemCount(" @ %playerId @ ",grenadelauncher, 0);", 18);
	   schedule("Player::mountItem(" @ %playerId @ ", Mortar, 0);", 18);
	
	   //setup target to shoot
	   %group1 = "\"MissionGroup\\\\AI\\\\guard6\"";
	   %name1 = "Vorpaxz";
	   schedule("initAI(" @ %name1 @ " ," @  %group1 @ " , darmor);", 35);
	   schedule("setTarget(" @ %playerId @ ", " @ %name1 @ ");", 35);
	   $counter++;
	}
	
	//---------------------------------------
	//fixedTargetsRocket()
	//---------------------------------------
	function fixedTargetsRocket(%playerId)
	{   
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>Remember the Disc Launcher?  Well here is its big brother, the Rocket Launcher.\", 10);", 5);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 5);
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>The Rocket Launcher is carried by most medium and all heavy armors.  However, the Juggernaught and Dreadnaught armors can carry packs which fire rockets as well.\", 10);", 15);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 15);
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>There are also different firing modes for the Rocket Launcher, but not for the Rocket Launcher Backpack.  Go to <f3>Weapon Options<f1> and then <f3>Rocket Options<f1> to change them.\", 10);", 25);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 25);
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>Another intruder has entered the base. (<f3>Say, he looks familiar<f1>) Try any of the various firing modes. (<f3>Wire Guided does the most damage, but is the hardest to use<f1>)\", 10);", 35);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 35);
	
	   //mount weapon
	   schedule("Player::setArmor(" @ %playerId @ ",darmor);", 18);
	   schedule("messageAll(1, \"Now wearing Dreadnaught armor.\");", 18);
	
	   schedule("Player::setItemCount(" @ %playerId @ ",MortarAmmo, 0);", 18);
	   schedule("Player::setItemCount(" @ %playerId @ ",Mortar, 0);", 18);
	   schedule("Player::setItemCount(" @ %playerId @ ",RocketLauncher, 1);", 18);
	   schedule("Player::setItemCount(" @ %playerId @ ",RocketAmmo, 25);", 18);
	   schedule("Player::setItemCount(" @ %playerId @ ",SMRPack, 1);", 18);
	   schedule("Player::setItemCount(" @ %playerId @ ",AutoRocketAmmo, 25);", 18);
	   schedule("Player::mountItem(" @ %playerId @ ", RocketLauncher, 0);", 18);
	   schedule("Player::mountItem(" @ %playerId @ ", SMRPack, 1);", 18);
	
	   //setup target to shoot
	   %group1 = "\"MissionGroup\\\\AI\\\\guard2\"";
	   %name1 = "\"Y|yukichigai\"";
	   schedule("initAI(" @ %name1 @ " ," @  %group1 @ " , darmor);", 35);
	   schedule("setTarget(" @ %playerId @ ", " @ %name1 @ ");", 35);
	   $counter++;
	}
	
	//---------------------------------------
	//fixedTargetsNuke()
	//---------------------------------------
	function fixedTargetsNuke(%playerId)
	{   
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>Now if you have been following what has been said you get the idea that Juggernaught is a very special armor.\", 10);", 5);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 5);
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>The Juggernaught armor is indeed special, weiding the most powerful weapons in Shifter.  However its weapon selection is limited to only a few choice weapons.\", 10);", 15);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 15);
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>Any player in Juggernaught armor carries a Rocket Launcher, a Mortar and a weapon of mass destruction.  Juggernaughts also have automatic shielding which engages whenever they are damaged.\", 10);", 25);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 25);
	   schedule("bottomprint(" @ %playerId @ ", \"<f1><jc>It looks like one more enemy has made it into the base a little behind the others, and for a good reason: this player is in Juggernaught armor, and a Juggernaught won't die easy.  Cycle through your weapons and find one that will do the job.\", 10);", 35);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 35);
	
	   //mount weapon
	   schedule("Player::setArmor(" @ %playerId @ ",jarmor);", 18);
	   schedule("messageAll(1, \"Now wearing Juggernaught armor.\");", 18);
	
	   schedule("Player::setItemCount(" @ %playerId @ ",MortarAmmo, 25);", 18);
	   schedule("Player::setItemCount(" @ %playerId @ ",Mortar, 1);", 28);
	   schedule("Player::setItemCount(" @ %playerId @ ",RocketLauncher, 1);", 18);
	   schedule("Player::setItemCount(" @ %playerId @ ",RocketAmmo, 25);", 28);
	   schedule("Player::setItemCount(" @ %playerId @ ",SMRPack2, 1);", 18);
	   schedule("Player::setItemCount(" @ %playerId @ ",AutoRocketAmmo, 25);", 28);
	   schedule("Player::mountItem(" @ %playerId @ ", RocketLauncher, 0);", 18);
	   schedule("Player::mountItem(" @ %playerId @ ", SMRPack2, 1);", 18);
	   schedule("Player::setItemCount(" @ %playerId @ ",MFGL, 1);", 28);
	   schedule("Player::setItemCount(" @ %playerId @ ",MFGLAmmo, 4);", 28);
	
	   //setup target to shoot
	   %group1 = "\"MissionGroup\\\\AI\\\\guard2\"";
	   %name1 = "ArchAngel";
	   schedule("initAI(" @ %name1 @ " ," @  %group1 @ " , jarmor);", 35);
	   schedule("setTarget(" @ %playerId @ ", " @ %name1 @ ");", 35);
	   $counter++;
	}
	
	//-------------------------------
	//weaponsStart()
	//-------------------------------
	function weaponsStart(%clientId)
	{
	  fixedTargetsBlaster(%clientId);
	}
	
	//-------------------------------
	//initAi()
	//-------------------------------
	function initAI(%name, %group, %armor)
	{
	  createAI(%name, %group, %armor, %name);
	}
	
	//-------------------------------
	//Game:playerSpawned()
	//-------------------------------
	function Game::playerSpawned(%pl, %clientId, %armor)
	{
	   replenishAmmo();
	} 
	
	//--------------------------------
	//AI::onDroneKilled()
	//--------------------------------
	function AI::onDroneKilled(%aiName)
	{
	  %clientId = 2049;
	  //kill thy vehicle creater!
	  if(%aiName == "Nailz")
	  {
	    fixedTargetsHyperBlaster(%clientId); //fixedTargetsPlasma(%clientId);
		bottomprint(%clientId, "<f1><jc>A most righteous blaster kill.", 5);
		$AIkilled++;
		ObjectiveScreen();
	  }
	  if(%aiName == "[TCSA] Spam Man")
	  {
	    fixedTargetsPlasma(%clientId);
		bottomprint(%clientId, "<f1><jc>That'll teach him!", 5);
		$AIkilled++;
		ObjectiveScreen();
	  }
	  //symlink? hmmm enjoy it cuz it won't happen often. Killing him that is.
	  else if(%aiName == "SymLink")
	  {
	    fixedTargetsDisc(%clientId);
		bottomprint(%clientId, "<f1><jc>Fried to a golden brown.", 5);
		$AIkilled++;
		ObjectiveScreen();
	  }
	  //kill thy mission building God!
	  else if(%aiName == "Cornboy!")
	  {
	    fixedTargetsChain(%clientId);
		bottomprint(%clientId, "<f1><jc>He's going home in a box.", 5);
		$AIkilled++;
		ObjectiveScreen();
	  }
	  //kill thy master of the engine.
	  else if(%aiName == "Slacker")
	  {
	    fixedTargetsVulcan(%clientId); //fixedTargetsSniper(%clientId);
		bottomprint(%clientId, "<f1><jc>Looks like someone took a meat tenderizer to him.", 5);
		$AIkilled++;
		ObjectiveScreen();
	  }
	  else if(%aiName == "ll'")
	  {
	    fixedTargetsSniper(%clientId);
		bottomprint(%clientId, "<f1><jc>Anybody feel like hamburgers?", 5);
		$AIkilled++;
		ObjectiveScreen();
	  }
	  //one word, 9 lives! Make every shot count.
	  else if(%aiName == "GotM*lk?")
	  {
	    fixedTargetsRailgun(%clientId); //fixedTargetsGrenade(%clientId);
		bottomprint(%clientId, "<f1><jc>Oooo, in the eye!", 5);
		$AIkilled++;
		ObjectiveScreen();
	  }
	  else if(%aiName == "TierDrop")
	  {
	    fixedTargetsGrenade(%clientId);
		bottomprint(%clientId, "<f1><jc>Yep, she's definitely dead.", 5);
		$AIkilled++;
		ObjectiveScreen();
	  }
	  //kill thy compiler of the Gods!
	  else if(%aiName == "Skeet")
	  {
	    fixedTargetsMortar(%clientId); //endMission(%clientId);
		bottomprint(%clientId, "<f1><jc>He he, BOOM!!!", 5);
		$AIkilled++;
		ObjectiveScreen();
	  }
	  else if(%aiName == "Vorpaxz")
	  {
	    fixedTargetsRocket(%clientId);
		bottomprint(%clientId, "<f1><jc>Zigged when he should have zagged.", 5);
		$AIkilled++;
		ObjectiveScreen();
	  }
	  else if(%aiName == "Y|yukichigai")
	  {
	    fixedTargetsNuke(%clientId);
		bottomprint(%clientId, "<f1><jc>Not just any kind of death, mind you, but <f3>flying<f1> death.", 5);
		$AIkilled++;
		ObjectiveScreen();
	  }
	  else if(%aiName == "ArchAngel")
	  {
	    endMission(%clientId);
		bottomprint(%clientId, "<f1><jc>If he's not dead, neither is Elvis.", 5);
		$AIkilled++;
	  }
	}  
	
	//----------------------------------
	//endMission()
	//----------------------------------
	function endMission(%clientId)
	{
	  %name = Client::getName(%clientId);
	  %String = "\"<f1><jc>All-righty then " @ %name @ ", you have just completed the Shifter Weapons Training Mission!\"";
	  schedule("bottomprint(" @ %clientId @ ", " @ %String @ " , 10);", 5);
	  schedule("messageAll(0, \"~wshell_click.wav\");", 5); 
	  schedule("Training::MissionComplete(" @ %clientId @ ");", 15);
	}
	
	//----------------------------------
	//StayInBounds()
	//----------------------------------
	function StayInBounds(%clientId)
	{ 
		%player = Client::getOwnedObject(%clientId);
		%flash = 0.4;
		Player::setDamageFlash(%player, %flash);
		%pos = "203.811 -532.056 176.938";
		messageAll(0, "You must Stay inside your base!" @ "~wshieldhit.wav");
		GameBase::setPosition(%ClientId, %pos);
	} 
	   
	//------------------------------------------
	//GroupTrigger::onLeave()
	//------------------------------------------
	function GroupTrigger::onLeave(%this, %object)
	{ 
	   %clId = Client::getFirst();
	   //The trigger stuff is not completely reliable, so we'll try our own 
	   //hard-coded rough check here as well:
	   %pos = Gamebase::getPosition( %clId );
	
	   %x = getWord(%pos, 0 );
	   %y = getWord(%pos, 1 );
	   %z = getWord(%pos, 2 );
	
	   // Seems to work pretty well.  You can get on top of the platform now.  I increased
	   // the Z so you can fly pretty high (it will cause the call to the else{} below.
	   //
	   // This has the "side effect" that there now IS a way to leave the platform, but you 
	   // have to try, and I think it qualifies as an easter egg rather than a bug.  
	   if( %x < 193 || %x > 212 || %y < -539 || %y > -521 || %z < 175 || %z > 250 )
	   {
	      dbecho(2,"Out of Bounds!");
	      StayInBounds(%clId);
	   }
	   else
	   {
	      dbecho(2,"onLeave() erroneously called in Weapons Training");
	   }
	} 
	
	//----------------------------------
	//setTarget()
	//----------------------------------
	function setTarget(%playerId, %name)
	{
		%id = AI::getId(%name);
		%targIdx = (%id - 2048);
		issueTargCommand(%playerId, %playerId, 1,"Waypoint set to target", %targIdx);
	}				
	
	//----------------------------------
	//missionSummary()
	//----------------------------------
	function missionSummary()
	{
	   %time = getSimTime();
	   
	   Training::displayBitmap(0);
	   Team::setObjective(0, 1, "<f5><jl>Mission Completion:");
	   Team::setObjective(0, 2, "<f1>   -Completed:");
	   Team::setObjective(0, 3, "\n");
	   Team::setObjective(0, 4, "<f5><jl>Mission Information:");
	   Team::setObjective(0, 5, "<f1>   -Mission Name: Introduction to Weapons");
	   Team::setObjective(0, 6, "\n");
	   
	   Team::setObjective(0, 7, "<f5><j1>Mission Summary:");
	   
	   Team::setObjective(0, 8, "<f1>   -Total Mission Time: " @ "<f1>" @ Time::getMinutes(%time) @ " Minutes " @ Time::getSeconds(%time) @ " Seconds");
	   Team::setObjective(0, 9, "\n");
	   Team::setObjective(0, 10, "\n");
	   Team::setObjective(0, 11, "\n");
	   Team::setObjective(0, 12, "\n");
	   Team::setObjective(0, 13, "\n");
	   Team::setObjective(0, 14, "\n");
	}
	
	//--------------------------------------
	//Training::missionComplete()
	//--------------------------------------
	function Training::missionComplete(%cl)
	{
	  Client::setGuiMode(%cl, $GuiModeObjectives);
	  missionSummary();
	  remoteEval(2049, TrainingEndMission);
	}
	
	//-------------------------------------
	//remoteTrainingEndMission()
	//-------------------------------------
	function remoteTrainingEndMission()
	{
	   schedule("EndGame();", 8);
	}
	
	//------------------------------------
	//replenishAmmo()
	//------------------------------------
	function replenishAmmo()
	{
	  %playerId = 2049;
	  
	  if($counter == 2)
	    Player::setItemCount(%playerId, PlasmaAmmo, 100);						  
	  else if($counter == 4)
	    Player::setItemCount(%playerId, bulletAmmo, 100);
	  else if($counter == 3)
	    Player::setItemCount(%playerId, discAmmo, 100);
	  else if($counter == 5)
	    Player::setItemCount(%playerId ,grenadeAmmo, 100);
	  schedule("replenishAmmo();", 30);
	}
	
	//--------------------------------------------
	//Game::initialMissionDrop()
	//--------------------------------------------
	function Game::initialMissionDrop(%clientId)
	{
	   GameBase::setTeam(%clientId, 0);
	   Client::setGuiMode(%clientId, $GuiModePlay);
	   Game::playerSpawn(%clientId, false);
	
	   schedule("bottomprint(" @ %clientId @ ", \"<f1><jc>Training Mission 2 - Weapon Introduction.\", 5);", 0);
	   schedule("messageAll(0, \"~wshell_click.wav\");", 0); 
	   schedule("weaponsStart(" @ %clientId @ ");", 5);
		Training::displayBitmap(0);
		objectiveScreen();
	}
	
	//------------------------------------------------
	//ObjectiveScreen()
	//------------------------------------------------
	function ObjectiveScreen()
	{
	   %time = getSimTime() - $MatchStartTime;
	   Training::displayBitmap(0);
	   Team::setObjective(0, 1, "<f5><jl>Mission Completion:");
	   Team::setObjective(0, 2, "<f1>   -Firing range: Weapons training in progress");
	   Team::setObjective(0, 3, "\n");
	   Team::setObjective(0, 4, "<f5><jl>Mission Information:");
	   Team::setObjective(0, 5, "<f1>   -Mission Name: Introduction to Weapons");
	   Team::setObjective(0, 6, "\n");
	   
	   Team::setObjective(0, 7, "<f5><j1>Mission Summary:");
	   Team::setObjective(0, 8, "<f1>   -Total Mission Time: " @ "<f1>" @ Time::getMinutes(%time) @ " Minutes " @ Time::getSeconds(%time) @ " Seconds");
	   Team::setObjective(0, 9, "<f1>   -Total kills: " @ $AIkilled @ " out of 6");
	   
	   Team::setObjective(0, 10, "\n");
	   Team::setObjective(0, 11, "\n");
	   Team::setObjective(0, 12, "\n");
	   Team::setObjective(0, 13, "\n");
	   Team::setObjective(0, 14, "\n");
	}
	
	//----------------------------------------
	//Player::onDamage()
	//----------------------------------------
	//function Player::onDamage(%this,%type,%value,%pos,%vec,%mom,%vertPos,%quadrant,%object)
	//{
	//  if(Player::getClient(%this) != Client::getFirst())	
	//  {	
	//	if (Player::isExposed(%this)) {
	//      %damagedClient = Player::getClient(%this);
	//     %shooterClient = %object;
	
	//		Player::applyImpulse(%this,%mom);
	//		if($teamplay && %damagedClient != %shooterClient && Client::getTeam(%damagedClient) == Client::getTeam(%shooterClient) ) {
	//			if (%shooterClient != -1) {
	//				%curTime = getSimTime();
	//			   if ((%curTime - %this.DamageTime > 3.5 || %this.LastHarm != %shooterClient) && %damagedClient != %shooterClient && $Server::TeamDamageScale > 0) {
	//					Client::sendMessage(%damagedClient,0,"You took Friendly Fire from " @ Client::getName(%shooterClient) @ "!");
	//					Client::sendMessage(%shooterClient,0,"You just harmed Teammate " @ Client::getName(%damagedClient) @ "!");
	//					%this.LastHarm = %shooterClient;
	//					%this.DamageStamp = %curTime;
	//				}
	//			}
	//			%friendFire = $Server::TeamDamageScale;
	//		}
	//		else 
	//			%friendFire = 1.0;	
	//
	//		if (!Player::isDead(%this)) {
	//			%armor = Player::getArmor(%this);
	//			//More damage applyed to head shots
	//			if(%vertPos == "head" && %type == $LaserDamageType) {
	//				if(%armor == "harmor") { 
	//					if(%quadrant == "middle_back" || %quadrant == "middle_front" || %quadrant == "middle_middle") {
	//						%value += (%value * 0.3);
	//					}
	//				}
	//				else {
	//					%value += (%value * 0.3);
	//				}
	//			}
	//			//If Shield Pack is on
	//			if (%type != -1 && %this.shieldStrength) {
	//				%energy = GameBase::getEnergy(%this);
	//				%strength = %this.shieldStrength;
	//				if (%type == $ShrapnelDamageType || %type == $MortarDamageType)
	//					%strength *= 0.75;
	//				%absorb = %energy * %strength;
	//				if (%value < %absorb) {
	//					GameBase::setEnergy(%this,%energy - ((%value / %strength)*%friendFire));
	//					%thisPos = getBoxCenter(%this);
	//					%offsetZ =((getWord(%pos,2))-(getWord(%thisPos,2)));
	//					GameBase::activateShield(%this,%vec,%offsetZ);
	//					%value = 0;
	//				}
	//				else {
	//					GameBase::setEnergy(%this,0);
	//					%value = %value - %absorb;
	//				}
	//			}
	//			if (%value) {
	//				%value = $DamageScale[%armor, %type] * %value * %friendFire;
	//            %dlevel = GameBase::getDamageLevel(%this) + %value;
	//            %spillOver = %dlevel - %armor.maxDamage;
	//				GameBase::setDamageLevel(%this,%dlevel);
	//				%flash = Player::getDamageFlash(%this) + %value * 2;
	//				if (%flash > 0.75) 
	//					%flash = 0.75;
	//				Player::setDamageFlash(%this,%flash);
	//				//If player not dead then play a random hurt sound
	//				if(!Player::isDead(%this)) { 
	//					if(%damagedClient.lastDamage < getSimTime()) {
	//						%sound = radnomItems(3,injure1,injure2,injure3);
	//						playVoice(%damagedClient,%sound);
	//						%damagedClient.lastdamage = getSimTime() + 1.5;
	//					}
	//				}
	//				else {
	//               if(%spillOver > 0.5 && (%type== $ExplosionDamageType || %type == $ShrapnelDamageType || %type== $MortarDamageType|| %type == $MissileDamageType)) {
	//		 				Player::trigger(%this, $WeaponSlot, false);
	//						%weaponType = Player::getMountedItem(%this,$WeaponSlot);
	//						if(%weaponType != -1)
	//							Player::dropItem(%this,%weaponType);
	  //              	Player::blowUp(%this);
	//					}
	//					else
	//					{
	//						if ((%value > 0.40 && (%type== $ExplosionDamageType || %type == $ShrapnelDamageType || %type== $MortarDamageType || %type == $MissileDamageType )) || (Player::getLastContactCount(%this) > 6) ) {
	//					  		if(%quadrant == "front_left" || %quadrant == "front_right") 
	//								%curDie = $PlayerAnim::DieBlownBack;
	//							else
	//								%curDie = $PlayerAnim::DieForward;
	//						}
	//						else if( Player::isCrouching(%this) ) 
	//							%curDie = $PlayerAnim::Crouching;							
	//						else if(%vertPos=="head") {
	//							if(%quadrant == "front_left" ||	%quadrant == "front_right"	) 
	//								%curDie = radnomItems(2, $PlayerAnim::DieHead, $PlayerAnim::DieBack);
	//						  	else 
	//								%curDie = radnomItems(2, $PlayerAnim::DieHead, $PlayerAnim::DieForward);
	//						}
	//						else if (%vertPos == "torso") {
	//							if(%quadrant == "front_left" ) 
	//								%curDie = radnomItems(3, $PlayerAnim::DieLeftSide, $PlayerAnim::DieChest, $PlayerAnim::DieForwardKneel);
	//							else if(%quadrant == "front_right") 
	//								%curDie = radnomItems(3, $PlayerAnim::DieChest, $PlayerAnim::DieRightSide, $PlayerAnim::DieSpin);
	//							else if(%quadrant == "back_left" ) 
	//								%curDie = radnomItems(4, $PlayerAnim::DieLeftSide, $PlayerAnim::DieGrabBack, $PlayerAnim::DieForward, $PlayerAnim::DieForwardKneel);
	//							else if(%quadrant == "back_right") 
	//								%curDie = radnomItems(4, $PlayerAnim::DieGrabBack, $PlayerAnim::DieRightSide, $PlayerAnim::DieForward, $PlayerAnim::DieForwardKneel);
	//						}
	//						else if (%vertPos == "legs") {
	//							if(%quadrant == "front_left" ||	%quadrant == "back_left") 
	//								%curDie = $PlayerAnim::DieLegLeft;
	//							if(%quadrant == "front_right" ||	%quadrant == "back_right") 
	//								%curDie = $PlayerAnim::DieLegRight;
	//						}
	//						Player::setAnimation(%this, %curDie);
	//					}
	//					if(%type == $ImpactDamageType && %object.clLastMount != "")  
	//						%shooterClient = %object.clLastMount;
	//				   	Client::onKilled(%damagedClient,%shooterClient, %type);
	//				}
	//			}
	//		}
	// 	 }
	//  }
	//}
	
	
	//-------------------------------------
	//Ammo::onDrop() -don't be an idiot!
	//-------------------------------------
	function Ammo::onDrop(%player,%item)
	{
		if($matchStarted) {
			%count = Player::getItemCount(%player,%item);
			%delta = $SellAmmo[%item];
			if(%count <= %delta) { 
				if( %item == "BulletAmmo" || (Player::getMountedItem(%player,$WeaponSlot)).imageType.ammoType != %item)
					%delta = %count;
				else 
					%delta = %count - 1;
	
			}
			if(%delta > 0) {
				%obj = newObject("","Item",%item,%delta,false);
	      	schedule("Item::Pop(" @ %obj @ ");", $ItemPopTime, %obj);
	
	      	addToSet("MissionCleanup", %obj);
				GameBase::throw(%obj,%player,20,false);
				messageAll(0, "~wmale2.wdsgst2.wav");
				Player::decItemCount(%player,%item,%delta);
			}
		}
	}	
	
	
	//do nothing functions
	//function remoteScoresOn(%clientId)
	//{
	//}
	
	//function remoteScoresOff(%clientId)
	//{
	//}
	
	function Item::onDrop(%player, %item)
	{
	}

}