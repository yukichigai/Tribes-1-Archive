$modList = "ANARCHY 2.6";
$Anarchy = "\nwww.anarchymods.com";
$Anarchy::BanKickTime = "1800";
$Anarchy::fairTeams = "true";
$Anarchy::PABan = "false";
$Anarchy::PAKick = "true";
$Anarchy::PAMission = "true";
$Anarchy::PAModOptions = "false";
$Anarchy::PAResetDefaults = "true";
$Anarchy::PATeamChange = "true";
$Anarchy::PATeamDamage = "true";
$Anarchy::PATeamInfo = "false";
$Anarchy::PATimelimit = "false";
$Anarchy::PATourneyMode = "false";
$Anarchy::PAVote = "false";
$Anarchy::tkClientLvl = "1";
$Anarchy::tkLimit = "2";
$Anarchy::tkMultiple = "3";
$Anarchy::tkServerLvl = "3";
$Anarchy::Spawnclass = "false";

//logs the name and IP of everyone who connects, to config\\Connect.log
$ConnectLog = true; 

//log people who are kicked by admins, to config\\KickList.log
$ExportAKicks = false; 

//log people who are kicked by the computer, to config\\KickList.log
$ExportCKicks = false; 

//What you want it to say when an admin kicks a client, this is a centerprint message
//The "\n" will seperate lines of text on the screen... Example....
$Admin::KickMessage = "For being a complete Idiot, and total moron.....\n\n You are being kicked off of this server. \n\n Come back when you no longer have an attack of the dumbass.";

//If you want to use personal skins.  The skins must be installed in the
//tribes\base\skins directory on the server, and on the client side
$Anarchy::PersonalSkin = "true"; 

//When set to true, no one can blow you out of ANY stations
//I wouldn't set this unless you have the station kick on also.
//Without the station kick, they can tie up a station for the rest of the game
//if they want, and nothing will blow them out!!
//If the person gets blocked in so that the station kick function can't
//kick them out, THEN you can shoot them out of the station, but not before.
$StationLockTD = "true";  // no knock from station with teamdamage off
$StationLockNTD = "true";  // no knock from station with teamdamage on

//How long the server will wait before ejecting someone out of a inventory station
$Anarchy::StationTime = "20";  //range is 20-60

$PA::noKick = "True";  //if set to true, public admins cant be kicked by a vote

//If you have someone that you dont want to give admin status too, but dont want
//them to be kicked off of the server by VOTE or Public Admin, put their name in the quotes "".
$Name::noKicka = "";  //name of the client that you dont want to be kicked
$Name::noKickb = "";
$Name::nokickc = "";
$Name::nokickd = "";

//Special message for the owner when you gain super admin
//status with the SAD code..... no big deal, I was bored
$Owner::Name = ""; 

//gives you God admin status with a SAD password
//This is not something that you want to give everyone, 
//it is for the owner of the server only.
$OwnerPassword = "CHANGE ME"; 

$PublicPassword = "CHANGE ME";  //public admin sad code
$AdminPassword = "CHANGE ME";   //super admin sad code